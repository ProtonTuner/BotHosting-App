# Changelog

## 1.1.0
- Added ZIP archive and general file import via Android document picker.
- Added imported-files browser.
- Added archive entry/path validation and extraction limits.
- Bumped Android app version to 1.1.0.


## 1.0.0 — Consolidated Android runtime MVP
- Moved Python execution into a non-exported Android foreground service with an ongoing notification and Stop action.
- Added cooperative stop requests implemented with Python trace events; documented what cannot be interrupted safely.
- Added live console log streaming through a bounded private log file, UTF-8-safe byte chunks and offset deduplication to avoid repeated output when returning to the Activity.
- Replaced source-code Intent payloads with a validated, file-backed script handoff and a 1 MB project limit.
- Added Activity lifecycle protection for Python initialization failures. Persisted last-run status/output and service-state re-query recover stale flags after process death.
- Added individual `.py` import/export with extension checks, a 1 MB import limit, path containment checks, and collision-safe filenames.
- Added notification permission request flow on Android 13+ and system-bar inset handling for target API 35.
- Declared Android 14+ `specialUse` foreground-service type and its use-case property.
- Added GitHub Actions workflow to run host tests and compile/upload a debug APK.
- Version set to 1.0.0 / versionCode 10000.

## 0.3.0 — Dependency manager
- Added a dependency manifest editor with syntax validation.
- Added export of the in-app requirements manifest through Android's Storage Access Framework.
- Connected `app/requirements.txt` to Chaquopy's build-time package installation.
- Added Internet permission and requirement parsing tests.

## 0.2.0 — Workspace and runner reliability
- Added create/list/open/save for Python scripts.
- Added background execution on a single runner executor and bounded stdout/stderr capture.
- Added an in-process lock because cwd and stdout/stderr redirection are process-global.
- Added filename/path validation and host-side automated tests.

This is a source-project milestone. The v1.0.0 APK and foreground-service behavior have not been built/run on a physical Android device in this environment.
