package com.mini.bothost;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Descarga el bot desde GitHub (repo completo o un .zip dentro del repo) y lo extrae. */
final class GitHub {
    private GitHub() { }

    /** Devuelve null si todo salio bien, o el mensaje de error. */
    static String update(Context c, Store.Bot b) {
        String repo = b.ghRepo.trim();
        if (!repo.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")) {
            return "Repositorio no válido (usa usuario/repo)";
        }
        String ref = b.ghBranch.trim().isEmpty() ? "main" : b.ghBranch.trim();
        String path = b.ghPath.trim();
        while (path.startsWith("/")) {
            path = path.substring(1);
        }
        String url = "https://api.github.com/repos/" + repo
                + (path.isEmpty() ? "/zipball/" + Uri.encode(ref, "/")
                : "/contents/" + Uri.encode(path, "/") + "?ref=" + Uri.encode(ref));

        File tmp = new File(c.getCacheDir(), "gh.dl");
        HttpURLConnection h = null;
        try {
            h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(60000);
            h.setRequestProperty("User-Agent", "BotHost");
            h.setRequestProperty("Accept", path.isEmpty()
                    ? "application/vnd.github+json" : "application/vnd.github.raw+json");
            if (!b.ghToken.trim().isEmpty()) {
                h.setRequestProperty("Authorization", "Bearer " + b.ghToken.trim());
            }
            int code = h.getResponseCode();
            if (code == 401 || code == 403) {
                return "GitHub rechazó el acceso (revisa el token y sus permisos)";
            }
            if (code == 404) {
                return "No se encontró el repo, la rama o el archivo (¿falta el token de un repo privado?)";
            }
            if (code != 200) {
                return "GitHub respondió " + code;
            }
            InputStream in = h.getInputStream();
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[8192];
                long total = 0;
                int n;
                while ((n = in.read(buf)) != -1) {
                    total += n;
                    if (total > 100L * 1024 * 1024) {
                        return "El archivo pesa más de 100 MB";
                    }
                    out.write(buf, 0, n);
                }
            } finally {
                in.close();
                out.close();
            }
            if (path.isEmpty() || path.toLowerCase().endsWith(".zip")) {
                if (Store.unzip(tmp, Store.dir(c, b.id)) < 0) {
                    return "No se pudo extraer el zip descargado";
                }
            } else {
                File dest = Store.resolve(c, b.id, path.substring(path.lastIndexOf('/') + 1));
                if (dest == null || !tmp.renameTo(dest)) {
                    return "No se pudo guardar el archivo";
                }
            }
            return null;
        } catch (IOException e) {
            return "Error de red: " + e.getMessage();
        } finally {
            if (h != null) {
                h.disconnect();
            }
            tmp.delete();
        }
    }
}
