# Changelog — Vesper Runtime

## 1.7.0 — Stabilized project imports and dependency diagnostics

- ZIP import now prefers likely startup scripts (`main.py`, `main_2.py`, `bot.py`, and common alternatives) rather than blindly selecting the first `.py` entry in archive order.
- Recognizes a single top-level wrapper directory, preserves packages and sibling files, and reports when a ZIP has no runnable Python source.
- Checks project copy collisions before copying files, reducing the chance of leaving a partially imported project when a filename conflicts.
- Python execution adds the workspace and its subdirectories to the temporary import path, supporting local modules inside wrapper folders as well as a root-level `bot/` package.
- Missing imports now include a diagnostic that distinguishes local-project code from external dependencies and explains that external packages must be bundled into the APK at build time.
- Updated Android version metadata and CI artifact name to 1.7.0 / versionCode 10700.

Limitations: this is a source release, not a promise of zero failures. Third-party compatibility depends on Chaquopy/Android wheels, device policies, and the user's project. Host-side tests pass in this workspace, but Android APK assembly and physical-device execution were not available here.

## 1.6.2 — ZIP project package imports

- ZIP imports now copy the startup script's sibling source files and package directories into the runnable workspace instead of copying only one .py file.
- The Python runner adds the active project workspace to `sys.path` during execution, enabling imports such as `from bot import consola`, then restores the prior path.
- Added a regression test for importing a local package.
- This fixes local-module lookup when those files are included in the imported ZIP; it does not install missing third-party dependencies.

## 1.3.0 — Persistent local runtime

- Added opt-in sticky-service recovery after an unexpected process kill, using the last user-started script.
- Explicit stop and normal script completion clear recovery state.
- Added hosting-panel controls for auto-restart and Android battery/background settings.
- Bumped Android version to 1.3.0 (versionCode 10300).
- Preserved ZIP import, extraction limits, path validation, project editor, dependency manager, and console.

Limitations: recovery depends on Android service lifecycle and device-vendor policy. Force-stop and reboot are not handled by a boot receiver. This is not a guarantee of persistent 24/7 hosting. APK compilation and physical-device behavior must be verified separately.

# Changelog

## 1.2.0 — Local hosting panel

- Added a Wispbyte-inspired Hosting Panel showing run state, startup script, project count, available app storage and available device RAM.
- Added persistent startup-script selection and one-tap start/stop actions using the existing foreground Python service.
- Preserved ZIP/file import, path traversal protections, Python editor, dependency validator and console.
- Updated Android version metadata and GitHub Actions artifact name.
- Scope: local phone-hosting only; no promise of 24/7 uptime or a remote server.


## 1.1.0
- Added ZIP archive and general file import via Android document picker.
- Added imported-files browser.
- Added archive entry/path validation and extraction limits.
- Bumped Android app version to 1.1.0.


## 1.0.0 — Consolidated Android runtime MVP
- Moved Python execution into a non-exported Android foreground service with an ongoing notification and Stop action.
- Added cooperative stop requests implemented with Python trace events; documented what cannot be interrupted safely.
- Added live console log streaming through a bounded private log file, UTF-8-safe byte chunks and offset deduplication to avoid repeated output when returning to the Activity.
- Replaced source-code Intent payloads with a validated, file-backed script handoff and a 1 MB project limit.
- Added Activity lifecycle protection for Python initialization failures. Persisted last-run status/output and service-state re-query recover stale flags after process death.
- Added individual `.py` import/export with extension checks, a 1 MB import limit, path containment checks, and collision-safe filenames.
- Added notification permission request flow on Android 13+ and system-bar inset handling for target API 35.
- Declared Android 14+ `specialUse` foreground-service type and its use-case property.
- Added GitHub Actions workflow to run host tests and compile/upload a debug APK.
- Version set to 1.0.0 / versionCode 10000.

## 0.3.0 — Dependency manager
- Added a dependency manifest editor with syntax validation.
- Added export of the in-app requirements manifest through Android's Storage Access Framework.
- Connected `app/requirements.txt` to Chaquopy's build-time package installation.
- Added Internet permission and requirement parsing tests.

## 0.2.0 — Workspace and runner reliability
- Added create/list/open/save for Python scripts.
- Added background execution on a single runner executor and bounded stdout/stderr capture.
- Added an in-process lock because cwd and stdout/stderr redirection are process-global.
- Added filename/path validation and host-side automated tests.

This is a source-project milestone. The v1.0.0 APK and foreground-service behavior have not been built/run on a physical Android device in this environment.


## 1.2.0 — Local hosting panel

- Added a Wispbyte-inspired Hosting Panel showing run state, startup script, project count, available app storage and available device RAM.
- Added persistent startup-script selection and one-tap start/stop actions using the existing foreground Python service.
- Preserved ZIP/file import, path traversal protections, Python editor, dependency validator and console.
- Updated Android version metadata and GitHub Actions artifact name.
- Scope: local phone-hosting only; no promise of 24/7 uptime or a remote server.

## 1.4.0 — Hosting dashboard UI refresh
- Replaced the long plain form with a dark, card-based local hosting dashboard inspired by common game-server panels.
- Added a server overview card with prominent start/stop controls, quick-access actions, a dedicated code-editor card, file/dependency actions, and a terminal-style console.
- Preserved Python project creation, selection, saving, ZIP/file import, exports, dependency manager, startup-script selection, and the hosting panel.
- Updated Android version metadata to 1.4.0 (versionCode 10400).
- This is a Wispbyte-inspired interface, not an exact reproduction of Wispbyte's proprietary UI or hosted service.


## 1.5.0 — Integrated file manager
- Added in-app file browser for Vesper's private imports workspace with folder navigation and file-type indicators.
- Added per-item actions: preview/open, select feedback, duplicate, rename, move, export/download text files, ZIP extraction, pin-to-quick-access preference, and confirmed deletion.
- ZIP extraction validates entry paths, limits entry count and expanded size, and rejects traversal paths.
- Existing ZIP/file import, Python editor, runtime controls, and dependency manager remain available.
- APK compilation and on-device behavior still require CI/device verification.
