package com.mini.bothost;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Persistencia en archivos (la leen varios procesos, por eso no usamos SharedPreferences).
 * filesDir/bots/ID/{config.json, main.py, log.txt, heartbeat.json}
 * filesDir/slots/slotN  -> id del bot que ocupa el proceso N mientras corre
 */
final class Store {
    static final int MAX_BOTS = 4;

    static final String TEMPLATE =
            "import os\n"
            + "import discord\n"
            + "from discord.ext import commands\n"
            + "\n"
            + "TOKEN = os.getenv(\"DISCORD_TOKEN\")  # se configura en la pantalla del bot\n"
            + "\n"
            + "intents = discord.Intents.default()\n"
            + "intents.message_content = True  # activalo tambien en el Developer Portal\n"
            + "bot = commands.Bot(command_prefix=\"!\", intents=intents)\n"
            + "\n"
            + "\n"
            + "@bot.event\n"
            + "async def on_ready():\n"
            + "    print(f\"Conectado como {bot.user}\")\n"
            + "\n"
            + "\n"
            + "@bot.command()\n"
            + "async def ping(ctx):\n"
            + "    await ctx.send(f\"Pong! {round(bot.latency * 1000)} ms\")\n"
            + "\n"
            + "\n"
            + "bot.run(TOKEN)\n";

    static class Bot {
        String id = "";
        String name = "Bot";
        String token = "";
        String env = "";
        boolean autoRestart = true;
        boolean autoStart = false;
        int slot = 0;
    }

    private Store() { }

    // ---------- rutas ----------

    static File botsDir(Context c) {
        File f = new File(c.getFilesDir(), "bots");
        if (!f.exists()) {
            f.mkdirs();
        }
        return f;
    }

    static File dir(Context c, String id) {
        return new File(botsDir(c), id);
    }

    static File mainPy(Context c, String id) {
        return new File(dir(c, id), "main.py");
    }

    static File logFile(Context c, String id) {
        return new File(dir(c, id), "log.txt");
    }

    static File heartbeatFile(Context c, String id) {
        return new File(dir(c, id), "heartbeat.json");
    }

    static File slotFile(Context c, int slot) {
        File d = new File(c.getFilesDir(), "slots");
        if (!d.exists()) {
            d.mkdirs();
        }
        return new File(d, "slot" + slot);
    }

    // ---------- bots ----------

    static List<Bot> list(Context c) {
        List<Bot> out = new ArrayList<>();
        File[] dirs = botsDir(c).listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                Bot b = load(c, d.getName());
                if (b != null) {
                    out.add(b);
                }
            }
        }
        Collections.sort(out, new Comparator<Bot>() {
            @Override
            public int compare(Bot a, Bot b) {
                return a.slot - b.slot;
            }
        });
        return out;
    }

    static Bot load(Context c, String id) {
        File f = new File(dir(c, id), "config.json");
        if (!f.exists()) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(readText(f));
            Bot b = new Bot();
            b.id = id;
            b.name = o.optString("name", "Bot");
            b.token = o.optString("token", "");
            b.env = o.optString("env", "");
            b.autoRestart = o.optBoolean("autoRestart", true);
            b.autoStart = o.optBoolean("autoStart", false);
            b.slot = o.optInt("slot", 0);
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    static void save(Context c, Bot b) {
        try {
            JSONObject o = new JSONObject();
            o.put("name", b.name);
            o.put("token", b.token);
            o.put("env", b.env);
            o.put("autoRestart", b.autoRestart);
            o.put("autoStart", b.autoStart);
            o.put("slot", b.slot);
            writeText(new File(dir(c, b.id), "config.json"), o.toString());
        } catch (JSONException ignored) {
            // no deberia pasar
        }
    }

    /** Devuelve null si ya hay MAX_BOTS. */
    static Bot create(Context c, String name, String code) {
        boolean[] used = new boolean[MAX_BOTS];
        for (Bot x : list(c)) {
            if (x.slot >= 0 && x.slot < MAX_BOTS) {
                used[x.slot] = true;
            }
        }
        int slot = -1;
        for (int i = 0; i < MAX_BOTS; i++) {
            if (!used[i]) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            return null;
        }
        Bot b = new Bot();
        b.id = UUID.randomUUID().toString().substring(0, 8);
        b.name = name;
        b.slot = slot;
        dir(c, b.id).mkdirs();
        writeText(mainPy(c, b.id), code);
        save(c, b);
        return b;
    }

    static void delete(Context c, String id) {
        Bot b = load(c, id);
        if (b != null) {
            slotFile(c, b.slot).delete();
        }
        deleteRec(dir(c, id));
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                deleteRec(k);
            }
        }
        f.delete();
    }

    // ---------- estado ----------

    /** Latido escrito por Python cada 3 s; null si no hay o esta viejo. */
    static JSONObject heartbeat(Context c, String id) {
        File f = heartbeatFile(c, id);
        if (!f.exists()) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(readText(f));
            double age = System.currentTimeMillis() / 1000.0 - o.optDouble("t", 0);
            return age < 12 ? o : null;
        } catch (Exception e) {
            return null;
        }
    }

    static boolean starting(Context c, Bot b) {
        File sf = slotFile(c, b.slot);
        return sf.exists()
                && System.currentTimeMillis() - sf.lastModified() < 45000
                && readText(sf).trim().equals(b.id);
    }

    static boolean isActive(Context c, Bot b) {
        return heartbeat(c, b.id) != null || starting(c, b);
    }

    static String statusText(Context c, Bot b) {
        JSONObject hb = heartbeat(c, b.id);
        if (hb != null) {
            boolean ready = hb.optBoolean("ready");
            StringBuilder sb = new StringBuilder(ready ? "● En línea" : "◐ Conectando…");
            if (ready) {
                String user = hb.optString("user", "");
                if (!user.isEmpty()) {
                    sb.append(" · ").append(user);
                }
                sb.append(" · ").append(hb.optInt("guilds", 0)).append(" servidores");
                int ping = hb.optInt("ping", -1);
                if (ping >= 0) {
                    sb.append(" · ").append(ping).append(" ms");
                }
            }
            sb.append("\nRAM ").append(Math.round(hb.optDouble("mem", 0))).append(" MB");
            long up = (long) (System.currentTimeMillis() / 1000.0 - hb.optDouble("started", 0));
            sb.append(" · activo ").append(fmtDur(Math.max(0, up)));
            return sb.toString();
        }
        if (starting(c, b)) {
            return "◐ Iniciando…";
        }
        return "○ Detenido";
    }

    private static String fmtDur(long s) {
        if (s < 60) {
            return s + "s";
        }
        if (s < 3600) {
            return (s / 60) + "m";
        }
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }

    // ---------- archivos ----------

    static String readText(File f) {
        return readTail(f, 4 * 1024 * 1024);
    }

    static String readTail(File f, int maxBytes) {
        if (f == null || !f.exists()) {
            return "";
        }
        RandomAccessFile r = null;
        try {
            r = new RandomAccessFile(f, "r");
            long len = r.length();
            long start = Math.max(0L, len - (long) maxBytes);
            r.seek(start);
            byte[] buf = new byte[(int) (len - start)];
            r.readFully(buf);
            String s = new String(buf, StandardCharsets.UTF_8);
            if (start > 0) {
                int nl = s.indexOf('\n');
                if (nl >= 0) {
                    s = s.substring(nl + 1);
                }
            }
            return s;
        } catch (IOException e) {
            return "";
        } finally {
            if (r != null) {
                try {
                    r.close();
                } catch (IOException ignored) {
                    // nada
                }
            }
        }
    }

    static void writeText(File f, String s) {
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) {
                p.mkdirs();
            }
            FileOutputStream o = new FileOutputStream(f);
            try {
                o.write(s.getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
            // sin espacio o sin permisos: no hay mucho que hacer
        }
    }

    static void appendLog(Context c, String id, String msg) {
        try {
            String line = new SimpleDateFormat("HH:mm:ss ", Locale.US).format(new Date()) + msg + "\n";
            FileOutputStream o = new FileOutputStream(logFile(c, id), true);
            try {
                o.write(line.getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
            // nada
        }
    }
}
