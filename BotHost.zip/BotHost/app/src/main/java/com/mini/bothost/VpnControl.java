package com.mini.bothost;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Corre en el proceso principal (los bots viven en :b0..:b3). Los bots le avisan al iniciar y al
 * detenerse; levanta la VPN con el primer bot y la baja cuando ya no queda ninguno.
 */
public class VpnControl extends Service {
    static final String A_ACQ = "com.mini.bothost.VPN_ACQUIRE";
    static final String A_REL = "com.mini.bothost.VPN_RELEASE";
    static final String A_SYNC = "com.mini.bothost.VPN_SYNC";

    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, final int startId) {
        final Context c = getApplicationContext();
        if (intent == null) {
            // El sistema reinicio este servicio: recuperar los bots que siguen activos.
            for (int i = 0; i < BotService.SLOTS.length; i++) {
                if (!Store.readText(Store.slotFile(c, i)).trim().isEmpty()) {
                    Vpn.setSlot(i, true);
                }
            }
        } else {
            String a = intent.getAction();
            int slot = intent.getIntExtra("slot", -1);
            if (A_ACQ.equals(a)) {
                Vpn.setSlot(slot, true);
            } else if (A_REL.equals(a)) {
                Vpn.setSlot(slot, false);
            }
        }
        EXEC.execute(new Runnable() {
            @Override
            public void run() {
                Vpn.sync(c);
                if (!Vpn.hasSlots()) {
                    stopSelf(startId);
                }
            }
        });
        return START_STICKY;
    }
}
