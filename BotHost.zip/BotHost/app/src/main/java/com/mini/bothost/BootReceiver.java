package com.mini.bothost;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Al encender el telefono, inicia los bots marcados con "Iniciar con el celular". */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            return;
        }
        for (Store.Bot b : Store.list(context)) {
            if (b.autoStart) {
                try {
                    BotService.start(context, b);
                } catch (Exception ignored) {
                    // el sistema puede negar el arranque; el usuario puede iniciarlo a mano
                }
            }
        }
    }
}
