package com.mini.bothost;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * VPN WireGuard opcional (por ejemplo la config .conf de Proton VPN).
 * - La config y el interruptor se guardan en archivos (los leen todos los procesos).
 * - El tunel solo se levanta en el proceso principal (VpnControl) y SOLO para esta app
 *   (IncludedApplications): el resto del telefono no se toca. Como los procesos de los bots
 *   comparten el mismo UID, su trafico tambien sale por la VPN.
 */
final class Vpn {
    private static GoBackend backend;
    private static boolean up;
    /** Bots activos que piden la VPN (solo se usa en el proceso principal). */
    private static final Set<Integer> SLOTS = new HashSet<Integer>();

    private static final Tunnel TUNNEL = new Tunnel() {
        @Override
        public String getName() {
            return "bothost";
        }

        @Override
        public void onStateChange(Tunnel.State newState) {
            // no hace falta reaccionar
        }
    };

    private Vpn() { }

    // ---------- ajustes (archivos) ----------

    static File confFile(Context c) {
        return new File(c.getFilesDir(), "vpn.conf");
    }

    static File onFile(Context c) {
        return new File(c.getFilesDir(), "vpn.on");
    }

    static File errFile(Context c) {
        return new File(c.getFilesDir(), "vpn.err");
    }

    static String config(Context c) {
        return Store.readText(confFile(c));
    }

    static void setConfig(Context c, String s) {
        if (s == null || s.trim().isEmpty()) {
            confFile(c).delete();
        } else {
            Store.writeText(confFile(c), s);
        }
    }

    static boolean switchOn(Context c) {
        return onFile(c).exists();
    }

    static void setSwitch(Context c, boolean on) {
        if (on) {
            Store.writeText(onFile(c), "1");
        } else {
            onFile(c).delete();
        }
    }

    /** Activada y con config: los bots esperaran a la VPN al iniciar. */
    static boolean enabled(Context c) {
        return switchOn(c) && !config(c).trim().isEmpty();
    }

    // ---------- config ----------

    /** Devuelve null si la config es valida, o el motivo del error. */
    static String validate(Context c) {
        try {
            parse(c);
            return null;
        } catch (Throwable t) {
            String m = t.getMessage();
            return m == null || m.isEmpty() ? t.toString() : m;
        }
    }

    private static Config parse(Context c) throws Exception {
        String text = config(c);
        StringBuilder sb = new StringBuilder();
        boolean added = false;
        for (String line : text.split("\\r?\\n")) {
            String l = line.trim().toLowerCase(Locale.ROOT).replace(" ", "");
            if (l.startsWith("includedapplications=") || l.startsWith("excludedapplications=")) {
                continue; // la VPN siempre se limita a esta app
            }
            sb.append(line).append('\n');
            if (!added && l.equals("[interface]")) {
                sb.append("IncludedApplications = ").append(c.getPackageName()).append('\n');
                added = true;
            }
        }
        if (!added) {
            throw new IllegalArgumentException("Falta la sección [Interface] (pega el .conf completo)");
        }
        return Config.parse(new ByteArrayInputStream(sb.toString().getBytes(StandardCharsets.UTF_8)));
    }

    // ---------- tunel (solo proceso principal) ----------

    /** Intent para pedir el permiso de VPN a Android, o null si ya esta concedido. */
    static Intent consentIntent(Context c) {
        return VpnService.prepare(c);
    }

    private static void up(Context c) throws Exception {
        Context app = c.getApplicationContext();
        if (VpnService.prepare(app) != null) {
            throw new IllegalStateException(
                    "falta autorizar la VPN: abre Bot Host > VPN y toca “Probar conexión”");
        }
        if (backend == null) {
            backend = new GoBackend(app);
        }
        backend.setState(TUNNEL, Tunnel.State.UP, parse(app));
        up = true;
    }

    private static void down() {
        try {
            if (backend != null && up) {
                backend.setState(TUNNEL, Tunnel.State.DOWN, null);
            }
        } catch (Throwable ignored) {
            // nada que hacer
        }
        up = false;
    }

    /** Deja la VPN como corresponde: arriba si hay bots activos y esta habilitada; abajo si no. */
    static synchronized void sync(Context c) {
        boolean want = !SLOTS.isEmpty() && enabled(c);
        if (want && !up) {
            try {
                errFile(c).delete();
                up(c);
            } catch (Throwable t) {
                String m = t.getMessage();
                Store.writeText(errFile(c), m == null || m.isEmpty() ? t.toString() : m);
            }
        } else if (!want && up) {
            down();
        }
    }

    static synchronized void setSlot(int slot, boolean on) {
        if (slot < 0) {
            return;
        }
        if (on) {
            SLOTS.add(slot);
        } else {
            SLOTS.remove(slot);
        }
    }

    static synchronized boolean hasSlots() {
        return !SLOTS.isEmpty();
    }

    /** Prueba desde la pantalla de VPN: levanta el tunel aunque no haya bots. */
    static synchronized String testUp(Context c) {
        try {
            up(c);
            return null;
        } catch (Throwable t) {
            String m = t.getMessage();
            return m == null || m.isEmpty() ? t.toString() : m;
        }
    }

    // ---------- desde cualquier proceso ----------

    static void send(Context c, String action, int slot) {
        try {
            c.startService(new Intent(c, VpnControl.class).setAction(action).putExtra("slot", slot));
        } catch (Exception ignored) {
            // el sistema puede negarlo; el bot sigue sin VPN
        }
    }

    /** True si hay alguna VPN activa para esta app. */
    static boolean isActive(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
            // sin permiso o sin red
        }
        return false;
    }
}
