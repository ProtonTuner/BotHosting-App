package com.vesper.runtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.chaquo.python.android.AndroidPlatform
import com.chaquo.python.Python
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground service for user-started Python jobs. The notification is visible
 * while a script is running, and the process can keep running when the Activity
 * is covered or destroyed. Android can still stop the app under system pressure.
 */
class RuntimeService : Service() {
    private val executor = Executors.newSingleThreadExecutor { task ->
        Thread(task, "VesperForegroundPython").apply { isDaemon = false }
    }
    private val running = AtomicBoolean(false)
    @Volatile private var currentScript = ""
    @Volatile private var outputPolling = false
    @Volatile private var outputOffset = 0L
    @Volatile private var outputLogFile: File? = null
    private var outputPoller: Thread? = null
    private val outputLock = Any()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN -> startScript(intent, startId)
            ACTION_STOP -> stopScript()
            ACTION_QUERY -> reportCurrentState(startId)
            null -> resumeAfterSystemRestart(startId)
        }
        // If Android reclaims the process, request a service restart. We only
        // resume a script when the user enabled auto-restart and a run was active.
        return START_STICKY
    }

    private fun resumeAfterSystemRestart(startId: Int) {
        val hostingPrefs = getSharedPreferences(HOSTING_PREFS_NAME, MODE_PRIVATE)
        val shouldResume = hostingPrefs.getBoolean(KEY_AUTO_RESTART, false) &&
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_DESIRED_RUNNING, false)
        if (!shouldResume) {
            emitState("READY", false)
            stopSelf(startId)
            return
        }
        val script = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_ACTIVE_SCRIPT, null)
        val projectDir = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_ACTIVE_PROJECT_DIR, null)
        if (script.isNullOrBlank() || projectDir.isNullOrBlank()) {
            clearDesiredRun()
            emitState("Recovery skipped: saved run configuration is incomplete", false)
            stopSelf(startId)
            return
        }
        val resumeIntent = Intent(this, RuntimeService::class.java).apply {
            action = ACTION_RUN
            putExtra(EXTRA_SCRIPT_NAME, script)
            putExtra(EXTRA_PROJECT_DIR, projectDir)
        }
        startScript(resumeIntent, startId)
    }

    private fun clearDesiredRun() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putBoolean(KEY_DESIRED_RUNNING, false)
            .remove(KEY_ACTIVE_SCRIPT)
            .remove(KEY_ACTIVE_PROJECT_DIR)
            .apply()
    }

    private fun reportCurrentState(startId: Int) {
        if (running.get()) {
            val savedStatus = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_STATUS, "Status: RUNNING — $currentScript")
                .orEmpty()
                .removePrefix("Status: ")
            emitState(savedStatus, true)
        } else {
            // Correct stale SharedPreferences if Android previously killed the process.
            emitState("READY", false)
            stopSelf(startId)
        }
    }

    private fun startScript(intent: Intent, startId: Int) {
        if (!running.compareAndSet(false, true)) {
            emitState("A script is already running", true)
            return
        }

        val scriptName = intent.getStringExtra(EXTRA_SCRIPT_NAME)
        val suppliedDir = intent.getStringExtra(EXTRA_PROJECT_DIR)
        if (scriptName == null || suppliedDir == null) {
            running.set(false)
            emitState("Could not start: incomplete run request", false)
            stopSelf(startId)
            return
        }

        val projectsRoot = File(filesDir, "projects").canonicalFile
        val projectDir = try { File(suppliedDir).canonicalFile } catch (_: Exception) { null }
        val expectedFileName = scriptName.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}\\.py", RegexOption.IGNORE_CASE))
        val scriptFile = try { File(projectsRoot, scriptName).canonicalFile } catch (_: Exception) { null }
        if (projectDir == null || projectDir != projectsRoot || !projectsRoot.isDirectory || !expectedFileName ||
            scriptFile == null || scriptFile.parentFile != projectsRoot || !scriptFile.isFile || scriptFile.length() > MAX_SCRIPT_BYTES) {
            running.set(false)
            emitState("Could not start: invalid project path, filename, or oversized/missing script", false)
            stopSelf(startId)
            return
        }
        currentScript = scriptName
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putBoolean(KEY_DESIRED_RUNNING, true)
            .putString(KEY_ACTIVE_SCRIPT, scriptName)
            .putString(KEY_ACTIVE_PROJECT_DIR, projectsRoot.absolutePath)
            .apply()
        outputOffset = 0L
        outputLogFile = null // Never tail a previous run if this run fails before Python starts.
        outputPolling = false
        outputPoller = null
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().remove(KEY_LAST_OUTPUT).apply()
        try {
            enterForeground("Starting $scriptName…")
        } catch (e: Exception) {
            running.set(false)
            clearDesiredRun()
            emitState("Could not promote runtime to foreground service: ${e.message ?: e.javaClass.simpleName}", false)
            stopSelf(startId)
            return
        }
        persistState("RUNNING — $scriptName", true)
        sendState("RUNNING — $scriptName", true)

        try {
            executor.execute {
                var completedStatus = "FINISHED — $scriptName"
                var resultText = ""
                try {
                    val code = scriptFile.readText(Charsets.UTF_8)
                    if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                    startOutputPolling(File(filesDir, "runtime-output.log"))
                    resultText = Python.getInstance().getModule("vesper_runtime")
                        .callAttr("run_code", code, projectsRoot.absolutePath, scriptName, File(filesDir, "runtime-output.log").absolutePath)
                        ?.toString() ?: "(no output)"
                    if (resultText.contains("[Execution stopped by user]")) {
                        completedStatus = "STOPPED — $scriptName"
                    }
                } catch (e: Exception) {
                    completedStatus = "ERROR — $scriptName"
                    resultText = "ERROR: ${e.message ?: e.javaClass.simpleName}"
                } finally {
                    stopOutputPolling()
                    running.set(false)
                    currentScript = ""
                    clearDesiredRun()
                    persistOutput(resultText)
                    // Normally output has already been streamed from the sidecar log.
                    // If that stream was unavailable or the script printed nothing,
                    // send the final summary as a fallback.
                    if (outputOffset == 0L && resultText.isNotBlank()) {
                        sendOutput(resultText + if (resultText.endsWith("\n")) "" else "\n")
                    }
                    persistState(completedStatus, false)
                    sendState(completedStatus, false)
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    // Stop the service regardless of later STOP/rejected RUN intents,
                    // which may have incremented Android's startId after this run.
                    stopSelf()
                }
            }
        } catch (e: Exception) {
            running.set(false)
            clearDesiredRun()
            val message = "Could not schedule Python script: ${e.message ?: e.javaClass.simpleName}"
            persistOutput(message)
            sendOutput(message)
            emitState("ERROR — $scriptName", false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
    }

    private fun stopScript() {
        // An explicit user stop must never be mistaken for an unexpected kill.
        clearDesiredRun()
        if (!running.get()) {
            emitState("No script is running", false)
            stopSelf()
            return
        }
        updateNotification("Stop requested for $currentScript")
        persistState("STOPPING — $currentScript", true)
        sendState("STOPPING — $currentScript", true)
        // Enter Python on a separate thread because acquiring the interpreter lock
        // may wait for the running script to reach a Python thread-switch point.
        Thread({
            try {
                if (Python.isStarted()) {
                    Python.getInstance().getModule("vesper_runtime").callAttr("request_stop")
                }
            } catch (_: Exception) {
                // The job's normal completion path will report any runtime failure.
            }
        }, "VesperStopRequest").apply { isDaemon = true }.start()
    }

    private fun startOutputPolling(file: File) {
        synchronized(outputLock) {
            file.delete()
            outputLogFile = file
            outputOffset = 0L
            outputPolling = true
        }
        outputPoller = Thread({
            while (outputPolling) {
                readNewOutput()
                try { Thread.sleep(120) } catch (_: InterruptedException) { break }
            }
            readNewOutput()
        }, "VesperOutputTail").apply { isDaemon = true; start() }
    }

    private fun stopOutputPolling() {
        outputPolling = false
        val poller = outputPoller
        if (poller != null && poller !== Thread.currentThread()) {
            try { poller.join(1_000) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        }
        readNewOutput()
        outputPoller = null
    }

    private fun readNewOutput() {
        synchronized(outputLock) {
            val file = outputLogFile ?: return
            if (!file.isFile) return
            try {
                // Drain all available bytes in bounded broadcasts. Unicode may use
                // more than one byte per character, so don't assume 100k chars = 100k bytes.
                while (true) {
                    val fileLength = file.length()
                    if (fileLength <= outputOffset) return
                    RandomAccessFile(file, "r").use { stream ->
                        val chunkStart = outputOffset
                        stream.seek(chunkStart)
                        val count = minOf(fileLength - chunkStart, 256_000L).toInt()
                        val bytes = ByteArray(count)
                        val read = stream.read(bytes)
                        if (read > 0) {
                            // Keep UTF-8 code points intact when a very large write needs
                            // more than one broadcast. The next loop rereads trimmed bytes.
                            val hasMoreBytes = fileLength - chunkStart > read
                            val safeCount = completeUtf8PrefixLength(bytes, read, hasMoreBytes)
                            if (safeCount <= 0) return
                            outputOffset = chunkStart + safeCount
                            sendOutput(String(bytes, 0, safeCount, Charsets.UTF_8), chunkStart, outputOffset)
                        } else {
                            return
                        }
                    }
                }
            } catch (e: Exception) {
                sendOutput("\n[Log read error: ${e.message ?: e.javaClass.simpleName}]\n")
            }
        }
    }

    private fun completeUtf8PrefixLength(bytes: ByteArray, length: Int, hasMoreBytes: Boolean): Int {
        if (!hasMoreBytes || length <= 0) return length
        var leadIndex = length - 1
        while (leadIndex >= 0 && (bytes[leadIndex].toInt() and 0xC0) == 0x80) leadIndex--
        if (leadIndex < 0) return length
        val lead = bytes[leadIndex].toInt() and 0xFF
        val expectedLength = when {
            (lead and 0x80) == 0 -> 1
            (lead and 0xE0) == 0xC0 -> 2
            (lead and 0xF0) == 0xE0 -> 3
            (lead and 0xF8) == 0xF0 -> 4
            else -> 1
        }
        val available = length - leadIndex
        return if (available < expectedLength) leadIndex else length
    }

    private fun enterForeground(text: String) {
        val stopIntent = Intent(this, RuntimeService::class.java).setAction(ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(
            this, STOP_PENDING_INTENT_ID, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, OPEN_PENDING_INTENT_ID, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Vesper Runtime")
            .setContentText(text)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_pause, "Stop script", stopPendingIntent)
            .build()

        val serviceType = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, serviceType)
    }

    private fun updateNotification(text: String) {
        enterForeground(text)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Running Python scripts", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shows when Vesper Runtime is executing a user-started Python script."
                }
            )
        }
    }

    private fun emitState(status: String, isRunning: Boolean) {
        persistState(status, isRunning)
        sendState(status, isRunning)
    }

    private fun persistState(status: String, isRunning: Boolean) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putString(KEY_STATUS, "Status: $status")
            .putBoolean(KEY_RUNNING, isRunning)
            .apply()
    }

    private fun persistOutput(text: String) {
        val capped = if (text.length > MAX_STORED_OUTPUT) {
            "[Earlier output trimmed]\n" + text.takeLast(MAX_STORED_OUTPUT - 25)
        } else text
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
            .putString(KEY_LAST_OUTPUT, capped)
            .apply()
    }

    private fun sendState(status: String, isRunning: Boolean) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName)
            .putExtra(EXTRA_STATUS, "Status: $status")
            .putExtra(EXTRA_RUNNING, isRunning))
    }

    private fun sendOutput(output: String, byteStartOffset: Long? = null, byteOffset: Long? = null) {
        val intent = Intent(ACTION_OUTPUT).setPackage(packageName).putExtra(EXTRA_OUTPUT, output)
        if (byteStartOffset != null) intent.putExtra(EXTRA_OUTPUT_START_OFFSET, byteStartOffset)
        if (byteOffset != null) intent.putExtra(EXTRA_OUTPUT_OFFSET, byteOffset)
        sendBroadcast(intent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_RUN = "com.vesper.runtime.action.RUN"
        const val ACTION_STOP = "com.vesper.runtime.action.STOP"
        const val ACTION_QUERY = "com.vesper.runtime.action.QUERY"
        const val ACTION_STATE = "com.vesper.runtime.action.STATE"
        const val ACTION_OUTPUT = "com.vesper.runtime.action.OUTPUT"
        const val EXTRA_SCRIPT_NAME = "script_name"
        const val EXTRA_PROJECT_DIR = "project_dir"
        const val EXTRA_STATUS = "status"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_OUTPUT = "output"
        const val EXTRA_OUTPUT_START_OFFSET = "output_start_offset"
        const val EXTRA_OUTPUT_OFFSET = "output_offset"
        const val PREFS_NAME = "vesper_runtime_state"
        const val HOSTING_PREFS_NAME = "vesper_hosting"
        const val KEY_AUTO_RESTART = "auto_restart"
        const val KEY_DESIRED_RUNNING = "desired_running"
        const val KEY_ACTIVE_SCRIPT = "active_script"
        const val KEY_ACTIVE_PROJECT_DIR = "active_project_dir"
        const val KEY_STATUS = "status"
        const val KEY_RUNNING = "running"
        const val KEY_LAST_OUTPUT = "last_output"
        private const val CHANNEL_ID = "vesper_runtime_execution"
        private const val NOTIFICATION_ID = 4103
        private const val STOP_PENDING_INTENT_ID = 4104
        private const val OPEN_PENDING_INTENT_ID = 4105
        private const val MAX_STORED_OUTPUT = 100_000
        private const val MAX_SCRIPT_BYTES = 1_000_000L
    }
}
