package com.mini.bothost;

import android.content.Context;
import android.net.Uri;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Persistencia en archivos (la leen varios procesos, por eso no usamos SharedPreferences).
 * filesDir/bots/ID/{config.json, main.py, log.txt, heartbeat.json}
 * filesDir/slots/slotN  -> id del bot que ocupa el proceso N mientras corre
 */
final class Store {
    static final int MAX_BOTS = 4;

    static final String TEMPLATE =
            "import os\n"
            + "import discord\n"
            + "from discord.ext import commands\n"
            + "\n"
            + "TOKEN = os.getenv(\"DISCORD_TOKEN\")  # se configura en la pantalla del bot\n"
            + "\n"
            + "intents = discord.Intents.default()\n"
            + "intents.message_content = True  # activalo tambien en el Developer Portal\n"
            + "bot = commands.Bot(command_prefix=\"!\", intents=intents)\n"
            + "\n"
            + "\n"
            + "@bot.event\n"
            + "async def on_ready():\n"
            + "    print(f\"Conectado como {bot.user}\")\n"
            + "\n"
            + "\n"
            + "@bot.command()\n"
            + "async def ping(ctx):\n"
            + "    await ctx.send(f\"Pong! {round(bot.latency * 1000)} ms\")\n"
            + "\n"
            + "\n"
            + "bot.run(TOKEN)\n";

    static class Bot {
        String id = "";
        String name = "Bot";
        String token = "";
        String env = "";
        boolean autoRestart = true;
        boolean autoStart = false;
        boolean installReqs = true;
        String webhook = "";
        String ghRepo = "";
        String ghBranch = "main";
        String ghPath = "";
        String ghToken = "";
        int slot = 0;
        // --- repo / arranque ---
        String entry = "main.py";   // archivo principal (puede estar en subcarpeta)
        boolean autoPull = false;   // actualizar desde GitHub cada vez que inicia
        // --- rendimiento (editable; 0 = sin limite) ---
        int limRam = 0;             // MB
        int limCpu = 0;             // % de un nucleo
        int limPing = 0;            // ms (solo avisa)
        int limSecs = 60;           // segundos sostenidos antes de actuar
        boolean limRestart = false; // reiniciar al superar RAM/CPU (si no, solo avisa)
        int restartHours = 0;       // reinicio programado
        int gcMinutes = 0;          // gc.collect() periodico
        int sampleSecs = 3;         // intervalo de medicion (2-10)
        int nice = 0;               // 0 normal, 10 baja, 19 muy baja
        boolean cpuLock = true;     // WakeLock parcial
        boolean wifiLock = true;    // Wi-Fi alto rendimiento
    }

    private Store() { }

    // ---------- rutas ----------

    static File botsDir(Context c) {
        File f = new File(c.getFilesDir(), "bots");
        if (!f.exists()) {
            f.mkdirs();
        }
        return f;
    }

    static File dir(Context c, String id) {
        return new File(botsDir(c), id);
    }

    static File mainPy(Context c, String id) {
        return new File(dir(c, id), "main.py");
    }

    static File logFile(Context c, String id) {
        return new File(dir(c, id), "log.txt");
    }

    static File heartbeatFile(Context c, String id) {
        return new File(dir(c, id), "heartbeat.json");
    }

    static File slotFile(Context c, int slot) {
        File d = new File(c.getFilesDir(), "slots");
        if (!d.exists()) {
            d.mkdirs();
        }
        return new File(d, "slot" + slot);
    }

    // ---------- bots ----------

    static List<Bot> list(Context c) {
        List<Bot> out = new ArrayList<>();
        File[] dirs = botsDir(c).listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                Bot b = load(c, d.getName());
                if (b != null) {
                    out.add(b);
                }
            }
        }
        Collections.sort(out, new Comparator<Bot>() {
            @Override
            public int compare(Bot a, Bot b) {
                return a.slot - b.slot;
            }
        });
        return out;
    }

    static Bot load(Context c, String id) {
        File f = new File(dir(c, id), "config.json");
        if (!f.exists()) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(readText(f));
            Bot b = new Bot();
            b.id = id;
            b.name = o.optString("name", "Bot");
            b.token = o.optString("token", "");
            b.env = o.optString("env", "");
            b.autoRestart = o.optBoolean("autoRestart", true);
            b.autoStart = o.optBoolean("autoStart", false);
            b.installReqs = o.optBoolean("installReqs", true);
            b.webhook = o.optString("webhook", "");
            b.ghRepo = o.optString("ghRepo", "");
            b.ghBranch = o.optString("ghBranch", "main");
            b.ghPath = o.optString("ghPath", "");
            b.ghToken = o.optString("ghToken", "");
            b.slot = o.optInt("slot", 0);
            b.entry = o.optString("entry", "main.py");
            if (b.entry.trim().isEmpty()) {
                b.entry = "main.py";
            }
            b.autoPull = o.optBoolean("autoPull", false);
            b.limRam = Math.max(0, o.optInt("limRam", 0));
            b.limCpu = Math.max(0, o.optInt("limCpu", 0));
            b.limPing = Math.max(0, o.optInt("limPing", 0));
            b.limSecs = Math.max(10, o.optInt("limSecs", 60));
            b.limRestart = o.optBoolean("limRestart", false);
            b.restartHours = Math.max(0, o.optInt("restartHours", 0));
            b.gcMinutes = Math.max(0, o.optInt("gcMinutes", 0));
            b.sampleSecs = Math.min(10, Math.max(2, o.optInt("sampleSecs", 3)));
            b.nice = Math.min(19, Math.max(0, o.optInt("nice", 0)));
            b.cpuLock = o.optBoolean("cpuLock", true);
            b.wifiLock = o.optBoolean("wifiLock", true);
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    static void save(Context c, Bot b) {
        try {
            JSONObject o = new JSONObject();
            o.put("name", b.name);
            o.put("token", b.token);
            o.put("env", b.env);
            o.put("autoRestart", b.autoRestart);
            o.put("autoStart", b.autoStart);
            o.put("installReqs", b.installReqs);
            o.put("webhook", b.webhook);
            o.put("ghRepo", b.ghRepo);
            o.put("ghBranch", b.ghBranch);
            o.put("ghPath", b.ghPath);
            o.put("ghToken", b.ghToken);
            o.put("slot", b.slot);
            o.put("entry", b.entry);
            o.put("autoPull", b.autoPull);
            o.put("limRam", b.limRam);
            o.put("limCpu", b.limCpu);
            o.put("limPing", b.limPing);
            o.put("limSecs", b.limSecs);
            o.put("limRestart", b.limRestart);
            o.put("restartHours", b.restartHours);
            o.put("gcMinutes", b.gcMinutes);
            o.put("sampleSecs", b.sampleSecs);
            o.put("nice", b.nice);
            o.put("cpuLock", b.cpuLock);
            o.put("wifiLock", b.wifiLock);
            writeText(new File(dir(c, b.id), "config.json"), o.toString());
        } catch (JSONException ignored) {
            // no deberia pasar
        }
    }

    /** Devuelve null si ya hay MAX_BOTS. Con code == null no crea main.py (bots desde repositorio). */
    static Bot create(Context c, String name, String code) {
        boolean[] used = new boolean[MAX_BOTS];
        for (Bot x : list(c)) {
            if (x.slot >= 0 && x.slot < MAX_BOTS) {
                used[x.slot] = true;
            }
        }
        int slot = -1;
        for (int i = 0; i < MAX_BOTS; i++) {
            if (!used[i]) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            return null;
        }
        Bot b = new Bot();
        b.id = UUID.randomUUID().toString().substring(0, 8);
        b.name = name;
        b.slot = slot;
        dir(c, b.id).mkdirs();
        if (code != null) {
            writeText(mainPy(c, b.id), code);
        }
        save(c, b);
        return b;
    }

    static void delete(Context c, String id) {
        Bot b = load(c, id);
        if (b != null) {
            slotFile(c, b.slot).delete();
        }
        deleteRec(dir(c, id));
    }

    // ---------- exportar / importar bot completo ----------

    /** Zip con codigo, datos y config.json (token incluido). Sin libs, logs ni cache. */
    static boolean exportFull(Context c, String id, Uri uri) {
        java.util.zip.ZipOutputStream z = null;
        try {
            java.io.OutputStream os = c.getContentResolver().openOutputStream(uri);
            if (os == null) {
                return false;
            }
            z = new java.util.zip.ZipOutputStream(os);
            addDir(z, dir(c, id), "");
            z.close();
            z = null;
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            if (z != null) {
                try {
                    z.close();
                } catch (IOException ignored) {
                    // nada
                }
            }
        }
    }

    private static void addDir(java.util.zip.ZipOutputStream z, File d, String prefix) throws IOException {
        File[] kids = d.listFiles();
        if (kids == null) {
            return;
        }
        for (File k : kids) {
            String n = k.getName();
            if (k.isDirectory()) {
                if (!n.equals("libs") && !n.equals("__pycache__") && !n.equals(".deps-tmp")) {
                    addDir(z, k, prefix + n + "/");
                }
                continue;
            }
            if (n.endsWith(".pyc")
                    || (prefix.isEmpty() && (n.equals("log.txt") || n.equals("log.txt.1")
                    || n.startsWith("heartbeat.json") || n.equals("metrics.json")
                    || n.equals("stats.json") || n.equals("deploy.json")))) {
                continue;
            }
            z.putNextEntry(new java.util.zip.ZipEntry(prefix + n));
            InputStream in = new java.io.FileInputStream(k);
            try {
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) != -1) {
                    z.write(buf, 0, r);
                }
            } finally {
                in.close();
            }
            z.closeEntry();
        }
    }

    /** Crea un bot nuevo desde un zip exportado con exportFull. null si no es valido o no hay slot. */
    static Bot importFull(Context c, File zip) {
        java.util.zip.ZipFile zf = null;
        try {
            zf = new java.util.zip.ZipFile(zip);
            java.util.zip.ZipEntry e = zf.getEntry("config.json");
            if (e == null) {
                return null;
            }
            InputStream in = zf.getInputStream(e);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) != -1) {
                bo.write(buf, 0, r);
            }
            in.close();
            JSONObject o = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            Bot b = create(c, o.optString("name", "Bot importado"), "");
            if (b == null) {
                return null;
            }
            unzip(zip, dir(c, b.id));
            o.put("slot", b.slot);
            writeText(new File(dir(c, b.id), "config.json"), o.toString());
            return load(c, b.id);
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                if (zf != null) {
                    zf.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    /** Borra libs/ completo (dependencias descargadas) para reinstalar desde cero. */
    static void wipeLibs(Context c, String id) {
        deleteRec(new File(dir(c, id), "libs"));
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                deleteRec(k);
            }
        }
        f.delete();
    }

    // ---------- archivos extra del bot (cogs, json, etc.) ----------

    private static final String[] HIDDEN = {
            "config.json", "log.txt", "log.txt.1", "heartbeat.json", "heartbeat.json.tmp",
            "metrics.json", "metrics.json.tmp", "stats.json", "stats.json.tmp", "deploy.json"};

    private static boolean isHidden(String rel) {
        for (String h : HIDDEN) {
            if (h.equals(rel)) {
                return true;
            }
        }
        return false;
    }

    /** Ruta segura dentro de la carpeta del bot, o null si no es valida. */
    static File resolve(Context c, String id, String rel) {
        if (rel == null) {
            return null;
        }
        rel = rel.trim().replace('\\', '/');
        while (rel.startsWith("/")) {
            rel = rel.substring(1);
        }
        if (rel.isEmpty() || rel.contains("..") || rel.endsWith("/") || isHidden(rel)) {
            return null;
        }
        return new File(dir(c, id), rel);
    }

    /** Archivos del usuario (rutas relativas), sin config/logs/__pycache__/libs. */
    static List<String> userFiles(Context c, String id) {
        List<String> out = new ArrayList<>();
        collect(dir(c, id), "", 0, out);
        Collections.sort(out);
        return out;
    }

    private static void collect(File d, String prefix, int depth, List<String> out) {
        File[] kids = d.listFiles();
        if (kids == null) {
            return;
        }
        for (File k : kids) {
            String name = k.getName();
            String rel = prefix + name;
            if (k.isDirectory()) {
                if (depth < 3 && !name.equals("__pycache__") && !name.equals("libs")) {
                    collect(k, rel + "/", depth + 1, out);
                }
            } else if (!isHidden(rel) && !name.endsWith(".pyc")) {
                out.add(rel);
            }
        }
    }

    static boolean isTextName(String n) {
        n = n.toLowerCase(Locale.ROOT);
        String[] ok = {".py", ".txt", ".json", ".env", ".md", ".yml", ".yaml", ".csv", ".ini", ".toml", ".cfg"};
        for (String e : ok) {
            if (n.endsWith(e)) {
                return true;
            }
        }
        return false;
    }

    /** Copia binaria uri -> archivo. */
    static boolean copyFromUri(Context c, Uri uri, File dest) {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = c.getContentResolver().openInputStream(uri);
            if (in == null) {
                return false;
            }
            File p = dest.getParentFile();
            if (p != null && !p.exists()) {
                p.mkdirs();
            }
            out = new FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    /**
     * Extrae un zip dentro de destDir. Evita rutas peligrosas (zip-slip), ignora __MACOSX y los
     * archivos internos del host, quita la carpeta raiz si todo viene dentro de una sola, y corta
     * si pasa de 100 MB. Devuelve cuantos archivos extrajo, o -1 si fallo.
     */
    static int unzip(File zip, File destDir) {
        java.util.zip.ZipFile zf = null;
        try {
            zf = new java.util.zip.ZipFile(zip);
            String common = null;
            boolean single = true;
            java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName().replace('\\', '/');
                if (n.startsWith("__MACOSX/")) {
                    continue;
                }
                int i = n.indexOf('/');
                if (i < 0) {
                    single = false;
                    break;
                }
                String top = n.substring(0, i + 1);
                if (common == null) {
                    common = top;
                } else if (!common.equals(top)) {
                    single = false;
                    break;
                }
            }
            String strip = (single && common != null) ? common : "";
            String root = destDir.getCanonicalPath() + File.separator;
            long total = 0;
            int count = 0;
            en = zf.entries();
            while (en.hasMoreElements()) {
                java.util.zip.ZipEntry e = en.nextElement();
                String n = e.getName().replace('\\', '/');
                if (n.startsWith("__MACOSX/") || e.isDirectory()) {
                    continue;
                }
                if (!strip.isEmpty() && n.startsWith(strip)) {
                    n = n.substring(strip.length());
                }
                if (n.isEmpty() || isHidden(n)) {
                    continue;
                }
                File out = new File(destDir, n);
                if (!out.getCanonicalPath().startsWith(root)) {
                    continue;
                }
                File p = out.getParentFile();
                if (p != null && !p.exists()) {
                    p.mkdirs();
                }
                InputStream in = zf.getInputStream(e);
                FileOutputStream fo = new FileOutputStream(out);
                try {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = in.read(buf)) != -1) {
                        total += r;
                        if (total > 100L * 1024 * 1024) {
                            return -1;
                        }
                        fo.write(buf, 0, r);
                    }
                } finally {
                    in.close();
                    fo.close();
                }
                count++;
            }
            return count;
        } catch (IOException e) {
            return -1;
        } finally {
            try {
                if (zf != null) {
                    zf.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    /** Copia binaria archivo -> uri (para exportar). */
    static boolean copyToUri(Context c, File src, Uri uri) {
        InputStream in = null;
        java.io.OutputStream out = null;
        try {
            in = new java.io.FileInputStream(src);
            out = c.getContentResolver().openOutputStream(uri);
            if (out == null) {
                return false;
            }
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    // ---------- estado ----------

    /** Texto corto para la notificacion. */
    static String shortStatus(Context c, Bot b) {
        JSONObject hb = heartbeat(c, b.id);
        if (hb == null) {
            return "Iniciando…";
        }
        if (!hb.optBoolean("ready")) {
            return "Conectando…";
        }
        String s = "En línea · " + hb.optInt("guilds", 0) + " servidores";
        int ping = hb.optInt("ping", -1);
        if (ping >= 0) {
            s += " · " + ping + " ms";
        }
        s += " · " + Math.round(hb.optDouble("mem", 0)) + " MB";
        return s;
    }

    /** Latido escrito por Python cada 3 s; null si no hay o esta viejo. */
    static JSONObject heartbeat(Context c, String id) {
        File f = heartbeatFile(c, id);
        if (!f.exists()) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(readText(f));
            double age = System.currentTimeMillis() / 1000.0 - o.optDouble("t", 0);
            double limit = Math.max(12, 2 * o.optInt("interval", 3) + 4);
            return age < limit ? o : null;
        } catch (Exception e) {
            return null;
        }
    }

    static boolean starting(Context c, Bot b) {
        File sf = slotFile(c, b.slot);
        return sf.exists()
                && System.currentTimeMillis() - sf.lastModified() < 45000
                && readText(sf).trim().equals(b.id);
    }

    static boolean isActive(Context c, Bot b) {
        return heartbeat(c, b.id) != null || starting(c, b);
    }

    static String statusText(Context c, Bot b) {
        JSONObject hb = heartbeat(c, b.id);
        if (hb != null) {
            boolean ready = hb.optBoolean("ready");
            StringBuilder sb = new StringBuilder(ready ? "● En línea" : "◐ Conectando…");
            if (ready) {
                String user = hb.optString("user", "");
                if (!user.isEmpty()) {
                    sb.append(" · ").append(user);
                }
                sb.append(" · ").append(hb.optInt("guilds", 0)).append(" servidores");
                int ping = hb.optInt("ping", -1);
                if (ping >= 0) {
                    sb.append(" · ").append(ping).append(" ms");
                }
            }
            sb.append("\nRAM ").append(Math.round(hb.optDouble("mem", 0))).append(" MB");
            sb.append(" · CPU ").append(Math.round(hb.optDouble("cpu", 0))).append("%");
            long up = (long) (System.currentTimeMillis() / 1000.0 - hb.optDouble("started", 0));
            sb.append(" · activo ").append(fmtDur(Math.max(0, up)));
            return sb.toString();
        }
        if (starting(c, b)) {
            return "◐ Iniciando…";
        }
        return "○ Detenido";
    }

    static String fmtDur(long s) {
        if (s < 60) {
            return s + "s";
        }
        if (s < 3600) {
            return (s / 60) + "m";
        }
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }

    // ---------- metricas, despliegue y deteccion ----------

    static JSONObject readJson(File f) {
        if (f == null || !f.exists()) {
            return null;
        }
        try {
            return new JSONObject(readText(f));
        } catch (Exception e) {
            return null;
        }
    }

    /** Historial (RAM, CPU, ping, eventos/min) que escribe host.py cada ~5 s. */
    static JSONObject metrics(Context c, String id) {
        return readJson(new File(dir(c, id), "metrics.json"));
    }

    /** Contadores persistentes: inicios, reinicios, caidas, ultimo motivo. */
    static JSONObject stats(Context c, String id) {
        return readJson(new File(dir(c, id), "stats.json"));
    }

    static JSONObject deploy(Context c, String id) {
        return readJson(new File(dir(c, id), "deploy.json"));
    }

    static String deploySha(Context c, String id) {
        JSONObject o = deploy(c, id);
        return o == null ? "" : o.optString("sha", "");
    }

    static void writeDeploy(Context c, String id, String repo, String ref, String sha) {
        try {
            JSONObject o = new JSONObject();
            o.put("repo", repo);
            o.put("ref", ref);
            o.put("sha", sha == null ? "" : sha);
            o.put("t", System.currentTimeMillis() / 1000.0);
            writeText(new File(dir(c, id), "deploy.json"), o.toString());
        } catch (JSONException ignored) {
            // no deberia pasar
        }
    }

    static long folderSize(File f) {
        if (f == null) {
            return 0;
        }
        if (f.isFile()) {
            return f.length();
        }
        long t = 0;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                t += folderSize(k);
            }
        }
        return t;
    }

    /** Nombre de la carpeta raiz de un zip (p. ej. "usuario-repo-abc1234"), o "". */
    static String zipTopDir(File zip) {
        java.util.zip.ZipFile zf = null;
        try {
            zf = new java.util.zip.ZipFile(zip);
            java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zf.entries();
            if (en.hasMoreElements()) {
                String n = en.nextElement().getName().replace('\\', '/');
                int i = n.indexOf('/');
                return i > 0 ? n.substring(0, i) : "";
            }
        } catch (IOException ignored) {
            // sin dato
        } finally {
            try {
                if (zf != null) {
                    zf.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
        return "";
    }

    /** Busca el archivo que arranca el bot. Devuelve su ruta relativa o null. */
    static String detectEntry(Context c, String id) {
        File root = dir(c, id);
        String[] names = {"main.py", "bot.py", "app.py", "run.py", "start.py", "index.py",
                "launcher.py", "__main__.py"};
        for (String n : names) {
            File f = new File(root, n);
            if (f.isFile() && f.length() > 0) {
                return n;
            }
        }
        File[] kids = root.listFiles();
        if (kids == null) {
            return null;
        }
        Arrays.sort(kids);
        for (File k : kids) {
            if (k.isFile() && k.getName().endsWith(".py") && k.length() < 1024 * 1024) {
                String t = readText(k);
                if (t.contains("discord") && (t.contains(".run(") || t.contains(".start("))) {
                    return k.getName();
                }
            }
        }
        for (File k : kids) {
            String dn = k.getName();
            if (!k.isDirectory() || dn.equals("libs") || dn.equals("__pycache__") || dn.startsWith(".")) {
                continue;
            }
            for (String n : names) {
                File f = new File(k, n);
                if (f.isFile() && f.length() > 0) {
                    return dn + "/" + n;
                }
            }
        }
        return null;
    }

    /** Variables de .env.example como lineas comentadas (el usuario las activa). */
    static String envFromExample(Context c, String id) {
        String[] names = {".env.example", ".env.sample", ".env.template", "example.env", "sample.env"};
        for (String n : names) {
            File f = new File(dir(c, id), n);
            if (!f.isFile()) {
                continue;
            }
            StringBuilder sb = new StringBuilder();
            for (String line : readText(f).split("\r?\n")) {
                String t = line.trim();
                if (t.startsWith("export ")) {
                    t = t.substring(7).trim();
                }
                if (t.isEmpty() || t.startsWith("#") || !t.contains("=")) {
                    continue;
                }
                sb.append("# ").append(t).append('\n');
            }
            if (sb.length() > 0) {
                return "# Variables sugeridas por " + n + " (quita el # y completa lo necesario):\n"
                        + sb;
            }
        }
        return "";
    }

    // ---------- archivos ----------

    static String readText(File f) {
        return readTail(f, 4 * 1024 * 1024);
    }

    static String readTail(File f, int maxBytes) {
        if (f == null || !f.exists()) {
            return "";
        }
        RandomAccessFile r = null;
        try {
            r = new RandomAccessFile(f, "r");
            long len = r.length();
            long start = Math.max(0L, len - (long) maxBytes);
            r.seek(start);
            byte[] buf = new byte[(int) (len - start)];
            r.readFully(buf);
            String s = new String(buf, StandardCharsets.UTF_8);
            if (start > 0) {
                int nl = s.indexOf('\n');
                if (nl >= 0) {
                    s = s.substring(nl + 1);
                }
            }
            return s;
        } catch (IOException e) {
            return "";
        } finally {
            if (r != null) {
                try {
                    r.close();
                } catch (IOException ignored) {
                    // nada
                }
            }
        }
    }

    static void writeText(File f, String s) {
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) {
                p.mkdirs();
            }
            FileOutputStream o = new FileOutputStream(f);
            try {
                o.write(s.getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
            // sin espacio o sin permisos: no hay mucho que hacer
        }
    }

    static void appendLog(Context c, String id, String msg) {
        try {
            String line = new SimpleDateFormat("HH:mm:ss ", Locale.US).format(new Date()) + msg + "\n";
            FileOutputStream o = new FileOutputStream(logFile(c, id), true);
            try {
                o.write(line.getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
            // nada
        }
    }
}
