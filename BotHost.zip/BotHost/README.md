# Bot Host

App Android para hostear bots de Discord en Python (discord.py) directamente en el celular.
Python viene embebido con Chaquopy; cada bot corre en su propio proceso.

## Incluido
discord.py (con aiohttp), requests, python-dotenv, aiosqlite, pytz, tzdata, aiofiles, python-dateutil, beautifulsoup4.
Para agregar más librerías edita `app/build.gradle` (bloque `pip { install "paquete" }`).
Solo funcionan paquetes puros de Python o que Chaquopy ya tenga compilados para Android.

## Cómo usarla
1. Instala el APK y acepta las notificaciones.
2. Toca **Ahorro de batería** y elige **Sin restricciones** (si no, Android puede cerrar los bots).
3. **Desde GitHub** (lo más rápido, ver abajo), o **+ Nuevo bot** (trae un ejemplo con `!ping`), o **Importar .py** con tu archivo.
4. Dentro del bot pega el **token**; en el código léelo con `os.getenv("DISCORD_TOKEN")` (también llega como `TOKEN`, `BOT_TOKEN` y `DISCORD_BOT_TOKEN`).
5. **Iniciar**. Verás estado, servidores, ping, RAM y logs en vivo (también en la notificación).
6. **Archivos del bot**: agrega cogs, .json, etc. (puedes usar subcarpetas como `cogs/musica.py`), edítalos, expórtalos o bórralos.
7. **Iniciar todos / Detener todos** desde la pantalla principal; **Compartir** envía el log por cualquier app.

## Novedades 1.6

### Bot solo con el repositorio
**Desde GitHub** pide el repo (`usuario/repo` o la URL completa, también `.../tree/rama`), y opcionalmente rama, token de Discord y token de GitHub (repos privados). La app:
1. descarga el repo (si dejas la rama vacía usa la rama por defecto, sea `main`, `master`…),
2. **detecta el archivo principal** (`main.py`, `bot.py`, `app.py`…, incluso dentro de una subcarpeta como `src/main.py`),
3. instala `requirements.txt` (solo Python puro, como siempre) y deja las variables de `.env.example` como líneas comentadas en *Variables de entorno*,
4. lo inicia si ya le diste el token.

Con **Actualizar desde el repo cada vez que inicie** (activo por defecto en estos bots) cada arranque consulta el último commit y solo descarga si cambió. También ocurre tras un reinicio automático. El commit instalado aparece en *Avanzado* y en *Métricas*. El archivo principal se puede cambiar a mano en *Avanzado > Arranque*.

### Pestaña Métricas
- **En vivo:** cuenta, servidores, usuarios, canales, conexiones de voz, ping (actual, promedio, mín y máx).
- **Recursos:** RAM (actual y pico), CPU (% de un núcleo), hilos, tráfico de red de la app, tamaño de la carpeta del bot.
- **Actividad:** tiempo activo, mensajes, comandos y errores vistos, eventos por minuto, inicios / reinicios / caídas y el motivo de la última caída y del último reinicio.
- **Teléfono:** batería, temperatura, RAM libre, almacenamiento libre.
- **Gráficas** de RAM, CPU, ping y eventos (últimos ~10 min) con la línea de tu límite.

Notas: la RAM es la del proceso completo del bot (Python + Java). La red es la de **toda la app** (todos los bots comparten UID en Android). La CPU puede pasar de 100 % si el bot usa varios núcleos.

### Rendimiento y límites (editable)
En la misma pestaña, todo por bot y con **0 = sin límite**:
- **Límites de RAM, CPU y ping** y cuánto tiempo deben superarse de forma sostenida. Siempre avisan por el webhook; para RAM y CPU puedes activar **reiniciar el bot**, que mata y relanza el proceso (libera la RAM de verdad). Freno anti-bucle: tras 3 reinicios por límite en 30 min solo avisa. El ping nunca reinicia (reiniciar no arregla la red).
- **Reinicio programado** cada N horas y **liberar memoria** (`gc`) cada N minutos.
- **Intervalo de medición** (2–10 s) y **prioridad de CPU** (normal / baja / muy baja).
- **WakeLock de CPU** y **Wi-Fi de alto rendimiento** (apagarlos ahorra batería pero el bot puede pausarse con la pantalla apagada).
- Perfiles rápidos **Ahorro / Equilibrado / Máximo**.

Límites e intervalo se aplican al instante; prioridad, WakeLock y Wi-Fi al reiniciar el bot.

## Diseño (1.4)
Fondo **aurora** animado (manchas de colores con degradado suave que se mueven despacio; se detiene en ahorro de batería o con las animaciones del sistema desactivadas), título arcoíris, tarjetas y botones de cristal e ícono nuevo.

## Pantalla del bot (1.3)
Cinco pestañas (desde 1.6): **Ajustes** (cuenta, variables, comportamiento), **Archivos** (gestor integrado: toca un archivo para editarlo, ⋮ para exportar/eliminar/extraer), **Logs**, **Métricas** (ver arriba) y **Avanzado** (alertas, GitHub, archivo principal, respaldo, eliminar). El nombre, estado y botones Iniciar/Reiniciar siempre están visibles arriba.

## Novedades 1.2
- **Alertas:** pega un webhook de Discord en el bot y te avisa al iniciar, si se cae, se reinicia o se detiene por un error fatal.
- **Watchdog:** si el bot lleva 10 min sin conexión a Discord (y el auto-reinicio está activo), se reinicia solo.
- **Actualizar desde GitHub:** repo + rama (+ `.zip` opcional dentro del repo) + token de solo lectura para repos privados. Descarga, extrae y reinicia el bot si estaba corriendo.
- **Exportar/Importar bot completo:** un zip con código, datos, token y ajustes. Contiene el token: guárdalo en privado.

## Compilar
- Android Studio: abre la carpeta y *Build > Build APK(s)*.
- GitHub: sube el proyecto; `.github/workflows/build.yml` compila y deja el APK en *Actions > Artifacts*.
  Para poder actualizar encima de versiones anteriores, guarda tu keystore en base64 en el secret `KEYSTORE_BASE64`.

## Notas
- Si falta un módulo, el log lo explica y el bot se detiene (reiniciar no lo arreglaría). Lo mismo con token inválido, intents privilegiados sin activar o errores de sintaxis.
- **requirements.txt:** crea ese archivo en *Archivos del bot > Nuevo archivo* y, con la opción "Instalar requirements.txt al iniciar" activa, la app descarga de PyPI lo que falte (con sus dependencias) a `libs/` del bot antes de arrancar. Solo se reinstala si el archivo cambia (o con "Reinstalar dependencias").
- **Límite:** únicamente paquetes de **Python puro**. Los que traen código nativo (numpy, pillow, pynacl, cryptography…) no se pueden instalar así: el log lo indica y hay que agregarlos en `app/build.gradle` si Chaquopy los ofrece. Líneas como `-r otro.txt`, `git+https://…` o URLs se ignoran.
- También puedes copiar a mano paquetes de Python puro en `libs/` (ya está en `sys.path`).
- Los bots marcados con "Iniciar cuando se encienda el celular" también se reinician tras actualizar la app.
- Máximo 4 bots a la vez (un proceso por bot). Para más, agrega clases `S4`, `S5`… en `BotService.java` y su `<service>` en el manifest.
- Usa `bot.run(TOKEN)` o `asyncio.run(...)` con `bot.start(...)`; ambos se detienen limpio.
- El token también queda como `TOKEN` y `BOT_TOKEN`; las variables del bot se cargan en `os.environ`.
- **Música (opcional, experimental):** discord.py 2.7 exige `davey` (DAVE), PyNaCl, libopus y ffmpeg. Ninguno viene en el APK por defecto. Para activarla:
  1. En GitHub: *Actions > Music libs (davey + libopus + ffmpeg) > Run workflow* (una sola vez). Compila `davey` con el NDK, compila libopus, descarga un ffmpeg arm64 y lo guarda todo en el repo (`app/wheels/` y `app/src/main/jniLibs/arm64-v8a/`).
  2. Compila la app como siempre: `build.gradle` detecta esos archivos y activa PyNaCl + la música solas. Con música activa la app queda solo en **arm64** (+~30 MB).
  3. Al iniciar el bot verás `[music] ffmpeg listo`, `[music] libopus cargada` y `[music] davey (DAVE) disponible` en el log.
  - Las URLs http(s) que el bot pase a `FFmpegPCMAudio` se descargan con Python y se entregan a ffmpeg por stdin (el ffmpeg estático no resuelve DNS en Android). Formatos por streaming (HLS/DASH manifest) no funcionan por ese camino.
  - Licencias: ver `THIRD_PARTY.md` (el ffmpeg incluido es GPL).
