import importlib.util
import os
import tempfile
import threading
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).parents[1] / "app" / "src" / "main" / "python" / "vesper_runtime.py"
spec = importlib.util.spec_from_file_location("vesper_runtime", MODULE_PATH)
vesper_runtime = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(vesper_runtime)


class VesperRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project_dir = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_captures_stdout(self):
        result = vesper_runtime.run_code("print('hello')", str(self.project_dir))
        self.assertEqual(result, "hello")

    def test_imports_local_package_from_project_directory(self):
        package_dir = self.project_dir / "bot"
        package_dir.mkdir()
        (package_dir / "__init__.py").write_text("", encoding="utf-8")
        (package_dir / "consola.py").write_text("value = 'module-loaded'\n", encoding="utf-8")
        result = vesper_runtime.run_code(
            "from bot import consola\nprint(consola.value)", str(self.project_dir), "main_2.py"
        )
        self.assertEqual(result, "module-loaded")

    def test_imports_local_package_from_nested_project_directory(self):
        package_dir = self.project_dir / "src" / "bot"
        package_dir.mkdir(parents=True)
        (package_dir / "__init__.py").write_text("", encoding="utf-8")
        (package_dir / "consola.py").write_text("value = 'nested-module-loaded'\n", encoding="utf-8")
        result = vesper_runtime.run_code(
            "from bot import consola\nprint(consola.value)", str(self.project_dir), "main_2.py"
        )
        self.assertEqual(result, "nested-module-loaded")

    def test_namespace_packages_do_not_leak_between_projects(self):
        import tempfile
        other = tempfile.TemporaryDirectory()
        try:
            first_root = Path(self.temp.name) / "first"
            second_root = Path(other.name) / "second"
            first_pkg = first_root / "namespace_bot"
            second_pkg = second_root / "namespace_bot"
            first_pkg.mkdir(parents=True)
            second_pkg.mkdir(parents=True)
            (first_pkg / "feature.py").write_text("value = 'first'\n", encoding="utf-8")
            (second_pkg / "feature.py").write_text("value = 'second'\n", encoding="utf-8")
            first = vesper_runtime.run_code(
                "import namespace_bot.feature\nprint(namespace_bot.feature.value)", str(first_root)
            )
            second = vesper_runtime.run_code(
                "import namespace_bot.feature\nprint(namespace_bot.feature.value)", str(second_root)
            )
            self.assertEqual(first, "first")
            self.assertEqual(second, "second")
        finally:
            other.cleanup()

    def test_missing_module_explains_android_dependency_limit(self):
        result = vesper_runtime.run_code("import vesper_nonexistent_dependency_xyz", str(self.project_dir))
        self.assertIn("ModuleNotFoundError", result)
        self.assertIn("app/requirements.txt", result)
        self.assertIn("rebuild", result)

    def test_captures_exception_traceback(self):
        result = vesper_runtime.run_code("raise ValueError('bad input')", str(self.project_dir))
        self.assertIn("ValueError: bad input", result)

    def test_reports_empty_output(self):
        result = vesper_runtime.run_code("x = 1", str(self.project_dir))
        self.assertEqual(result, "Script completed with no output.")

    def test_restores_working_directory(self):
        before = os.getcwd()
        vesper_runtime.run_code("import os\nos.chdir('/')", str(self.project_dir))
        self.assertEqual(os.getcwd(), before)

    def test_traceback_uses_selected_filename(self):
        result = vesper_runtime.run_code("raise RuntimeError('failure')", str(self.project_dir), "worker.py")
        self.assertIn("worker.py", result)

    def test_rejects_windows_path_filename(self):
        with self.assertRaises(ValueError):
            vesper_runtime.run_code("pass", str(self.project_dir), r"..\outside.py")

    def test_accepts_system_exit_without_killing_host(self):
        result = vesper_runtime.run_code("raise SystemExit(2)", str(self.project_dir))
        self.assertIn("SystemExit: 2", result)

    def test_tiny_output_limit_stays_bounded(self):
        result = vesper_runtime.run_code("print('lots of output')", str(self.project_dir), max_output_chars=8)
        self.assertLessEqual(len(result), 8)

    def test_rejects_path_traversal_filename(self):
        with self.assertRaises(ValueError):
            vesper_runtime.run_code("pass", str(self.project_dir), "../outside.py")

    def test_rejects_missing_project_directory(self):
        with self.assertRaises(NotADirectoryError):
            vesper_runtime.run_code("pass", str(self.project_dir / "missing"))

    def test_live_log_sidecar_receives_output_before_script_finishes(self):
        import time
        log_file = self.project_dir / "live.log"
        finished = threading.Event()
        result = {}

        def run_script():
            result["value"] = vesper_runtime.run_code(
                "import time\nprint('visible-now')\ntime.sleep(0.35)\nprint('done')",
                str(self.project_dir), "live.py", str(log_file)
            )
            finished.set()

        worker = threading.Thread(target=run_script)
        worker.start()
        deadline = time.monotonic() + 0.25
        observed_early = False
        while time.monotonic() < deadline:
            if log_file.exists() and "visible-now" in log_file.read_text(encoding="utf-8"):
                observed_early = not finished.is_set()
                break
            time.sleep(0.01)
        worker.join(timeout=2)
        self.assertFalse(worker.is_alive())
        self.assertTrue(observed_early, "live log should be flushed before a long script ends")
        self.assertEqual(result["value"], "visible-now\ndone")
        self.assertIn("done", log_file.read_text(encoding="utf-8"))

    def test_request_stop_cooperatively_stops_python_loop(self):
        result = {}
        started = threading.Event()

        def run_forever():
            started.set()
            result["value"] = vesper_runtime.run_code(
                "import time\nwhile True:\n    time.sleep(0.001)", str(self.project_dir), "loop.py"
            )

        worker = threading.Thread(target=run_forever)
        worker.start()
        self.assertTrue(started.wait(timeout=1))
        # Wait briefly so run_code has entered the interpreter, then request stop.
        import time
        time.sleep(0.05)
        vesper_runtime.request_stop()
        worker.join(timeout=3)
        self.assertFalse(worker.is_alive(), "runner did not respond to cooperative stop")
        self.assertIn("[Execution stopped by user]", result["value"])

    def test_stop_request_does_not_leak_to_next_script(self):
        vesper_runtime.request_stop()
        # Starting a new run clears stale stop state by contract.
        result = vesper_runtime.run_code("print('ok')", str(self.project_dir))
        self.assertEqual(result, "ok")

    def test_concurrent_calls_are_serialized(self):
        results = {}
        barrier = threading.Barrier(3)

        def run(label):
            barrier.wait()
            results[label] = vesper_runtime.run_code(
                f"import time\nprint('{label}-start')\ntime.sleep(0.03)\nprint('{label}-end')",
                str(self.project_dir),
            )

        a = threading.Thread(target=run, args=("A",))
        b = threading.Thread(target=run, args=("B",))
        a.start(); b.start(); barrier.wait()
        a.join(timeout=2); b.join(timeout=2)
        self.assertFalse(a.is_alive())
        self.assertFalse(b.is_alive())
        self.assertEqual(results["A"], "A-start\nA-end")
        self.assertEqual(results["B"], "B-start\nB-end")

    def test_output_is_bounded(self):
        result = vesper_runtime.run_code("print('x' * 5000)", str(self.project_dir), max_output_chars=120)
        self.assertLessEqual(len(result), 120)
        self.assertIn("output truncated", result)

    def test_project_env_is_available_only_during_execution(self):
        env_file = self.project_dir / ".env"
        env_file.write_text('DISCORD_TOKEN="test.secret.value"\nCUSTOM_LABEL=hello # comment\n', encoding="utf-8")
        os.environ.pop("DISCORD_TOKEN", None)
        result = vesper_runtime.run_code(
            "import os\nprint(os.environ['DISCORD_TOKEN'] + ':' + os.environ['CUSTOM_LABEL'])",
            str(self.project_dir),
        )
        self.assertEqual(result, "test.secret.value:hello")
        self.assertNotIn("DISCORD_TOKEN", os.environ)
        self.assertNotIn("CUSTOM_LABEL", os.environ)

    def test_project_env_restores_preexisting_environment_value(self):
        env_file = self.project_dir / ".env"
        env_file.write_text("VSP_TEST_SECRET=from-file\n", encoding="utf-8")
        os.environ["VSP_TEST_SECRET"] = "from-host"
        try:
            result = vesper_runtime.run_code("import os\nprint(os.environ['VSP_TEST_SECRET'])", str(self.project_dir))
            self.assertEqual(result, "from-file")
            self.assertEqual(os.environ["VSP_TEST_SECRET"], "from-host")
        finally:
            os.environ.pop("VSP_TEST_SECRET", None)

    def test_json_escaped_project_env_values_round_trip(self):
        env_file = self.project_dir / ".env"
        expected = "tabs\t unicode-é slash\\tail"
        import json
        env_file.write_text("CUSTOM_VALUE=" + json.dumps(expected, ensure_ascii=False) + "\n", encoding="utf-8")
        result = vesper_runtime.run_code("import os\nprint(repr(os.environ['CUSTOM_VALUE']))", str(self.project_dir))
        self.assertEqual(result.strip(), repr(expected))
        self.assertNotIn("CUSTOM_VALUE", os.environ)

    def test_project_env_rejects_malformed_lines_without_executing_shell(self):
        (self.project_dir / ".env").write_text("DISCORD_TOKEN=ok\nBAD LINE\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            vesper_runtime.run_code("print('should not run')", str(self.project_dir))

    def test_project_env_rejects_oversized_file(self):
        (self.project_dir / ".env").write_text("A=" + "x" * (64 * 1024), encoding="utf-8")
        with self.assertRaises(ValueError):
            vesper_runtime.run_code("print('should not run')", str(self.project_dir))


if __name__ == "__main__":
    unittest.main()
