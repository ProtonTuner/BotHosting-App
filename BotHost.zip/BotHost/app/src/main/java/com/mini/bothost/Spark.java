package com.mini.bothost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.View;

/**
 * Mini-gráfica de línea con relleno, etiqueta de valor actual, máximo del periodo y una línea
 * punteada opcional para el límite configurado. Los valores negativos se tratan como "sin dato".
 */
final class Spark extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint();
    private final Paint limitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path area = new Path();

    private final String title;
    private final String unit;
    private final int color;
    private double[] data = new double[0];
    private double limit = 0;
    private int stepSecs = 5;

    Spark(Context c, String title, String unit, int color) {
        super(c);
        this.title = title;
        this.unit = unit;
        this.color = color;
        float d = c.getResources().getDisplayMetrics().density;
        line.setColor(color);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2f * d);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setColor(color);
        fill.setAlpha(45);
        fill.setStyle(Paint.Style.FILL);
        grid.setColor(0x22FFFFFF);
        grid.setStrokeWidth(1f);
        limitPaint.setColor(0xFFFF6B6B);
        limitPaint.setStyle(Paint.Style.STROKE);
        limitPaint.setStrokeWidth(1.5f * d);
        limitPaint.setPathEffect(new DashPathEffect(new float[]{8f * d, 6f * d}, 0));
        txt.setColor(Ui.TXT);
        txt.setTextSize(13f * d);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt2.setColor(Ui.TXT2);
        txt2.setTextSize(11f * d);
        setMinimumHeight(Ui.dp(c, 96));
    }

    void set(double[] values, double limitValue, int step) {
        data = values == null ? new double[0] : values;
        limit = limitValue;
        stepSecs = Math.max(1, step);
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int hh = Ui.dp(getContext(), 96);
        setMeasuredDimension(resolveSize(getSuggestedMinimumWidth(), w), resolveSize(hh, h));
    }

    private static String fmt(double v) {
        return v >= 100 ? String.valueOf(Math.round(v)) : String.format(java.util.Locale.US, "%.1f", v);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float d = getResources().getDisplayMetrics().density;
        float w = getWidth();
        float h = getHeight();
        float top = 22f * d;
        float bottom = h - 4f * d;
        float left = 2f * d;
        float right = w - 2f * d;

        // última lectura válida y máximo
        double last = -1;
        double max = 0;
        for (double v : data) {
            if (v >= 0) {
                last = v;
                if (v > max) {
                    max = v;
                }
            }
        }
        String head = title + (last >= 0 ? "  " + fmt(last) + " " + unit : "  —");
        cv.drawText(head, left, 15f * d, txt);
        if (data.length > 1) {
            String span = "últimos " + formatSpan((long) (data.length - 1) * stepSecs);
            float tw = txt2.measureText(span);
            cv.drawText(span, right - tw, 15f * d, txt2);
        }

        double top1 = Math.max(max, limit > 0 ? limit * 1.1 : 0);
        if (top1 <= 0) {
            top1 = 1;
        }
        top1 *= 1.1;
        cv.drawLine(left, bottom, right, bottom, grid);
        cv.drawLine(left, (top + bottom) / 2, right, (top + bottom) / 2, grid);

        if (data.length >= 2) {
            float dx = (right - left) / (data.length - 1);
            path.reset();
            area.reset();
            boolean pen = false;
            float lastX = 0;
            for (int i = 0; i < data.length; i++) {
                if (data[i] < 0) {
                    if (pen) {
                        area.lineTo(lastX, bottom);
                        area.close();
                    }
                    pen = false;
                    continue;
                }
                float x = left + dx * i;
                float y = (float) (bottom - (data[i] / top1) * (bottom - top));
                if (!pen) {
                    path.moveTo(x, y);
                    area.moveTo(x, bottom);
                    area.lineTo(x, y);
                    pen = true;
                } else {
                    path.lineTo(x, y);
                    area.lineTo(x, y);
                }
                lastX = x;
            }
            if (pen) {
                area.lineTo(lastX, bottom);
                area.close();
            }
            cv.drawPath(area, fill);
            cv.drawPath(path, line);
        } else {
            String m = "recopilando datos…";
            cv.drawText(m, (w - txt2.measureText(m)) / 2, (top + bottom) / 2 + 4f * d, txt2);
        }

        if (limit > 0) {
            float y = (float) (bottom - (limit / top1) * (bottom - top));
            if (y >= top - 2 && y <= bottom) {
                cv.drawLine(left, y, right, y, limitPaint);
                String l = "límite " + fmt(limit);
                cv.drawText(l, left + 4f * d, Math.max(top + 10f * d, y - 3f * d), txt2);
            }
        }
        if (max > 0) {
            String m = "máx " + fmt(max);
            cv.drawText(m, right - txt2.measureText(m), top + 10f * d, txt2);
        }
    }

    private static String formatSpan(long secs) {
        if (secs < 90) {
            return secs + " s";
        }
        return Math.round(secs / 60.0) + " min";
    }
}
