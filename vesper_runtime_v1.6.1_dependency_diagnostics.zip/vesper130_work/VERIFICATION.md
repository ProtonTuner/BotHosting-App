# Verification — Vesper Runtime 1.6.1

- Host-side Python test suite: run `python -m unittest discover -s tests -v` from the project root.
- Android APK build: not executed in this environment.
- Device execution: not verified on a physical Android device.
- Dependency behavior: dependencies listed in `app/requirements.txt` are bundled by Chaquopy at APK build time. Generic runtime `pip install` is not claimed or implemented because it is not a supported universal installer for this embedded Android Python runtime.
