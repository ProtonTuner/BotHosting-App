# Verification — Vesper Runtime 1.3.0

## Executed in the current environment

- `python -m unittest discover -s tests -v`: **45 tests passed**.
- Python source and test modules compile with desktop Python.
- Android manifest and style XML parse successfully.
- GitHub Actions workflow YAML parses successfully.
- ZIP integrity and required source/project files verified after packaging.
- Static integration checks cover the hosting panel, startup script selection, ZIP import, foreground service, sticky recovery opt-in, explicit-stop state clearing, and version metadata.

## Not executed in the current environment

- Android Gradle `:app:assembleDebug` build (Android SDK/Gradle build environment unavailable here).
- Full Kotlin type-checking against Android/AndroidX/Chaquopy dependencies.
- Installation and execution on a physical Android device/emulator.
- GitHub Actions workflow execution.
- Actual Android service recreation after process reclaim or behavior across OEM battery managers.
- Installation of optional packages such as `discord.py` into Chaquopy; Android compatibility must be confirmed by the build.

## 1.3.0-specific behavior

- Auto-recovery is opt-in and attempts to resume the last saved script only when Android recreates the sticky service with a null intent.
- Explicit Stop and normal script completion clear the persisted desired-running state.
- The panel opens Android battery/background settings; it does not silently change system policy.
- The README documents an optional ADB Doze-whitelist command. This can reduce some battery restrictions but cannot make the app unkillable.
- No boot receiver is included; automatic start after reboot is not implemented.
- Force-stop, low memory, OS policy, and OEM process management may still stop execution. This is not a guarantee of 24/7 hosting.

Host-side tests and static checks are not a substitute for compiling, installing, and testing the APK on Android.
