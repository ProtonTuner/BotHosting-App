"""Embedded Python runner used by Vesper Runtime.

This module is an execution helper, not a security sandbox. Python code entered by
an app user has the same process permissions as the Android application.
"""
from __future__ import annotations

import contextlib
import os
import sys
import traceback
import threading
from pathlib import Path
from typing import Optional, TextIO

DEFAULT_OUTPUT_LIMIT = 100_000
TRUNCATION_MARKER = "\n...[output truncated: limit reached]...\n"
_RUN_LOCK = threading.RLock()
_STOP_EVENT = threading.Event()
# Remember project-origin modules so one imported bot cannot contaminate a later run.
_PROJECT_MODULE_NAMES: set[str] = set()


class RuntimeStopped(Exception):
    """Raised when the user requests cooperative cancellation."""


def request_stop() -> bool:
    """Request that the currently running Python script stop at its next trace event.

    This cannot interrupt a native extension or a blocking system call until it
    returns to Python. Scripts can also deliberately disable tracing, so this is
    a best-effort user stop, not a security boundary.
    """
    _STOP_EVENT.set()
    return True


def _cancel_trace(frame, event, arg):
    if _STOP_EVENT.is_set():
        raise RuntimeStopped("Execution stopped by user")
    return _cancel_trace


_IGNORED_PROJECT_DIRS = {
    ".git", ".gradle", ".idea", ".pytest_cache", "__pycache__",
    ".venv", "venv", "env", "node_modules", "build", "dist",
}


def _project_import_paths(project_path: Path) -> list[str]:
    """Return project-local import paths with the workspace root first.

    ZIPs can contain wrapper folders such as ``src/`` or ``VesperBot/``. This
    makes local packages discoverable even if their directory isn't directly
    beside the chosen startup script. Desktop virtual environments and cache
    directories are skipped because their contents are not Android runtimes.
    """
    root = project_path.resolve()
    paths = [str(root)]
    try:
        for current, directories, _files in os.walk(root):
            directories[:] = sorted(
                name for name in directories
                if name not in _IGNORED_PROJECT_DIRS and not name.startswith(".")
            )
            current_path = Path(current).resolve()
            if current_path != root:
                paths.append(str(current_path))
    except OSError:
        # Keep the known-good root path if a nested directory cannot be read.
        pass
    return list(dict.fromkeys(paths))


def _module_has_project_origin(module: object, project_path: Path) -> bool:
    """Detect regular modules and namespace packages loaded from the workspace."""
    locations = []
    module_file = getattr(module, "__file__", None)
    if isinstance(module_file, (str, os.PathLike)):
        locations.append(module_file)
    module_paths = getattr(module, "__path__", None)
    if module_paths is not None:
        try:
            locations.extend(module_paths)
        except TypeError:
            pass
    root = str(project_path.resolve())
    root_prefix = root + os.sep
    for location in locations:
        try:
            resolved = str(Path(os.fspath(location)).resolve())
            if resolved == root or resolved.startswith(root_prefix):
                return True
        except (OSError, RuntimeError, TypeError, ValueError):
            continue
    return False


def _missing_module_hint(exc: ModuleNotFoundError, project_path: Path) -> str:
    """Explain next steps without assuming every missing import is a pip package."""
    module = getattr(exc, "name", None) or "unknown"
    top_level = module.split(".", 1)[0]
    candidates = (
        project_path / f"{top_level}.py",
        project_path / top_level / "__init__.py",
    )
    local_exists = any(candidate.is_file() for candidate in candidates)
    if local_exists:
        detail = (
            f"The project contains a candidate for '{top_level}', but Python could not load it. "
            "Check the package's internal imports and file names."
        )
    else:
        detail = (
            f"If '{module}' is a third-party dependency, it must be included in "
            "app/requirements.txt in the Android source project and rebuild the APK. "
            "Vesper Runtime cannot install arbitrary pip packages into an already-built APK, "
            "and not every PyPI package supports Android/Chaquopy. If it is your own code, "
            "re-import the complete ZIP with the module or package folder included."
        )
    return f"\n\n[Vesper Runtime import diagnosis] {detail}"


class BoundedTextWriter:
    """Text stream that caps captured output to avoid unbounded StringIO growth."""

    def __init__(self, max_chars: int = DEFAULT_OUTPUT_LIMIT, mirror: Optional[TextIO] = None) -> None:
        if max_chars < 1:
            raise ValueError("max_chars must be positive")
        self.max_chars = max_chars
        self._parts: list[str] = []
        self._length = 0
        self._truncated = False
        self._mirror = mirror
        self._mirror_marker_written = False

    def _mirror_write(self, value: str) -> None:
        if self._mirror is None or not value:
            return
        try:
            self._mirror.write(value)
            self._mirror.flush()
        except (OSError, ValueError):
            # Preserve in-memory execution/output if the device runs out of space
            # or the optional live-log stream becomes unavailable.
            self._mirror = None

    def write(self, value: str) -> int:
        if not isinstance(value, str):
            raise TypeError("write() argument must be str")
        original_length = len(value)
        if self._truncated or not value:
            return original_length

        remaining = self.max_chars - self._length
        if len(value) <= remaining:
            self._parts.append(value)
            self._length += len(value)
            self._mirror_write(value)
        else:
            accepted = value[:max(0, remaining)]
            if accepted:
                self._parts.append(accepted)
                self._length += len(accepted)
                self._mirror_write(accepted)
            self._truncated = True
            if not self._mirror_marker_written:
                self._mirror_write(TRUNCATION_MARKER)
                self._mirror_marker_written = True
        return original_length

    def flush(self) -> None:
        return None

    def getvalue(self) -> str:
        result = "".join(self._parts)
        if self._truncated:
            marker = TRUNCATION_MARKER
            # Keep the total returned result close to the requested output cap.
            result = result[: max(0, self.max_chars - len(marker))] + marker[: self.max_chars]
        return result


def _run_code_unlocked(
    code: str,
    project_dir: str,
    script_name: str = "main.py",
    log_file_path: Optional[str] = None,
    max_output_chars: int = DEFAULT_OUTPUT_LIMIT,
) -> str:
    """Execute Python code and return captured stdout/stderr.

    Args:
        code: Source text to execute.
        project_dir: Existing project directory; used as the process working directory.
        script_name: Python filename shown in tracebacks and as ``__file__``.
        log_file_path: Optional bounded sidecar output log, flushed for live display.
        max_output_chars: Maximum number of characters captured per stream.

    Note: This function changes the interpreter process's working directory and
    redirects stdout/stderr while the script runs. The Android app therefore must
    serialize calls to this function. It is not safe for untrusted scripts.
    """
    if not isinstance(code, str):
        raise TypeError("code must be a string")
    if (not isinstance(script_name, str) or not script_name or
            Path(script_name).name != script_name or "/" in script_name or "\\" in script_name or "\x00" in script_name):
        raise ValueError("script_name must be a simple filename")
    if not script_name.lower().endswith(".py"):
        raise ValueError("script_name must end in .py")

    project_path = Path(project_dir).resolve()
    if not project_path.is_dir():
        raise NotADirectoryError(f"Project directory does not exist: {project_path}")

    log_stream = None
    if log_file_path is not None:
        try:
            log_stream = open(log_file_path, "w", encoding="utf-8")
        except OSError:
            # Execution remains available even if live logging cannot be opened.
            log_stream = None
    stdout = BoundedTextWriter(max_output_chars, log_stream)
    stderr = BoundedTextWriter(max_output_chars, log_stream)
    previous_cwd = os.getcwd()
    previous_sys_path = list(sys.path)
    script_path = str(project_path / script_name)
    namespace = {"__name__": "__main__", "__file__": script_path}
    previous_trace = sys.gettrace()
    try:
        # A prior project may have imported a package with the same name. Clear
        # those project-local modules before starting the next selected script.
        for module_name in tuple(_PROJECT_MODULE_NAMES):
            sys.modules.pop(module_name, None)
        _PROJECT_MODULE_NAMES.clear()
        os.chdir(project_path)
        # Imported ZIPs may wrap code in one or more directories (for example
        # src/bot/). Put the workspace first, then its project subdirectories.
        project_import_paths = _project_import_paths(project_path)
        sys.path[:] = project_import_paths + [
            entry for entry in previous_sys_path if entry not in project_import_paths
        ]
        # A fresh run clears any stop request from the preceding script.
        _STOP_EVENT.clear()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            sys.settrace(_cancel_trace)
            try:
                exec(compile(code, script_path, "exec"), namespace, namespace)
            except RuntimeStopped:
                # Clear before writing the message, otherwise the trace hook would
                # immediately raise again while this cleanup code runs.
                _STOP_EVENT.clear()
                stdout.write("\n[Execution stopped by user]\n")
            except BaseException as exc:
                # Capture syntax/runtime errors, including SystemExit, instead of
                # letting user code accidentally terminate the runner thread.
                try:
                    error_text = traceback.format_exc()
                    if isinstance(exc, ModuleNotFoundError):
                        error_text += _missing_module_hint(exc, project_path)
                    stderr.write(error_text)
                except Exception:
                    pass
            finally:
                sys.settrace(previous_trace)
    finally:
        # Remember modules loaded from this workspace so they can be evicted
        # before the next project runs. Third-party Chaquopy modules are kept.
        for module_name, module in tuple(sys.modules.items()):
            if _module_has_project_origin(module, project_path):
                _PROJECT_MODULE_NAMES.add(module_name)
        sys.settrace(previous_trace)
        _STOP_EVENT.clear()
        sys.path[:] = previous_sys_path
        os.chdir(previous_cwd)
        if log_stream is not None:
            try:
                log_stream.close()
            except OSError:
                pass

    out_text = stdout.getvalue().rstrip("\n")
    err_text = stderr.getvalue().rstrip("\n")
    chunks = [chunk for chunk in (out_text, err_text) if chunk]
    return "\n".join(chunks) if chunks else "Script completed with no output."


def run_code(
    code: str,
    project_dir: str,
    script_name: str = "main.py",
    log_file_path: Optional[str] = None,
    max_output_chars: int = DEFAULT_OUTPUT_LIMIT,
) -> str:
    """Serialize script execution because cwd and stdout/stderr are process-global."""
    with _RUN_LOCK:
        return _run_code_unlocked(code, project_dir, script_name, log_file_path, max_output_chars)
