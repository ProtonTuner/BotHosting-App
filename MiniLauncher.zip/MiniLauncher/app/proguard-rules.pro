# Sin reglas extra: el launcher no usa reflexion ni librerias.
