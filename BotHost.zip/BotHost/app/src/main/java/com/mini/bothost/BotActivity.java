package com.mini.bothost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class BotActivity extends Activity {

    private static final int REQ_ADD_FILE = 21;
    private static final int REQ_EXPORT = 22;
    private static final int REQ_ZIP = 23;
    private static final int REQ_FULL = 24;

    private File pendingExport;

    private String id;
    private Store.Bot bot;
    private boolean deleted;

    private static final int ACCENT = 0xFF4FC3F7;

    private final java.util.ArrayList<View> pages = new java.util.ArrayList<>();
    private final java.util.ArrayList<TextView> tabTitles = new java.util.ArrayList<>();
    private final java.util.ArrayList<View> tabLines = new java.util.ArrayList<>();
    private ScrollView logScroll;
    private LinearLayout fileList;
    private TextView fileInfo;
    private TextView title;
    private EditText name;
    private EditText token;
    private EditText env;
    private CheckBox autoRestart;
    private CheckBox autoStart;
    private CheckBox installReqs;
    private EditText webhook;
    private EditText ghRepo;
    private EditText ghBranch;
    private EditText ghPath;
    private EditText ghToken;
    private TextView status;
    private TextView logView;
    private Button toggle;

    private String lastLog = null;
    private boolean restartPending;
    private long idleSince;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            h.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        id = getIntent().getStringExtra("id");
        bot = id == null ? null : Store.load(this, id);
        if (bot == null) {
            finish();
            return;
        }

        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);
        setContentView(root);
        final int p = Ui.dp(this, 16);
        final int mp = ViewGroup.LayoutParams.MATCH_PARENT;
        final int wc = ViewGroup.LayoutParams.WRAP_CONTENT;

        // --- cabecera fija: nombre, estado y control ---
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(p, p, p, 0);
        title = Ui.text(this, bot.name, 22, Ui.TXT, true);
        head.addView(title);
        status = Ui.text(this, "", 14, Ui.TXT2, false);
        status.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 8));
        head.addView(status);
        LinearLayout ctl = row();
        toggle = Ui.button(this, "Iniciar", v -> {
            if (Store.isActive(BotActivity.this, bot)) {
                BotService.stop(BotActivity.this, bot);
                Ui.toast(BotActivity.this, "Deteniendo…");
            } else {
                saveFields();
                BotService.start(BotActivity.this, bot);
                Ui.toast(BotActivity.this, "Iniciando…");
            }
            refresh();
        });
        ctl.addView(toggle, weight());
        ctl.addView(Ui.button(this, "Reiniciar", v -> {
            saveFields();
            if (Store.isActive(BotActivity.this, bot)) {
                BotService.stop(BotActivity.this, bot);
                restartPending = true;
                idleSince = 0;
                Ui.toast(BotActivity.this, "Reiniciando…");
            } else {
                BotService.start(BotActivity.this, bot);
            }
        }), weight());
        head.addView(ctl);
        root.addView(head);

        // --- barra de pestañas ---
        LinearLayout tabs = row();
        tabs.setPadding(p, Ui.dp(this, 4), p, 0);
        String[] names = {"Ajustes", "Archivos", "Logs", "Avanzado"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView t = Ui.text(this, names[i], 14, Ui.TXT2, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 8));
            View line = new View(this);
            col.addView(t, new LinearLayout.LayoutParams(mp, wc));
            col.addView(line, new LinearLayout.LayoutParams(mp, Ui.dp(this, 3)));
            col.setOnClickListener(v -> selectTab(idx));
            tabs.addView(col, weight());
            tabTitles.add(t);
            tabLines.add(line);
        }
        root.addView(tabs);
        View div = new View(this);
        div.setBackgroundColor(0x22FFFFFF);
        root.addView(div, new LinearLayout.LayoutParams(mp, 1));
        FrameLayout body = new FrameLayout(this);
        root.addView(body, new LinearLayout.LayoutParams(mp, 0, 1f));

        // === pestaña 1: Ajustes ===
        LinearLayout a1 = scrollPage(body);
        LinearLayout c1 = section("Cuenta");
        c1.addView(label("Nombre"));
        name = edit(bot.name, "Nombre del bot", false);
        c1.addView(name);
        c1.addView(label("Token de Discord (llega al código como DISCORD_TOKEN)"));
        token = edit(bot.token, "Pega aquí el token", false);
        token.setTransformationMethod(PasswordTransformationMethod.getInstance());
        c1.addView(token);
        CheckBox show = check("Mostrar token", false);
        show.setOnCheckedChangeListener((b, on) -> token.setTransformationMethod(on
                ? HideReturnsTransformationMethod.getInstance()
                : PasswordTransformationMethod.getInstance()));
        c1.addView(show);
        a1.addView(c1);

        LinearLayout c2 = section("Variables de entorno");
        c2.addView(label("Una por línea: CLAVE=valor"));
        env = edit(bot.env, "PREFIX=!\nOWNER_ID=123456789", true);
        c2.addView(env);
        a1.addView(c2);

        LinearLayout c3 = section("Comportamiento");
        autoRestart = check("Reiniciar automáticamente si se cae", bot.autoRestart);
        c3.addView(autoRestart);
        autoStart = check("Iniciar cuando se encienda el celular", bot.autoStart);
        c3.addView(autoStart);
        installReqs = check("Instalar requirements.txt al iniciar (usa internet)", bot.installReqs);
        c3.addView(installReqs);
        a1.addView(c3);
        addFull(a1, Ui.button(this, "Guardar", v -> {
            saveFields();
            Ui.toast(BotActivity.this, "Guardado. Reinicia el bot para aplicar.");
        }), 16);

        // === pestaña 2: Archivos (gestor integrado) ===
        LinearLayout a2 = scrollPage(body);
        LinearLayout f1 = section("Carpeta del bot");
        fileInfo = Ui.text(this, "", 13, Ui.TXT2, false);
        fileInfo.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        f1.addView(fileInfo);
        LinearLayout fr = row();
        fr.addView(Ui.button(this, "+ Archivo", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_ADD_FILE);
        }), weight());
        fr.addView(Ui.button(this, "+ Zip", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_ZIP);
        }), weight());
        fr.addView(Ui.button(this, "+ Nuevo", v -> newFile()), weight());
        f1.addView(fr);
        LinearLayout fr2 = row();
        fr2.addView(Ui.button(this, "Editar main.py", v -> {
            saveFields();
            startActivity(new Intent(BotActivity.this, CodeActivity.class).putExtra("id", id));
        }), weight());
        fr2.addView(Ui.button(this, "Reinstalar dependencias", v -> {
            Store.wipeLibs(BotActivity.this, id);
            Ui.toast(BotActivity.this, "libs/ borrada. Se reinstalará todo al iniciar el bot");
        }), weight());
        f1.addView(fr2);
        a2.addView(f1);
        fileList = section("Archivos");
        a2.addView(fileList);

        // === pestaña 3: Logs ===
        LinearLayout a3 = new LinearLayout(this);
        a3.setOrientation(LinearLayout.VERTICAL);
        a3.setPadding(p, p, p, p);
        body.addView(a3, new FrameLayout.LayoutParams(mp, mp));
        pages.add(a3);
        LinearLayout r3 = row();
        r3.addView(Ui.button(this, "Copiar", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("log",
                        Store.readTail(Store.logFile(BotActivity.this, id), 200000)));
                Ui.toast(BotActivity.this, "Log copiado");
            }
        }), weight());
        r3.addView(Ui.button(this, "Compartir", v -> {
            Intent s2 = new Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, "Log de " + bot.name)
                    .putExtra(Intent.EXTRA_TEXT,
                            Store.readTail(Store.logFile(BotActivity.this, id), 60000));
            startActivity(Intent.createChooser(s2, "Compartir log"));
        }), weight());
        r3.addView(Ui.button(this, "Limpiar", v -> {
            try {
                new FileOutputStream(Store.logFile(BotActivity.this, id)).close();
            } catch (IOException ignored) {
                // nada
            }
            lastLog = null;
            refresh();
        }), weight());
        a3.addView(r3);
        logView = Ui.text(this, "", 11, 0xFFB0BEC5, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setBackground(Ui.card(this));
        logView.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10));
        logScroll = new ScrollView(this);
        logScroll.addView(logView);
        LinearLayout.LayoutParams lsp = new LinearLayout.LayoutParams(mp, 0, 1f);
        lsp.topMargin = Ui.dp(this, 8);
        a3.addView(logScroll, lsp);

        // === pestaña 4: Avanzado ===
        LinearLayout a4 = scrollPage(body);
        LinearLayout g1 = section("Alertas");
        g1.addView(label("Webhook de Discord (avisa si el bot se cae o se reinicia)"));
        webhook = edit(bot.webhook, "https://discord.com/api/webhooks/…", false);
        g1.addView(webhook);
        a4.addView(g1);

        LinearLayout g2 = section("Actualizar desde GitHub");
        g2.addView(label("Repositorio (usuario/repo)"));
        ghRepo = edit(bot.ghRepo, "usuario/repo", false);
        g2.addView(ghRepo);
        g2.addView(label("Rama"));
        ghBranch = edit(bot.ghBranch, "main", false);
        g2.addView(ghBranch);
        g2.addView(label("Archivo .zip dentro del repo (vacío = todo el repo)"));
        ghPath = edit(bot.ghPath, "mibot.zip", false);
        g2.addView(ghPath);
        g2.addView(label("Token de GitHub (repos privados; solo permiso de lectura)"));
        ghToken = edit(bot.ghToken, "github_pat_…", false);
        ghToken.setTransformationMethod(PasswordTransformationMethod.getInstance());
        g2.addView(ghToken);
        addFull(g2, Ui.button(this, "Actualizar desde GitHub", v -> updateFromGithub()), 12);
        a4.addView(g2);

        LinearLayout g3 = section("Respaldo");
        TextView bk = Ui.text(this, "Un zip con código, datos, token y ajustes para mudar el bot a otro celular.",
                13, Ui.TXT2, false);
        bk.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        g3.addView(bk);
        addFull(g3, Ui.button(this, "Exportar bot completo", v -> exportFullDialog()), 0);
        a4.addView(g3);

        addFull(a4, Ui.button(this, "Eliminar bot", v -> confirmDelete()), 20);

        selectTab(0);
        refreshFiles();
    }

    // ---------- pestañas y gestor de archivos ----------

    private LinearLayout scrollPage(FrameLayout body) {
        ScrollView s = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        l.setPadding(p, Ui.dp(this, 4), p, p);
        s.addView(l);
        body.addView(s, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pages.add(s);
        return l;
    }

    private LinearLayout section(String titleText) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.card(this));
        int p = Ui.dp(this, 12);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        c.setLayoutParams(lp);
        if (titleText != null) {
            c.addView(Ui.text(this, titleText, 16, Ui.TXT, true));
        }
        return c;
    }

    private void addFull(LinearLayout parent, Button b, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, topDp);
        parent.addView(b, lp);
    }

    private void selectTab(int idx) {
        for (int i = 0; i < pages.size(); i++) {
            pages.get(i).setVisibility(i == idx ? View.VISIBLE : View.GONE);
            tabTitles.get(i).setTextColor(i == idx ? ACCENT : Ui.TXT2);
            tabLines.get(i).setBackgroundColor(i == idx ? ACCENT : 0x00000000);
        }
        View f = getCurrentFocus();
        if (f != null) {
            f.clearFocus();
        }
    }

    private static String sizeText(long b) {
        if (b < 1024) {
            return b + " B";
        }
        if (b < 1024 * 1024) {
            return (b / 1024) + " KB";
        }
        return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
    }

    /** Reconstruye la lista de archivos de la pestaña Archivos. */
    private void refreshFiles() {
        if (fileList == null || bot == null) {
            return;
        }
        List<String> files = Store.userFiles(this, id);
        fileList.removeViews(1, fileList.getChildCount() - 1);
        long total = 0;
        for (final String rel : files) {
            File f = Store.resolve(this, id, rel);
            long len = f == null ? 0 : f.length();
            total += len;
            LinearLayout r = row();
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.addView(Ui.text(this, rel, 15, Ui.TXT, false));
            txt.addView(Ui.text(this, sizeText(len), 12, Ui.TXT2, false));
            txt.setOnClickListener(v -> {
                if (Store.isTextName(rel)) {
                    startActivity(new Intent(BotActivity.this, CodeActivity.class)
                            .putExtra("id", id).putExtra("file", rel));
                } else {
                    fileActions(rel);
                }
            });
            r.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView more = Ui.text(this, "⋮", 22, Ui.TXT2, true);
            more.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 8), 0);
            more.setOnClickListener(v -> fileActions(rel));
            r.addView(more);
            View sep = new View(this);
            sep.setBackgroundColor(0x14FFFFFF);
            fileList.addView(sep, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
            fileList.addView(r);
        }
        if (files.isEmpty()) {
            TextView e = Ui.text(this, "(vacía)", 13, Ui.TXT2, false);
            e.setPadding(0, Ui.dp(this, 8), 0, 0);
            fileList.addView(e);
        }
        fileInfo.setText(files.size() + " archivos · " + sizeText(total)
                + "\nToca un archivo para editarlo, o ⋮ para más opciones.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bot != null) {
            h.post(tick);
            refreshFiles();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        if (bot != null && !deleted) {
            saveFields();
        }
    }

    // ---------- logica ----------

    private void saveFields() {
        String n = name.getText().toString().trim();
        if (!n.isEmpty()) {
            bot.name = n;
        }
        bot.token = token.getText().toString().trim();
        bot.env = env.getText().toString();
        bot.autoRestart = autoRestart.isChecked();
        bot.autoStart = autoStart.isChecked();
        bot.installReqs = installReqs.isChecked();
        bot.webhook = webhook.getText().toString().trim();
        bot.ghRepo = ghRepo.getText().toString().trim();
        bot.ghBranch = ghBranch.getText().toString().trim();
        bot.ghPath = ghPath.getText().toString().trim();
        bot.ghToken = ghToken.getText().toString().trim();
        Store.save(this, bot);
    }

    private void refresh() {
        boolean active = Store.isActive(this, bot);
        status.setText(Store.statusText(this, bot));
        title.setText(bot.name);
        toggle.setText(active ? "Detener" : "Iniciar");

        if (restartPending) {
            if (active) {
                idleSince = 0;
            } else if (idleSince == 0) {
                idleSince = System.currentTimeMillis();
            } else if (System.currentTimeMillis() - idleSince >= 1000) {
                restartPending = false;
                BotService.start(this, bot);
            }
        }

        String t = Store.readTail(Store.logFile(this, id), 6000);
        if (!t.equals(lastLog)) {
            boolean atBottom = logScroll.getScrollY() + logScroll.getHeight()
                    >= logView.getHeight() - Ui.dp(this, 80);
            lastLog = t;
            logView.setText(t.isEmpty() ? "(sin logs todavía)" : t);
            if (atBottom) {
                logScroll.post(new Runnable() {
                    @Override
                    public void run() {
                        logScroll.scrollTo(0, logView.getHeight());
                    }
                });
            }
        }
    }

    // ---------- GitHub / exportar ----------

    private void updateFromGithub() {
        saveFields();
        if (bot.ghRepo.isEmpty()) {
            Ui.toast(this, "Escribe el repositorio (usuario/repo)");
            return;
        }
        Ui.toast(this, "Descargando…");
        final Store.Bot b = bot;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String err = GitHub.update(BotActivity.this, b);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshFiles();
                        if (err != null) {
                            Ui.toast(BotActivity.this, err);
                        } else if (Store.isActive(BotActivity.this, b)) {
                            Ui.toast(BotActivity.this, "Actualizado. Reiniciando…");
                            BotService.stop(BotActivity.this, b);
                            restartPending = true;
                            idleSince = 0;
                        } else {
                            Ui.toast(BotActivity.this, "Actualizado. Ya puedes iniciar el bot.");
                        }
                    }
                });
            }
        }).start();
    }

    private void exportFullDialog() {
        saveFields();
        new AlertDialog.Builder(this)
                .setTitle("Exportar bot completo")
                .setMessage("El zip incluye código, datos, token, webhook y variables. "
                        + "Guárdalo en un lugar privado.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Exportar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/zip");
                        i.putExtra(Intent.EXTRA_TITLE,
                                bot.name.replaceAll("[^A-Za-z0-9_.-]", "_") + ".bothost.zip");
                        startActivityForResult(i, REQ_FULL);
                    }
                })
                .show();
    }

    // ---------- archivos extra ----------

    private void newFile() {
        final EditText n = new EditText(this);
        n.setSingleLine(true);
        n.setText("requirements.txt");
        new AlertDialog.Builder(this)
                .setTitle("Nuevo archivo")
                .setMessage("Puedes usar subcarpetas, por ejemplo cogs/musica.py")
                .setView(n)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear y editar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String name = n.getText().toString().trim();
                        File f = Store.resolve(BotActivity.this, id, name);
                        if (f == null) {
                            Ui.toast(BotActivity.this, "Nombre no válido");
                            return;
                        }
                        if (!f.exists()) {
                            Store.writeText(f, "");
                        }
                        startActivity(new Intent(BotActivity.this, CodeActivity.class)
                                .putExtra("id", id).putExtra("file", name));
                    }
                })
                .show();
    }

    private void fileActions(final String rel) {
        final java.util.ArrayList<String> ops = new java.util.ArrayList<>();
        ops.add("Editar");
        ops.add("Exportar");
        if (rel.toLowerCase().endsWith(".zip")) {
            ops.add("Extraer aquí");
        }
        if (!rel.equals("main.py")) {
            ops.add("Eliminar");
        }
        new AlertDialog.Builder(this)
                .setTitle(rel)
                .setItems(ops.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String op = ops.get(which);
                        final File f = Store.resolve(BotActivity.this, id, rel);
                        if (f == null || !f.exists()) {
                            return;
                        }
                        if (op.equals("Editar")) {
                            if (!Store.isTextName(rel)) {
                                Ui.toast(BotActivity.this, "Ese archivo no es de texto");
                                return;
                            }
                            startActivity(new Intent(BotActivity.this, CodeActivity.class)
                                    .putExtra("id", id).putExtra("file", rel));
                        } else if (op.equals("Exportar")) {
                            pendingExport = f;
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("*/*");
                            i.putExtra(Intent.EXTRA_TITLE, f.getName());
                            startActivityForResult(i, REQ_EXPORT);
                        } else if (op.equals("Extraer aquí")) {
                            extractAsync(f, false);
                        } else {
                            f.delete();
                            Ui.toast(BotActivity.this, "Eliminado");
                            refreshFiles();
                        }
                    }
                })
                .show();
    }

    /** Extrae en segundo plano; si temp es true, borra el zip al terminar. */
    private void extractAsync(final File zip, final boolean temp) {
        Ui.toast(this, "Extrayendo…");
        final File dest = Store.dir(this, id);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int n = Store.unzip(zip, dest);
                if (temp) {
                    zip.delete();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Ui.toast(BotActivity.this, n < 0
                                ? "No se pudo extraer (zip dañado o demasiado grande)"
                                : n + " archivos extraídos. Reinicia el bot para aplicar.");
                        refreshFiles();
                    }
                });
            }
        }, "unzip").start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        if (requestCode == REQ_EXPORT && pendingExport != null) {
            boolean ok = Store.copyToUri(this, pendingExport, uri);
            Ui.toast(this, ok ? "Exportado" : "No se pudo exportar");
            pendingExport = null;
        } else if (requestCode == REQ_FULL) {
            Ui.toast(this, "Exportando…");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final boolean ok = Store.exportFull(BotActivity.this, id, uri);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Ui.toast(BotActivity.this, ok ? "Bot exportado" : "No se pudo exportar");
                        }
                    });
                }
            }).start();
        } else if (requestCode == REQ_ZIP) {
            File tmp = new File(getCacheDir(), "import.zip");
            if (Store.copyFromUri(this, uri, tmp)) {
                extractAsync(tmp, true);
            } else {
                Ui.toast(this, "No se pudo leer el zip");
            }
        } else if (requestCode == REQ_ADD_FILE) {
            final EditText n = new EditText(this);
            n.setSingleLine(true);
            n.setText(Ui.fileName(this, uri));
            new AlertDialog.Builder(this)
                    .setTitle("Guardar como")
                    .setMessage("Puedes usar subcarpetas, por ejemplo cogs/musica.py")
                    .setView(n)
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Agregar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int which) {
                            File dest = Store.resolve(BotActivity.this, id, n.getText().toString());
                            if (dest == null) {
                                Ui.toast(BotActivity.this, "Nombre no válido");
                            } else if (Store.copyFromUri(BotActivity.this, uri, dest)) {
                                Ui.toast(BotActivity.this, "Agregado. Reinicia el bot para aplicar.");
                                refreshFiles();
                            } else {
                                Ui.toast(BotActivity.this, "No se pudo copiar el archivo");
                            }
                        }
                    })
                    .show();
        }
    }

    private void confirmDelete() {
        if (Store.isActive(this, bot)) {
            Ui.toast(this, "Detén el bot antes de eliminarlo");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Eliminar “" + bot.name + "”")
                .setMessage("Se borrarán su código, configuración y logs.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        deleted = true;
                        Store.delete(BotActivity.this, id);
                        finish();
                    }
                })
                .show();
    }

    // ---------- helpers de UI ----------

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 13, Ui.TXT2, false);
        t.setPadding(0, Ui.dp(this, 14), 0, 0);
        return t;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(Ui.TXT);
        c.setChecked(on);
        return c;
    }

    private EditText edit(String value, String hint, boolean multiline) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(Ui.TXT);
        e.setHintTextColor(0x66FFFFFF);
        if (multiline) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
        }
        return e;
    }
}
