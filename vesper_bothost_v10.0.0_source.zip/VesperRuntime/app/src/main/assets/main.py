"""Safe first-run script for Vesper BotHost 10.0."""
print("Vesper BotHost 10.0 is ready.")
print("Open Bots to create a Discord bot or import a bot project ZIP.")
