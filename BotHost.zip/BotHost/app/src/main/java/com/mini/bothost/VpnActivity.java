package com.mini.bothost;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Pantalla para pegar/importar la config WireGuard (.conf de Proton VPN u otra) y probarla. */
public class VpnActivity extends Activity {
    private static final int REQ_CONF = 21;
    private static final int REQ_PREP = 22;
    private static final int ACCENT = 0xFF6C8CFF;

    private EditText conf;
    private CheckBox on;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        sv.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, p, p, p);
        sv.addView(root);
        setContentView(Ui.withAurora(this, sv));

        root.addView(Ui.text(this, "VPN (WireGuard / Proton)", 24, Ui.TXT, true));
        TextView info = Ui.text(this,
                "Pega o importa un archivo .conf de WireGuard. En Proton VPN: account.protonvpn.com > "
                        + "Descargas > Configuración WireGuard > Android > Crear y descargar.\n\n"
                        + "La VPN se enciende cuando inicias un bot y se apaga cuando no queda ninguno. "
                        + "Solo afecta a Bot Host: el resto del celular sale como siempre. "
                        + "Una VPN suele aumentar un poco el ping; úsala si necesitas otra IP o ruta.",
                13, Ui.TXT2, false);
        info.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        root.addView(info);

        on = new CheckBox(this);
        on.setText("Usar la VPN mientras haya bots activos");
        on.setTextColor(Ui.TXT);
        on.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        on.setChecked(Vpn.switchOn(this));
        root.addView(on);

        conf = new EditText(this);
        conf.setText(Vpn.config(this));
        conf.setHint("[Interface]\nPrivateKey = ...\nAddress = ...\nDNS = ...\n\n[Peer]\nPublicKey = ...\nAllowedIPs = 0.0.0.0/0\nEndpoint = ...");
        conf.setTextColor(Ui.TXT);
        conf.setHintTextColor(0x66FFFFFF);
        conf.setTypeface(android.graphics.Typeface.MONOSPACE);
        conf.setTextSize(12);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0x33000000);
        bg.setCornerRadius(Ui.dp(this, 12));
        bg.setStroke(Ui.dp(this, 1), 0x33FFFFFF);
        conf.setBackground(bg);
        conf.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        conf.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        conf.setMinLines(10);
        conf.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Ui.dp(this, 8);
        root.addView(conf, clp);

        TextView warn = Ui.text(this,
                "La config incluye tu clave privada: se guarda solo dentro de la app y no se incluye "
                        + "en los exports de bots.", 12, Ui.TXT2, false);
        warn.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        root.addView(warn);

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(Ui.button(this, "Importar .conf", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_CONF);
            }
        }), weight());
        r1.addView(Ui.button(this, "Guardar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (save()) {
                    Ui.toast(VpnActivity.this, "Guardado");
                }
            }
        }), weight());
        root.addView(r1);

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(Ui.button(this, "Probar conexión", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                test();
            }
        }), weight());
        r2.addView(Ui.button(this, "Borrar VPN", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conf.setText("");
                on.setChecked(false);
                Vpn.setConfig(VpnActivity.this, "");
                Vpn.setSwitch(VpnActivity.this, false);
                Vpn.send(VpnActivity.this, VpnControl.A_SYNC, -1);
                setStatus("VPN borrada");
            }
        }), weight());
        root.addView(r2);

        status = Ui.text(this, "", 13, Ui.TXT, false);
        status.setPadding(0, Ui.dp(this, 12), 0, 0);
        root.addView(status);
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    /** Guarda config + interruptor y valida el formato. Devuelve false si la config no sirve. */
    private boolean save() {
        String text = conf.getText().toString();
        Vpn.setConfig(this, text);
        Vpn.setSwitch(this, on.isChecked());
        if (text.trim().isEmpty()) {
            setStatus(on.isChecked() ? "Pega primero una config" : "Sin config");
            return !on.isChecked();
        }
        String err = Vpn.validate(this);
        if (err != null) {
            setStatus("Config no válida: " + err);
            return false;
        }
        setStatus("Config válida.");
        Vpn.send(this, VpnControl.A_SYNC, -1); // por si ya hay bots corriendo
        return true;
    }

    private void test() {
        if (!save()) {
            return;
        }
        if (conf.getText().toString().trim().isEmpty()) {
            return;
        }
        Intent prep = Vpn.consentIntent(this);
        if (prep != null) {
            try {
                startActivityForResult(prep, REQ_PREP);
            } catch (Exception e) {
                setStatus("No se pudo pedir el permiso de VPN");
            }
            return;
        }
        setStatus("Conectando…");
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = Vpn.testUp(app);
                String result;
                if (err != null) {
                    result = "No conectó: " + err;
                } else {
                    result = "VPN conectada. IP pública que ven tus bots: " + publicIp();
                }
                // Si no hay bots activos (o la VPN esta apagada) se baja sola despues de la prueba.
                Vpn.sync(app);
                final String msg = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setStatus(msg);
                    }
                });
            }
        }, "vpn-test").start();
    }

    private static String publicIp() {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL("https://api.ipify.org").openConnection();
            h.setConnectTimeout(8000);
            h.setReadTimeout(8000);
            BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream()));
            try {
                String s = r.readLine();
                return s == null ? "(sin respuesta)" : s.trim();
            } finally {
                r.close();
            }
        } catch (Exception e) {
            return "(no se pudo consultar: " + e.getMessage() + ")";
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PREP) {
            if (resultCode == RESULT_OK) {
                test();
            } else {
                setStatus("Sin permiso de VPN: Android lo necesita para encenderla");
            }
        } else if (requestCode == REQ_CONF && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri uri = data.getData();
            try {
                conf.setText(Ui.readUri(this, uri));
                setStatus("Importado: " + Ui.displayName(this, uri) + ". Toca Guardar.");
            } catch (Exception e) {
                setStatus("No se pudo leer el archivo");
            }
        }
    }
}
