# Vesper BotHost 10.0.0 — Verification report

## Source checks

Run `python -m unittest discover -s tests -v` from the project root. Latest host-side result: **71 tests passed**. The suite covers Python output capture, scoped environment variables, cooperative stop, bounded logs, local imports, dependency manifest validation, bot project creation/import/deletion, token-handling invariants (including case-insensitive secret-file handling), ZIP path limits, Android manifest declarations and source-level BotHost wiring. Python modules also pass `compileall`; all 7 Android XML files parse successfully.

The bot helper is unit-tested using host Python. The Discord service itself has not been run here with real credentials or against Discord's gateway.

## Android build and device checks not completed

- Android Gradle build/APK assembly: not run; no configured Android SDK or Gradle executable/wrapper is available in this environment.
- Kotlin compiler check: the source was submitted to `kotlinc` as a parser check, but compilation stops on unresolved Android/AndroidX/Chaquopy symbols because the Android classpath is unavailable; this is not a successful Kotlin/Android compile.
- Kotlin/Android runtime: not run on emulator or a physical phone.
- Discord gateway connection, slash-command sync and stop/recovery behavior: not run against Discord.
- Chaquopy installation of `discord.py==2.7.1` and the pinned `aiohttp`/`yarl`/`multidict`/`frozenlist` wheel set: must be confirmed by running the GitHub Actions Android build. Chaquopy documents that packages without a matching Android wheel can fail during build.

## Architectural limitations

- One Python runtime slot means only one bot/script is active at a time.
- Foreground service is local and best-effort; no 24/7 uptime promise.
- Python is not sandboxed. A script can read its environment variables, access the app's private files and emit its token if the script author chooses to do so.
- The app-bundled Python dependency set is fixed at APK build time. In-app requirements editing is not a general-purpose runtime installer.
