package com.mini.bothost;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Editor simple del main.py del bot. */
public class CodeActivity extends Activity {

    private static final int REQ_IMPORT = 8;

    private String id;
    private String rel;
    private EditText code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        id = getIntent().getStringExtra("id");
        if (id == null || Store.load(this, id) == null) {
            finish();
            return;
        }

        rel = getIntent().getStringExtra("file");
        if (rel == null || Store.resolve(this, id, rel) == null) {
            rel = "main.py";
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);
        int p = Ui.dp(this, 8);
        root.setPadding(p, p, p, p);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.addView(Ui.button(this, "Guardar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                Ui.toast(CodeActivity.this, "Guardado. Reinicia el bot para aplicar.");
            }
        }), weight());
        bar.addView(Ui.button(this, "Tab", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = Math.max(code.getSelectionStart(), 0);
                code.getText().insert(pos, "    ");
            }
        }), weight());
        bar.addView(Ui.button(this, "Importar .py", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_IMPORT);
            }
        }), weight());
        root.addView(bar);

        TextView title = Ui.text(this, rel, 12, Ui.TXT2, false);
        title.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), 0, Ui.dp(this, 4));
        root.addView(title);

        code = new EditText(this);
        code.setText(Store.readText(Store.resolve(this, id, rel)));
        code.setTypeface(Typeface.MONOSPACE);
        code.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        code.setTextColor(Color.WHITE);
        code.setGravity(Gravity.TOP | Gravity.START);
        code.setHorizontallyScrolling(true);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        code.setBackgroundColor(0xFF1E232A);
        code.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        root.addView(code, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private void save() {
        Store.writeText(Store.resolve(this, id, rel), code.getText().toString());
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (code != null) {
            save(); // autoguardado para no perder cambios
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                code.setText(Ui.readUri(this, uri));
            } catch (Exception e) {
                Ui.toast(this, "No se pudo leer el archivo");
            }
        }
    }
}
