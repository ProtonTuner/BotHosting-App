import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parents[1]
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"


class ProjectIntegrationTests(unittest.TestCase):
    def test_chaquopy_build_reads_requirements_manifest(self):
        gradle = (ROOT / "app" / "build.gradle").read_text(encoding="utf-8")
        self.assertIn("install('-r', 'requirements.txt')", gradle)
        self.assertTrue((ROOT / "app" / "requirements.txt").is_file())

    def test_default_runtime_manifest_matches_build_template(self):
        source = (ROOT / "app" / "requirements.txt").read_text(encoding="utf-8")
        asset = (ROOT / "app" / "src" / "main" / "assets" / "requirements.txt").read_text(encoding="utf-8")
        self.assertEqual(source, asset)

    def test_manifest_has_internet_permission_and_exported_launcher(self):
        manifest_path = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
        tree = ET.parse(manifest_path)
        manifest = tree.getroot()
        permissions = {node.attrib.get(ANDROID_NS + "name") for node in manifest.findall("uses-permission")}
        self.assertIn("android.permission.INTERNET", permissions)
        activity = manifest.find("application/activity")
        self.assertIsNotNone(activity)
        self.assertEqual(activity.attrib.get(ANDROID_NS + "exported"), "true")

    def test_runtime_service_is_non_exported_and_declares_special_use(self):
        manifest_path = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
        tree = ET.parse(manifest_path)
        manifest = tree.getroot()
        permissions = {node.attrib.get(ANDROID_NS + "name") for node in manifest.findall("uses-permission")}
        self.assertIn("android.permission.FOREGROUND_SERVICE", permissions)
        self.assertIn("android.permission.FOREGROUND_SERVICE_SPECIAL_USE", permissions)
        app = manifest.find("application")
        service = app.find("service")
        self.assertIsNotNone(service)
        self.assertEqual(service.attrib.get(ANDROID_NS + "exported"), "false")
        self.assertEqual(service.attrib.get(ANDROID_NS + "foregroundServiceType"), "specialUse")
        service_src = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        self.assertIn("ServiceCompat.startForeground", service_src)
        self.assertIn("ACTION_STOP", service_src)
        self.assertIn("ACTION_QUERY", service_src)
        self.assertIn("startOutputPolling", service_src)
        self.assertIn("EXTRA_OUTPUT_OFFSET", service_src)

    def test_main_activity_has_project_transfer_and_stop_controls(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('makeButton("IMPORT .PY")', source)
        self.assertIn('makeButton("EXPORT .PY")', source)
        self.assertIn('makeButton("STOP")', source)
        self.assertIn("Intent.ACTION_OPEN_DOCUMENT", source)
        self.assertIn("maxImportedProjectBytes", source)

    def test_github_workflow_tests_and_uploads_debug_apk(self):
        workflow = (ROOT / ".github" / "workflows" / "android-apk.yml").read_text(encoding="utf-8")
        self.assertIn("workflow_dispatch:", workflow)
        self.assertIn("python -m unittest discover -s tests -v", workflow)
        self.assertIn("gradle --no-daemon :app:assembleDebug", workflow)
        self.assertIn("actions/upload-artifact@v4", workflow)
        self.assertIn("app/build/outputs/apk/debug/app-debug.apk", workflow)

    def test_activity_guards_lifecycle_after_python_initialization_failure(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("private var runtimeUiInitialized = false", source)
        self.assertIn("if (!runtimeUiInitialized) return", source)
        self.assertIn("runtimeUiInitialized = true", source)

    def test_run_handoff_uses_private_script_file_not_large_intent_payload(self):
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        service = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        self.assertNotIn("EXTRA_CODE", activity)
        self.assertIn("scriptFile.readText(Charsets.UTF_8)", service)
        self.assertIn("MAX_SCRIPT_BYTES", service)
        self.assertIn("content.toByteArray(Charsets.UTF_8).size > maxImportedProjectBytes", activity)

    def test_live_log_uses_byte_ranges_and_utf8_safe_chunks(self):
        service = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("EXTRA_OUTPUT_START_OFFSET", service)
        self.assertIn("completeUtf8PrefixLength", service)
        self.assertIn("endOffset <= lastLogBytesRead", activity)
        self.assertIn("appendMissedRunningOutput(startOffset)", activity)

    def test_version_is_one_point_three(self):
        gradle = (ROOT / "app" / "build.gradle").read_text(encoding="utf-8")
        self.assertIn("versionName '1.3.0'", gradle)
        self.assertIn("versionCode 10300", gradle)

    def test_service_supports_opt_in_sticky_recovery(self):
        service = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("return START_STICKY", service)
        self.assertIn("resumeAfterSystemRestart", service)
        self.assertIn("KEY_DESIRED_RUNNING", service)
        self.assertIn("clearDesiredRun()", service)
        self.assertIn("AUTO-RESTART: ON", activity)
        self.assertIn("BATTERY / BACKGROUND SETTINGS", activity)
        self.assertIn("ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS", activity)

    def test_local_hosting_panel_and_startup_script_controls_exist(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('makeButton("HOSTING PANEL")', source)
        self.assertIn('makeButton("STARTUP SCRIPT")', source)
        self.assertIn('private fun showHostingPanel()', source)
        self.assertIn('private fun chooseStartupScript()', source)
        self.assertIn('putString("startup_script", selected.name)', source)
        self.assertIn('StatFs(filesDir.absolutePath)', source)
        self.assertIn('startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_STOP))', source)

    def test_zip_and_general_file_import_controls_exist(self):
        source = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text()
        self.assertIn('IMPORT ZIP / FILES', source)
        self.assertIn('IMPORTED FILES', source)
        self.assertIn('private fun importZip', source)
        self.assertIn('maxArchiveEntries', source)
        self.assertIn('cleanImportedPath', source)

    def test_in_app_dependency_controls_and_export_flow_exist(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('makeButton("DEPENDENCIES")', source)
        self.assertIn('makeButton("EXPORT REQ.")', source)
        self.assertIn("Intent.ACTION_CREATE_DOCUMENT", source)
        self.assertIn('callAttr("validate_requirements_json", contents)', source)


if __name__ == "__main__":
    unittest.main()
