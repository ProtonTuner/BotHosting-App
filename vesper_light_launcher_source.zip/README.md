# Vesper Light Launcher

Launcher Android independiente y ligero, diseñado como punto de partida para Samsung Galaxy A12 / Android 12.

## Incluye
- Pantalla de inicio configurable como launcher predeterminado de Android.
- Reloj y fecha al abrir la pantalla.
- Búsqueda local de aplicaciones instaladas y cuadrícula de iconos.
- Mantener pulsada una aplicación para abrirla o ir a su información.
- Sin servicios en segundo plano, anuncios, cuentas ni permisos de red.
- Interfaz oscura con acento violeta; implementación nativa sin bibliotecas de UI adicionales.

## Compilar
Abrir la carpeta en Android Studio con JDK 17 y Android SDK Platform 35 instalado. Sin wrapper incluido, Android Studio puede importar el proyecto y sincronizar Gradle. Generar un APK desde **Build > Build APK(s)**.

## Convertirlo en launcher predeterminado
Instalar el APK y pulsar Inicio. Android debería ofrecer elegir **Vesper Light** como aplicación de inicio; también se puede elegir desde Ajustes > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio (los nombres pueden variar según la versión de One UI).

## Limitaciones de esta entrega
Este ZIP contiene el proyecto fuente, no un APK compilado. No se ha compilado ni probado en un Galaxy A12 físico. La fecha y la hora se actualizan al recrear la pantalla; no se mantiene un servicio de reloj en segundo plano. Es una base ligera inicial, no un reemplazo completo de One UI: no incluye widgets, gestos avanzados, fondos configurables ni gestión de páginas.
