package com.mini.bothost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class BotActivity extends Activity {

    private static final int REQ_ADD_FILE = 21;
    private static final int REQ_EXPORT = 22;
    private static final int REQ_ZIP = 23;
    private static final int REQ_FULL = 24;

    private File pendingExport;

    private String id;
    private Store.Bot bot;
    private boolean deleted;

    private ScrollView sv;
    private LinearLayout content;
    private EditText name;
    private EditText token;
    private EditText env;
    private CheckBox autoRestart;
    private CheckBox autoStart;
    private CheckBox installReqs;
    private EditText webhook;
    private EditText ghRepo;
    private EditText ghBranch;
    private EditText ghPath;
    private EditText ghToken;
    private TextView status;
    private TextView logView;
    private Button toggle;

    private String lastLog = null;
    private boolean restartPending;
    private long idleSince;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            h.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        id = getIntent().getStringExtra("id");
        bot = id == null ? null : Store.load(this, id);
        if (bot == null) {
            finish();
            return;
        }

        sv = new ScrollView(this);
        sv.setFitsSystemWindows(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        content.setPadding(p, p, p, p);
        sv.addView(content);
        setContentView(sv);

        content.addView(Ui.text(this, "Bot", 24, Ui.TXT, true));
        status = Ui.text(this, "", 14, Ui.TXT2, false);
        status.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        content.addView(status);

        // --- control ---
        LinearLayout ctl = row();
        toggle = Ui.button(this, "Iniciar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Store.isActive(BotActivity.this, bot)) {
                    BotService.stop(BotActivity.this, bot);
                    Ui.toast(BotActivity.this, "Deteniendo…");
                } else {
                    saveFields();
                    BotService.start(BotActivity.this, bot);
                    Ui.toast(BotActivity.this, "Iniciando…");
                }
                refresh();
            }
        });
        ctl.addView(toggle, weight());
        ctl.addView(Ui.button(this, "Reiniciar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFields();
                if (Store.isActive(BotActivity.this, bot)) {
                    BotService.stop(BotActivity.this, bot);
                    restartPending = true;
                    idleSince = 0;
                    Ui.toast(BotActivity.this, "Reiniciando…");
                } else {
                    BotService.start(BotActivity.this, bot);
                }
            }
        }), weight());
        content.addView(ctl);

        // --- configuracion ---
        content.addView(label("Nombre"));
        name = edit(bot.name, "Nombre del bot", false);
        content.addView(name);

        content.addView(label("Token de Discord (llega al código como DISCORD_TOKEN)"));
        token = edit(bot.token, "Pega aquí el token", false);
        token.setTransformationMethod(PasswordTransformationMethod.getInstance());
        content.addView(token);
        CheckBox show = check("Mostrar token", false);
        show.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                token.setTransformationMethod(on
                        ? HideReturnsTransformationMethod.getInstance()
                        : PasswordTransformationMethod.getInstance());
            }
        });
        content.addView(show);

        content.addView(label("Variables de entorno (una por línea: CLAVE=valor)"));
        env = edit(bot.env, "PREFIX=!\nOWNER_ID=123456789", true);
        content.addView(env);

        autoRestart = check("Reiniciar automáticamente si se cae", bot.autoRestart);
        content.addView(autoRestart);
        autoStart = check("Iniciar cuando se encienda el celular", bot.autoStart);
        content.addView(autoStart);
        installReqs = check("Instalar requirements.txt al iniciar (usa internet)", bot.installReqs);
        content.addView(installReqs);

        content.addView(label("Alertas: webhook de Discord (avisa si el bot se cae o se reinicia)"));
        webhook = edit(bot.webhook, "https://discord.com/api/webhooks/…", false);
        content.addView(webhook);

        content.addView(label("GitHub: repositorio (usuario/repo)"));
        ghRepo = edit(bot.ghRepo, "usuario/repo", false);
        content.addView(ghRepo);
        content.addView(label("Rama"));
        ghBranch = edit(bot.ghBranch, "main", false);
        content.addView(ghBranch);
        content.addView(label("Archivo .zip dentro del repo (vacío = todo el repo)"));
        ghPath = edit(bot.ghPath, "mibot.zip", false);
        content.addView(ghPath);
        content.addView(label("Token de GitHub (repos privados; solo permiso de lectura)"));
        ghToken = edit(bot.ghToken, "github_pat_…", false);
        ghToken.setTransformationMethod(PasswordTransformationMethod.getInstance());
        content.addView(ghToken);

        LinearLayout r2 = row();
        r2.addView(Ui.button(this, "Guardar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFields();
                Ui.toast(BotActivity.this, "Guardado. Reinicia el bot para aplicar.");
            }
        }), weight());
        r2.addView(Ui.button(this, "Editar código", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFields();
                startActivity(new Intent(BotActivity.this, CodeActivity.class).putExtra("id", id));
            }
        }), weight());
        content.addView(r2);

        LinearLayout r2b = row();
        r2b.addView(Ui.button(this, "Archivos del bot", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFiles();
            }
        }), weight());
        r2b.addView(Ui.button(this, "Reinstalar dependencias", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Store.wipeLibs(BotActivity.this, id);
                Ui.toast(BotActivity.this, "libs/ borrada. Se reinstalará todo al iniciar el bot");
            }
        }), weight());
        content.addView(r2b);

        LinearLayout r2c = row();
        r2c.addView(Ui.button(this, "Actualizar desde GitHub", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateFromGithub();
            }
        }), weight());
        r2c.addView(Ui.button(this, "Exportar bot completo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportFullDialog();
            }
        }), weight());
        content.addView(r2c);

        // --- logs ---
        TextView logTitle = Ui.text(this, "Logs", 18, Ui.TXT, true);
        logTitle.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
        content.addView(logTitle);
        LinearLayout r3 = row();
        r3.addView(Ui.button(this, "Copiar log", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("log",
                            Store.readTail(Store.logFile(BotActivity.this, id), 200000)));
                    Ui.toast(BotActivity.this, "Log copiado");
                }
            }
        }), weight());
        r3.addView(Ui.button(this, "Compartir", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_SUBJECT, "Log de " + bot.name)
                        .putExtra(Intent.EXTRA_TEXT,
                                Store.readTail(Store.logFile(BotActivity.this, id), 60000));
                startActivity(Intent.createChooser(s, "Compartir log"));
            }
        }), weight());
        r3.addView(Ui.button(this, "Limpiar log", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    new FileOutputStream(Store.logFile(BotActivity.this, id)).close();
                } catch (IOException ignored) {
                    // nada
                }
                lastLog = null;
                refresh();
            }
        }), weight());
        content.addView(r3);

        logView = Ui.text(this, "", 11, 0xFFB0BEC5, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setBackground(Ui.card(this));
        logView.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10));
        content.addView(logView);

        Button del = Ui.button(this, "Eliminar bot", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDelete();
            }
        });
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = Ui.dp(this, 20);
        content.addView(del, dlp);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bot != null) {
            h.post(tick);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        if (bot != null && !deleted) {
            saveFields();
        }
    }

    // ---------- logica ----------

    private void saveFields() {
        String n = name.getText().toString().trim();
        if (!n.isEmpty()) {
            bot.name = n;
        }
        bot.token = token.getText().toString().trim();
        bot.env = env.getText().toString();
        bot.autoRestart = autoRestart.isChecked();
        bot.autoStart = autoStart.isChecked();
        bot.installReqs = installReqs.isChecked();
        bot.webhook = webhook.getText().toString().trim();
        bot.ghRepo = ghRepo.getText().toString().trim();
        bot.ghBranch = ghBranch.getText().toString().trim();
        bot.ghPath = ghPath.getText().toString().trim();
        bot.ghToken = ghToken.getText().toString().trim();
        Store.save(this, bot);
    }

    private void refresh() {
        boolean active = Store.isActive(this, bot);
        status.setText(Store.statusText(this, bot));
        toggle.setText(active ? "Detener" : "Iniciar");

        if (restartPending) {
            if (active) {
                idleSince = 0;
            } else if (idleSince == 0) {
                idleSince = System.currentTimeMillis();
            } else if (System.currentTimeMillis() - idleSince >= 1000) {
                restartPending = false;
                BotService.start(this, bot);
            }
        }

        String t = Store.readTail(Store.logFile(this, id), 6000);
        if (!t.equals(lastLog)) {
            boolean atBottom = sv.getScrollY() + sv.getHeight() >= content.getHeight() - Ui.dp(this, 80);
            lastLog = t;
            logView.setText(t.isEmpty() ? "(sin logs todavía)" : t);
            if (atBottom) {
                sv.post(new Runnable() {
                    @Override
                    public void run() {
                        sv.scrollTo(0, content.getHeight());
                    }
                });
            }
        }
    }

    // ---------- GitHub / exportar ----------

    private void updateFromGithub() {
        saveFields();
        if (bot.ghRepo.isEmpty()) {
            Ui.toast(this, "Escribe el repositorio (usuario/repo)");
            return;
        }
        Ui.toast(this, "Descargando…");
        final Store.Bot b = bot;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String err = GitHub.update(BotActivity.this, b);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (err != null) {
                            Ui.toast(BotActivity.this, err);
                        } else if (Store.isActive(BotActivity.this, b)) {
                            Ui.toast(BotActivity.this, "Actualizado. Reiniciando…");
                            BotService.stop(BotActivity.this, b);
                            restartPending = true;
                            idleSince = 0;
                        } else {
                            Ui.toast(BotActivity.this, "Actualizado. Ya puedes iniciar el bot.");
                        }
                    }
                });
            }
        }).start();
    }

    private void exportFullDialog() {
        saveFields();
        new AlertDialog.Builder(this)
                .setTitle("Exportar bot completo")
                .setMessage("El zip incluye código, datos, token, webhook y variables. "
                        + "Guárdalo en un lugar privado.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Exportar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/zip");
                        i.putExtra(Intent.EXTRA_TITLE,
                                bot.name.replaceAll("[^A-Za-z0-9_.-]", "_") + ".bothost.zip");
                        startActivityForResult(i, REQ_FULL);
                    }
                })
                .show();
    }

    // ---------- archivos extra ----------

    private void showFiles() {
        saveFields();
        final List<String> files = Store.userFiles(this, id);
        String[] items = new String[files.size() + 3];
        items[0] = "+ Agregar archivo…";
        items[1] = "+ Importar .zip (extraer)…";
        items[2] = "+ Nuevo archivo (p. ej. requirements.txt)…";
        for (int i = 0; i < files.size(); i++) {
            items[i + 3] = files.get(i);
        }
        new AlertDialog.Builder(this)
                .setTitle("Archivos del bot")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which <= 1) {
                            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("*/*");
                            startActivityForResult(i, which == 0 ? REQ_ADD_FILE : REQ_ZIP);
                        } else if (which == 2) {
                            newFile();
                        } else {
                            fileActions(files.get(which - 3));
                        }
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void newFile() {
        final EditText n = new EditText(this);
        n.setSingleLine(true);
        n.setText("requirements.txt");
        new AlertDialog.Builder(this)
                .setTitle("Nuevo archivo")
                .setMessage("Puedes usar subcarpetas, por ejemplo cogs/musica.py")
                .setView(n)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear y editar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String name = n.getText().toString().trim();
                        File f = Store.resolve(BotActivity.this, id, name);
                        if (f == null) {
                            Ui.toast(BotActivity.this, "Nombre no válido");
                            return;
                        }
                        if (!f.exists()) {
                            Store.writeText(f, "");
                        }
                        startActivity(new Intent(BotActivity.this, CodeActivity.class)
                                .putExtra("id", id).putExtra("file", name));
                    }
                })
                .show();
    }

    private void fileActions(final String rel) {
        final java.util.ArrayList<String> ops = new java.util.ArrayList<>();
        ops.add("Editar");
        ops.add("Exportar");
        if (rel.toLowerCase().endsWith(".zip")) {
            ops.add("Extraer aquí");
        }
        if (!rel.equals("main.py")) {
            ops.add("Eliminar");
        }
        new AlertDialog.Builder(this)
                .setTitle(rel)
                .setItems(ops.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String op = ops.get(which);
                        final File f = Store.resolve(BotActivity.this, id, rel);
                        if (f == null || !f.exists()) {
                            return;
                        }
                        if (op.equals("Editar")) {
                            if (!Store.isTextName(rel)) {
                                Ui.toast(BotActivity.this, "Ese archivo no es de texto");
                                return;
                            }
                            startActivity(new Intent(BotActivity.this, CodeActivity.class)
                                    .putExtra("id", id).putExtra("file", rel));
                        } else if (op.equals("Exportar")) {
                            pendingExport = f;
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("*/*");
                            i.putExtra(Intent.EXTRA_TITLE, f.getName());
                            startActivityForResult(i, REQ_EXPORT);
                        } else if (op.equals("Extraer aquí")) {
                            extractAsync(f, false);
                        } else {
                            f.delete();
                            Ui.toast(BotActivity.this, "Eliminado");
                        }
                    }
                })
                .show();
    }

    /** Extrae en segundo plano; si temp es true, borra el zip al terminar. */
    private void extractAsync(final File zip, final boolean temp) {
        Ui.toast(this, "Extrayendo…");
        final File dest = Store.dir(this, id);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int n = Store.unzip(zip, dest);
                if (temp) {
                    zip.delete();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Ui.toast(BotActivity.this, n < 0
                                ? "No se pudo extraer (zip dañado o demasiado grande)"
                                : n + " archivos extraídos. Reinicia el bot para aplicar.");
                    }
                });
            }
        }, "unzip").start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        if (requestCode == REQ_EXPORT && pendingExport != null) {
            boolean ok = Store.copyToUri(this, pendingExport, uri);
            Ui.toast(this, ok ? "Exportado" : "No se pudo exportar");
            pendingExport = null;
        } else if (requestCode == REQ_FULL) {
            Ui.toast(this, "Exportando…");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final boolean ok = Store.exportFull(BotActivity.this, id, uri);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Ui.toast(BotActivity.this, ok ? "Bot exportado" : "No se pudo exportar");
                        }
                    });
                }
            }).start();
        } else if (requestCode == REQ_ZIP) {
            File tmp = new File(getCacheDir(), "import.zip");
            if (Store.copyFromUri(this, uri, tmp)) {
                extractAsync(tmp, true);
            } else {
                Ui.toast(this, "No se pudo leer el zip");
            }
        } else if (requestCode == REQ_ADD_FILE) {
            final EditText n = new EditText(this);
            n.setSingleLine(true);
            n.setText(Ui.fileName(this, uri));
            new AlertDialog.Builder(this)
                    .setTitle("Guardar como")
                    .setMessage("Puedes usar subcarpetas, por ejemplo cogs/musica.py")
                    .setView(n)
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Agregar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int which) {
                            File dest = Store.resolve(BotActivity.this, id, n.getText().toString());
                            if (dest == null) {
                                Ui.toast(BotActivity.this, "Nombre no válido");
                            } else if (Store.copyFromUri(BotActivity.this, uri, dest)) {
                                Ui.toast(BotActivity.this, "Agregado. Reinicia el bot para aplicar.");
                            } else {
                                Ui.toast(BotActivity.this, "No se pudo copiar el archivo");
                            }
                        }
                    })
                    .show();
        }
    }

    private void confirmDelete() {
        if (Store.isActive(this, bot)) {
            Ui.toast(this, "Detén el bot antes de eliminarlo");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Eliminar “" + bot.name + "”")
                .setMessage("Se borrarán su código, configuración y logs.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        deleted = true;
                        Store.delete(BotActivity.this, id);
                        finish();
                    }
                })
                .show();
    }

    // ---------- helpers de UI ----------

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 13, Ui.TXT2, false);
        t.setPadding(0, Ui.dp(this, 14), 0, 0);
        return t;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(Ui.TXT);
        c.setChecked(on);
        return c;
    }

    private EditText edit(String value, String hint, boolean multiline) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(Ui.TXT);
        e.setHintTextColor(0x66FFFFFF);
        if (multiline) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
        }
        return e;
    }
}
