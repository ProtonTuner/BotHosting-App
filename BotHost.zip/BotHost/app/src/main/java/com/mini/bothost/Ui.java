package com.mini.bothost;

import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Utilidades de interfaz (todo se arma por codigo, sin layouts XML). */
final class Ui {
    static final int TXT = 0xFFECEFF1;
    static final int TXT2 = 0xFF90A4AE;
    static final int CARD = 0xB0121826;
    static final int[] RAINBOW = {0xFFFF4D6D, 0xFFFF9F43, 0xFFFFD93D, 0xFF4ADE80,
            0xFF22D3EE, 0xFF6C8CFF, 0xFFB57BFF, 0xFFFF4D6D};

    private Ui() { }

    static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    static Button button(Context c, String label, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x26FFFFFF);
        g.setCornerRadius(dp(c, 14));
        g.setStroke(dp(c, 1), 0x4DFFFFFF);
        RippleDrawable r = new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null);
        b.setBackground(new InsetDrawable(r, dp(c, 3)));
        b.setOnClickListener(l);
        return b;
    }

    static GradientDrawable card(Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(c, 16));
        g.setStroke(dp(c, 1), 0x33FFFFFF);
        return g;
    }

    /** Barra con los colores del arcoiris (subrayado de la pestana activa). */
    static GradientDrawable rainbowBar(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, RAINBOW);
        g.setCornerRadius(dp(c, 2));
        return g;
    }

    /** Texto con degradado arcoiris que se desplaza mientras esta en pantalla. */
    static void rainbowText(final TextView t) {
        final Matrix m = new Matrix();
        final float[] w = {0f};
        final LinearGradient[] sh = {null};
        final ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(5000);
        va.setRepeatCount(ValueAnimator.INFINITE);
        va.setInterpolator(new LinearInterpolator());
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                float width = Math.max(1f, t.getPaint().measureText(t.getText().toString()));
                if (sh[0] == null || width != w[0]) {
                    w[0] = width;
                    sh[0] = new LinearGradient(0, 0, width, 0, RAINBOW, null, Shader.TileMode.REPEAT);
                    t.getPaint().setShader(sh[0]);
                }
                m.setTranslate(width * (Float) a.getAnimatedValue(), 0);
                sh[0].setLocalMatrix(m);
                t.invalidate();
            }
        });
        t.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                if (!va.isStarted()) {
                    va.start();
                }
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                va.cancel();
            }
        });
        if (t.isAttachedToWindow()) {
            va.start();
        }
    }

    /** Pone el fondo aurora detras del contenido. */
    static View withAurora(Context c, View content) {
        FrameLayout f = new FrameLayout(c);
        f.addView(new AuroraView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        f.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return f;
    }

    static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    static String readUri(Context c, Uri uri) throws IOException {
        InputStream in = c.getContentResolver().openInputStream(uri);
        if (in == null) {
            throw new IOException("sin datos");
        }
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), "UTF-8");
        } finally {
            in.close();
        }
    }

    /** Nombre real del archivo elegido (con extension). */
    static String fileName(Context c, Uri uri) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
                    null, null, null);
            if (cur != null && cur.moveToFirst() && cur.getString(0) != null) {
                return cur.getString(0);
            }
        } catch (Exception ignored) {
            // nombre por defecto
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return "archivo";
    }

    static String displayName(Context c, Uri uri) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
                    null, null, null);
            if (cur != null && cur.moveToFirst()) {
                String n = cur.getString(0);
                if (n != null) {
                    if (n.toLowerCase().endsWith(".py")) {
                        n = n.substring(0, n.length() - 3);
                    }
                    return n;
                }
            }
        } catch (Exception ignored) {
            // usamos el nombre por defecto
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return "Bot importado";
    }
}
