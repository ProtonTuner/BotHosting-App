# Bot Host

App Android para hostear bots de Discord en Python (discord.py) directamente en el celular.
Python viene embebido con Chaquopy; cada bot corre en su propio proceso.

## Incluido
discord.py (con aiohttp), requests, python-dotenv, aiosqlite, pytz.
Para agregar más librerías edita `app/build.gradle` (bloque `pip { install "paquete" }`).
Solo funcionan paquetes puros de Python o que Chaquopy ya tenga compilados para Android.

## Cómo usarla
1. Instala el APK y acepta las notificaciones.
2. Toca **Ahorro de batería** y elige **Sin restricciones** (si no, Android puede cerrar los bots).
3. **+ Nuevo bot** (trae un ejemplo con `!ping`) o **Importar .py** con tu archivo.
4. Dentro del bot pega el **token**; en el código léelo con `os.getenv("DISCORD_TOKEN")`.
5. **Iniciar**. Verás estado, servidores, ping, RAM y logs en vivo.

## Notas
- Máximo 4 bots a la vez (un proceso por bot). Para más, agrega clases `S4`, `S5`… en `BotService.java` y su `<service>` en el manifest.
- Usa `bot.run(TOKEN)` o `asyncio.run(...)` con `bot.start(...)`; ambos se detienen limpio.
- El token también queda como `TOKEN` y `BOT_TOKEN`; las variables del bot se cargan en `os.environ`.
- Sin voz (PyNaCl no está incluido) para mantener la app liviana.
