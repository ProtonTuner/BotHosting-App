package com.mini.bothost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;

/**
 * Fondo "aurora": manchas de colores del arcoiris con degradado radial (aspecto desenfocado)
 * que se mueven despacio. Solo anima mientras se ve y se queda estatico con el ahorro de
 * bateria o si las animaciones del sistema estan desactivadas.
 */
public class AuroraView extends View {
    private static final int[] COLORS = {0xFFFF4D8D, 0xFF7C5CFF, 0xFF22D3EE, 0xFF4ADE80, 0xFFFFB84D};
    private static final float[] SPEED = {0.11f, 0.15f, 0.09f, 0.13f, 0.17f};
    private static final float[] PHASE = {0f, 1.3f, 2.6f, 3.9f, 5.2f};

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RadialGradient[] shaders = new RadialGradient[COLORS.length];
    private final long t0 = SystemClock.uptimeMillis();
    private float radius;
    private boolean running;

    private final Runnable step = new Runnable() {
        @Override
        public void run() {
            if (!running) {
                return;
            }
            invalidate();
            postDelayed(this, 40);
        }
    };

    public AuroraView(Context c) {
        super(c);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        radius = Math.max(w, h) * 0.6f;
        for (int i = 0; i < COLORS.length; i++) {
            int rgb = COLORS[i] & 0x00FFFFFF;
            shaders[i] = new RadialGradient(0, 0, Math.max(radius, 1f),
                    rgb | 0x8C000000, rgb, Shader.TileMode.CLAMP);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(0xFF0B0F1A);
        float t = (SystemClock.uptimeMillis() - t0) / 1000f;
        int w = getWidth();
        int h = getHeight();
        for (int i = 0; i < COLORS.length; i++) {
            if (shaders[i] == null) {
                continue;
            }
            float a = PHASE[i] + t * SPEED[i];
            float cx = w * (0.5f + 0.5f * (float) Math.cos(a));
            float cy = h * (0.5f + 0.5f * (float) Math.sin(a * 0.83f + PHASE[i]));
            paint.setShader(shaders[i]);
            canvas.save();
            canvas.translate(cx, cy);
            canvas.drawCircle(0, 0, radius, paint);
            canvas.restore();
        }
        canvas.drawColor(0x66000000); // oscurece un poco para que el texto se lea bien
    }

    private boolean animationsAllowed() {
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        if (pm != null && pm.isPowerSaveMode()) {
            return false;
        }
        return Settings.Global.getFloat(getContext().getContentResolver(),
                Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f;
    }

    private void update() {
        boolean should = isShown() && getWindowVisibility() == VISIBLE && animationsAllowed();
        if (should && !running) {
            running = true;
            post(step);
        } else if (!should && running) {
            running = false;
            removeCallbacks(step);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        update();
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(step);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int v) {
        super.onWindowVisibilityChanged(v);
        update();
    }

    @Override
    protected void onVisibilityChanged(View changed, int v) {
        super.onVisibilityChanged(changed, v);
        update();
    }
}
