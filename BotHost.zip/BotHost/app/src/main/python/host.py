"""Runner de bots. Corre dentro del proceso de cada bot (un proceso por bot).

Java llama a run(bot_dir) en un hilo, stop() para cerrar, y warmup() una vez.
"""
import asyncio
import collections
import gc
import hashlib
import io
import json
import os
import runpy
import shutil
import signal
import sys
import threading
import time
import traceback
import zipfile

_stopping = False
_restarting = False  # reinicio de proceso en curso (limite excedido o reinicio programado)
_clients = []  # (client, loop) de cada discord.Client que se inicio
_ev = {}  # contador de eventos de discord por nombre (sin los socket_*)
try:
    _HZ = os.sysconf("SC_CLK_TCK")
except Exception:
    _HZ = 100


class _Log(object):
    """Escribe stdout/stderr en log.txt con hora y rota el archivo si crece."""

    encoding = "utf-8"
    errors = "replace"

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self.bol = True
        try:
            size = os.path.getsize(path)
        except OSError:
            size = 0
        if size > 400000:
            try:
                os.replace(path, path + ".1")
            except OSError:
                pass
            size = 0
        self.n = size
        self.f = open(path, "a", encoding="utf-8", errors="replace", buffering=1)

    def write(self, s):
        if not s:
            return 0
        out = []
        for part in s.splitlines(True):
            if self.bol:
                out.append(time.strftime("%H:%M:%S "))
            out.append(part)
            self.bol = part.endswith("\n")
        text = "".join(out)
        with self.lock:
            try:
                self.f.write(text)
                self.n += len(text)
                if self.n > 400000:
                    self._rotate()
            except Exception:
                pass
        return len(s)

    def _rotate(self):
        try:
            self.f.close()
            os.replace(self.path, self.path + ".1")
        except OSError:
            pass
        self.f = open(self.path, "a", encoding="utf-8", errors="replace", buffering=1)
        self.n = 0

    def flush(self):
        try:
            self.f.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


def _hint(exc):
    """Devuelve (mensaje, fatal) para errores comunes; fatal = reiniciar no sirve de nada."""
    names = [c.__name__ for c in type(exc).__mro__]
    if "ModuleNotFoundError" in names:
        mod = getattr(exc, "name", None) or "?"
        return ("Falta el modulo '%s'. La app no puede hacer pip install en el celular: "
                "agregalo a requirements.txt del bot (solo paquetes de Python puro) o, si tiene codigo "
                "nativo, a app/build.gradle (pip { install \"%s\" }) y recompila." % (mod, mod), True)
    if "ImportError" in names:  # ModuleNotFoundError ya se trato arriba
        return ("Error de importacion: %s. Es un fallo del codigo del bot (un nombre que no "
                "existe en ese modulo); reiniciar no lo arregla." % (exc,), True)
    if "SyntaxError" in names:  # incluye IndentationError
        return ("Error de sintaxis en %s linea %s. Corrigelo en 'Editar codigo'."
                % (os.path.basename(str(getattr(exc, "filename", "") or "main.py")),
                   getattr(exc, "lineno", "?")), True)
    if "LoginFailure" in names:
        return ("Token invalido. Revisa el token en la pantalla del bot.", True)
    if "PrivilegedIntentsRequired" in names:
        return ("Faltan intents privilegiados: activalos en Discord Developer Portal > Bot "
                "(Message Content / Server Members / Presence).", True)
    return None


# ---------------------------------------------------------------------------
# Instalador de requirements.txt (solo wheels de Python puro, desde PyPI)
# ---------------------------------------------------------------------------

def _py_ok_tag(interp, abi, plat):
    if plat != "any":
        return False
    if interp == "py3":
        return True
    if interp.startswith("py3") and interp[3:].isdigit():
        return int(interp[3:]) <= sys.version_info[1]
    return interp == "cp%d%d" % sys.version_info[:2] and abi == "none"


def _pick_wheel(files, pyver):
    from packaging.specifiers import SpecifierSet
    from packaging.utils import parse_wheel_filename
    for f in files or []:
        fn = f.get("filename", "")
        if f.get("packagetype") != "bdist_wheel" or f.get("yanked") or not fn.endswith("-none-any.whl"):
            continue
        try:
            tags = parse_wheel_filename(fn)[3]
        except Exception:
            continue
        if not any(_py_ok_tag(t.interpreter, t.abi, t.platform) for t in tags):
            continue
        rp = f.get("requires_python")
        if rp:
            try:
                if not SpecifierSet(rp).contains(pyver, prereleases=True):
                    continue
            except Exception:
                pass
        return f
    return None


def _dist_infos(libs, key):
    from packaging.utils import canonicalize_name
    out = []
    try:
        names = os.listdir(libs)
    except OSError:
        return out
    for e in names:
        if e.endswith(".dist-info"):
            nm = e[:-len(".dist-info")].rsplit("-", 1)[0]
            if canonicalize_name(nm) == key:
                out.append(os.path.join(libs, e))
    return out


def _extract_wheel(path, libs):
    root = os.path.realpath(libs) + os.sep
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if info.filename.endswith("/"):
                continue
            name = info.filename
            parts = name.split("/")
            if parts[0].endswith(".data"):
                if len(parts) > 2 and parts[1] in ("purelib", "platlib"):
                    name = "/".join(parts[2:])
                else:
                    continue
            dest = os.path.realpath(os.path.join(libs, name))
            if not dest.startswith(root):
                continue
            d = os.path.dirname(dest)
            if not os.path.isdir(d):
                os.makedirs(d)
            with z.open(info) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)


def _install_requirements(bot_dir):
    req_path = os.path.join(bot_dir, "requirements.txt")
    if not os.path.isfile(req_path):
        return
    with open(req_path, "rb") as f:
        data = f.read()
    digest = hashlib.sha1(data).hexdigest()
    libs = os.path.join(bot_dir, "libs")
    if not os.path.isdir(libs):
        os.makedirs(libs)
    marker = os.path.join(libs, ".req-hash")
    try:
        with open(marker) as f:
            if f.read().strip() == digest:
                print("[deps] requirements.txt sin cambios; nada que instalar")
                return
    except OSError:
        pass

    try:
        import importlib
        import importlib.metadata as md
        import requests
        from packaging.requirements import Requirement, InvalidRequirement
        from packaging.utils import canonicalize_name
        from packaging.version import Version
    except Exception as e:
        print("[deps] no se pueden instalar dependencias (falta %s)" % e)
        return

    pyver = Version("%d.%d.%d" % sys.version_info[:3])
    queue = []
    for raw in data.decode("utf-8", "replace").splitlines():
        line = raw.split(" #")[0].strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("-") or "://" in line or line.startswith("git+"):
            print("[deps] linea ignorada (no soportada): %s" % line)
            continue
        try:
            queue.append(Requirement(line))
        except InvalidRequirement:
            print("[deps] requisito invalido: %s" % line)

    print("[deps] instalando dependencias de requirements.txt (solo Python puro)...")
    tmpdir = os.path.join(bot_dir, ".deps-tmp")
    if not os.path.isdir(tmpdir):
        os.makedirs(tmpdir)
    sess = requests.Session()
    seen = set()
    ok = problems = 0
    net_error = False
    native = []

    while queue and not _stopping:
        req = queue.pop(0)
        key = canonicalize_name(req.name)
        if key in seen:
            continue
        if req.marker is not None and not req.marker.evaluate({"extra": ""}):
            continue
        seen.add(key)

        try:
            cur = md.version(req.name)
            if not req.specifier or req.specifier.contains(cur, prereleases=True):
                print("[deps] %s %s ya disponible" % (req.name, cur))
                continue
            print("[deps] %s %s no cumple '%s'; buscando otra version" % (req.name, cur, req.specifier))
        except md.PackageNotFoundError:
            pass

        try:
            r = sess.get("https://pypi.org/pypi/%s/json" % key, timeout=30)
        except Exception as e:
            print("[deps] %s: error de red (%s)" % (req.name, e))
            net_error = True
            problems += 1
            continue
        if r.status_code == 404:
            print("[deps] %s: no existe en PyPI" % req.name)
            problems += 1
            continue
        if r.status_code != 200:
            print("[deps] %s: PyPI respondio %s" % (req.name, r.status_code))
            net_error = True
            problems += 1
            continue
        releases = r.json().get("releases", {})
        vmap = {}
        for v in releases:
            try:
                vmap[Version(v)] = v
            except Exception:
                pass
        cands = list(req.specifier.filter(list(vmap), prereleases=False)) \
            or list(req.specifier.filter(list(vmap), prereleases=True))
        cands.sort(reverse=True)
        chosen = None
        for v in cands[:20]:
            w = _pick_wheel(releases.get(vmap[v]), pyver)
            if w:
                chosen = (v, w)
                break
        if not chosen:
            print("[deps] %s: no tiene wheel de Python puro compatible (probablemente necesita "
                  "compilarse). Si Chaquopy lo incluye, agregalo en app/build.gradle." % req.name)
            native.append(req.name)
            problems += 1
            continue

        ver, wheel = chosen
        dest = os.path.join(tmpdir, wheel["filename"])
        try:
            sha = hashlib.sha256()
            with sess.get(wheel["url"], stream=True, timeout=60) as resp:
                resp.raise_for_status()
                with open(dest, "wb") as out:
                    for chunk in resp.iter_content(65536):
                        sha.update(chunk)
                        out.write(chunk)
            want = (wheel.get("digests") or {}).get("sha256")
            if want and sha.hexdigest() != want:
                raise ValueError("checksum no coincide")
            for old in _dist_infos(libs, key):
                shutil.rmtree(old, ignore_errors=True)
            _extract_wheel(dest, libs)
        except Exception as e:
            print("[deps] %s: fallo la descarga/instalacion (%s)" % (req.name, e))
            net_error = True
            problems += 1
            continue
        finally:
            try:
                os.remove(dest)
            except OSError:
                pass
        print("[deps] %s %s instalado" % (req.name, ver))
        ok += 1

        # dependencias del paquete (desde su METADATA)
        extras = set(e.lower() for e in req.extras) | set([""])
        for di in _dist_infos(libs, key):
            try:
                from email.parser import Parser
                with open(os.path.join(di, "METADATA"), encoding="utf-8", errors="replace") as f:
                    msg = Parser().parsestr(f.read())
            except Exception:
                continue
            for rd in msg.get_all("Requires-Dist") or []:
                try:
                    dep = Requirement(rd)
                except InvalidRequirement:
                    continue
                if dep.marker is not None and not any(dep.marker.evaluate({"extra": e}) for e in extras):
                    continue
                queue.append(dep)
            break

    shutil.rmtree(tmpdir, ignore_errors=True)
    importlib.invalidate_caches()
    if not net_error and not _stopping:
        try:
            with open(marker, "w") as f:
                f.write(digest)
        except OSError:
            pass
    if native:
        print("[deps] para estos paquetes nativos agrega en app/build.gradle (bloque pip) y recompila:")
        for n in native:
            print('[deps]     install "%s"' % n)
    print("[deps] listo: %d instalada(s), %d con problemas%s"
          % (ok, problems, " (se reintentara al iniciar)" if net_error else ""))


# ---------------------------------------------------------------------------
# Musica: ffmpeg + libopus empaquetados en la app (ver workflow "Music libs")
# ---------------------------------------------------------------------------

_native_dir = None
_shim_done = False


def set_native_dir(path):
    global _native_dir
    _native_dir = path


class _HttpStream(io.RawIOBase):
    """Descarga la URL con Python y la entrega como flujo: el ffmpeg estatico no sabe resolver
    DNS en Android (no existe /etc/resolv.conf), asi que le damos el audio por stdin."""

    def __init__(self, url, headers=None):
        import requests
        self._r = requests.get(url, headers=headers or {}, stream=True, timeout=(15, 60))
        self._r.raise_for_status()

    def readable(self):
        return True

    def read(self, n=-1):
        try:
            return self._r.raw.read(n if n and n > 0 else 65536)
        except Exception:
            return b""

    def close(self):
        try:
            self._r.close()
        except Exception:
            pass
        super().close()


def _split_net_opts(opts):
    """Quita -reconnect*/-headers/-user_agent de before_options (no aplican al pipe)."""
    import shlex
    headers = {}
    if not opts:
        return None, headers
    toks = shlex.split(opts)
    out = []
    i = 0
    while i < len(toks):
        t = toks[i]
        if t.startswith("-reconnect"):
            i += 2
            continue
        if t == "-user_agent" and i + 1 < len(toks):
            headers["User-Agent"] = toks[i + 1]
            i += 2
            continue
        if t == "-headers" and i + 1 < len(toks):
            for line in toks[i + 1].replace("\r", "").split("\n"):
                if ":" in line:
                    k, v = line.split(":", 1)
                    headers[k.strip()] = v.strip()
            i += 2
            continue
        out.append(t)
        i += 1
    return (" ".join(shlex.quote(x) for x in out) or None), headers


def _patch_ffmpeg_sources():
    global _shim_done
    if _shim_done:
        return
    try:
        import discord
    except Exception:
        return

    def wrap(cls):
        orig = cls.__init__

        def __init__(self, source, *a, **kw):
            if isinstance(source, str) and source.startswith(("http://", "https://")) and not kw.get("pipe"):
                try:
                    opts, hdr = _split_net_opts(kw.get("before_options"))
                    stream = _HttpStream(source, hdr)
                    kw["before_options"] = opts
                    kw["pipe"] = True
                    source = stream
                except Exception as e:
                    print("[music] no se pudo abrir la URL por Python (%s); se intenta con ffmpeg directo" % (e,))
            orig(self, source, *a, **kw)

        cls.__init__ = __init__

    for name in ("FFmpegPCMAudio", "FFmpegOpusAudio"):
        c = getattr(discord, name, None)
        if c is not None:
            wrap(c)
    _shim_done = True


def _setup_music(bot_dir):
    nd = _native_dir
    if not nd:
        return
    ff = os.path.join(nd, "libffmpeg.so")
    if os.path.isfile(ff):
        bindir = os.path.join(os.path.dirname(os.path.dirname(bot_dir)), "bin")
        link = ff
        try:
            if not os.path.isdir(bindir):
                os.makedirs(bindir)
            link = os.path.join(bindir, "ffmpeg")
            if os.path.islink(link) or os.path.exists(link):
                os.remove(link)
            os.symlink(ff, link)
        except OSError:
            link = ff
        os.environ["FFMPEG_PATH"] = link
        os.environ["PATH"] = os.path.dirname(link) + os.pathsep + os.environ.get("PATH", "")
        print("[music] ffmpeg listo: %s" % link)
        _patch_ffmpeg_sources()
    op = os.path.join(nd, "libopus.so")
    if os.path.isfile(op):
        try:
            import discord.opus
            discord.opus.load_opus(op)
            print("[music] libopus cargada")
        except Exception as e:
            print("[music] no se pudo cargar libopus: %s" % (e,))
    try:
        import davey  # noqa: F401
        print("[music] davey (DAVE) disponible")
    except Exception:
        pass


def warmup():
    """Importa las librerias pesadas una vez (Java lo llama con un candado entre procesos)."""
    try:
        import discord  # noqa: F401
        import aiohttp  # noqa: F401
    except Exception:
        traceback.print_exc()


def _proc_status():
    """(RAM actual MB, RAM pico MB, hilos) leidos de /proc/self/status."""
    rss = peak = 0.0
    threads = 0
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    rss = round(int(line.split()[1]) / 1024.0, 1)
                elif line.startswith("VmHWM:"):
                    peak = round(int(line.split()[1]) / 1024.0, 1)
                elif line.startswith("Threads:"):
                    threads = int(line.split()[1])
    except Exception:
        pass
    return rss, peak, threads


def _cpu_ticks():
    """Tiempo de CPU (user+sys) de este proceso en ticks de reloj, o None."""
    try:
        with open("/proc/self/stat") as f:
            data = f.read()
        rest = data[data.rindex(")") + 2:].split()
        return int(rest[11]) + int(rest[12])  # utime, stime (campos 14 y 15)
    except Exception:
        return None


def _net_bytes():
    """Bytes (recibidos, enviados) de TODA la app desde que arranco el telefono, o None."""
    try:
        from java import jclass
        ts = jclass("android.net.TrafficStats")
        uid = os.getuid()
        rx = int(ts.getUidRxBytes(uid))
        tx = int(ts.getUidTxBytes(uid))
        if rx < 0 or tx < 0:
            return None
        return rx, tx
    except Exception:
        return None


def _num(cfg, key, default=0.0):
    try:
        return float(cfg.get(key, default))
    except Exception:
        return float(default)


# ---------------------------------------------------------------------------
# Contadores persistentes (stats.json): inicios, reinicios, caidas
# ---------------------------------------------------------------------------

_stats_lock = threading.Lock()


def _stats_load(bot_dir):
    try:
        with open(os.path.join(bot_dir, "stats.json"), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _stats_update(bot_dir, fn):
    with _stats_lock:
        d = _stats_load(bot_dir)
        try:
            fn(d)
            path = os.path.join(bot_dir, "stats.json")
            with open(path + ".tmp", "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(path + ".tmp", path)
        except Exception:
            pass
        return d


def _note_start(bot_dir):
    def f(d):
        d["starts"] = int(d.get("starts", 0)) + 1
    _stats_update(bot_dir, f)


def _note_crash(bot_dir, why, will_restart):
    def f(d):
        d["crashes"] = int(d.get("crashes", 0)) + 1
        if will_restart:
            d["restarts"] = int(d.get("restarts", 0)) + 1
        d["lastCrash"] = {"t": time.time(), "why": str(why)[:200]}
    _stats_update(bot_dir, f)


# ---------------------------------------------------------------------------
# Limites de rendimiento y reinicio de proceso
# ---------------------------------------------------------------------------

def _watch(st, kind, value, limit, secs, now):
    """True una vez cuando value supera limit de forma sostenida durante secs (luego enfria 10 min)."""
    if not limit or limit <= 0 or value is None or value <= limit:
        st["over"].pop(kind, None)
        return False
    since = st["over"].setdefault(kind, now)
    if now - since < secs:
        return False
    last = st["cool"].get(kind)
    if last is not None and now - last < 600:
        return False
    st["cool"][kind] = now
    st["over"].pop(kind, None)
    return True


def _restart_process(bot_dir, cfg, reason, by_limit):
    """Cierra el bot con gracia y mata el proceso SIN borrar el slot: Android reinicia el servicio
    (START_STICKY) y BotService recupera el bot del slot. Asi se libera de verdad la RAM.
    No vuelve si reinicia; vuelve (sin hacer nada) si el freno anti-bucle lo impide."""
    global _restarting
    if _restarting:
        return
    now = time.time()
    if by_limit:
        recent = [t for t in _stats_load(bot_dir).get("lr", []) if now - t < 1800]
        if len(recent) >= 3:
            print("[host] %s; pero ya hubo 3 reinicios por limites en 30 min: no reinicio mas" % reason)
            _alert(cfg, "🟠 %s. Ya hubo 3 reinicios por límites en 30 min; no reinicio más "
                        "(revisa el bot o sube el límite)" % reason)
            return
    _restarting = True
    try:
        def f(d):
            d["restarts"] = int(d.get("restarts", 0)) + 1
            d["lastRestart"] = {"t": now, "why": reason[:200]}
            if by_limit:
                lr = [t for t in d.get("lr", []) if now - t < 1800]
                lr.append(now)
                d["lr"] = lr
        _stats_update(bot_dir, f)
        print("[host] reiniciando el proceso: %s" % reason)
        _alert(cfg, "🔁 Reiniciando: %s" % reason, True, True)
        for client, loop in list(_clients):
            try:
                if not client.is_closed():
                    asyncio.run_coroutine_threadsafe(client.close(), loop).result(timeout=6)
            except Exception:
                pass
        try:
            sys.stdout.flush()
        except Exception:
            pass
        try:  # que la UI siga mostrando "iniciando" mientras Android relanza el servicio
            slot = int(cfg.get("slot", 0))
            os.utime(os.path.join(os.path.dirname(os.path.dirname(bot_dir)), "slots",
                                  "slot%d" % slot), None)
        except Exception:
            pass
    finally:
        os.kill(os.getpid(), signal.SIGKILL)


def _check_limits(bot_dir, cfg, st, info, started, now):
    secs = max(10.0, _num(cfg, "limSecs", 60))
    restart = bool(cfg.get("limRestart", False))
    for kind, val, lim, unit, label in (
            ("ram", info.get("mem"), _num(cfg, "limRam"), "MB", "RAM"),
            ("cpu", info.get("cpu"), _num(cfg, "limCpu"), "%", "CPU")):
        if _watch(st, kind, val, lim, secs, now):
            msg = "%s en %s%s supero el limite de %d%s durante %ds" % (label, val, unit, int(lim), unit, secs)
            print("[host] limite: %s" % msg)
            if restart:
                _restart_process(bot_dir, cfg, msg, True)
            else:
                _alert(cfg, "🟡 %s" % msg, True)
    ping = info.get("ping", -1)
    if _watch(st, "ping", ping if ping and ping > 0 else None, _num(cfg, "limPing"), secs, now):
        msg = "ping %d ms supero el limite de %d ms durante %ds" % (ping, int(_num(cfg, "limPing")), secs)
        print("[host] limite: %s" % msg)
        _alert(cfg, "🟡 %s" % msg, True)  # reiniciar no arregla la red: solo se avisa
    hrs = _num(cfg, "restartHours")
    if hrs > 0 and now - started >= hrs * 3600:
        _restart_process(bot_dir, cfg, "reinicio programado (cada %g h)" % hrs, False)


def _reload_cfg(bot_dir, cfg, st):
    """Relee config.json si cambio: los limites se aplican sin reiniciar el bot."""
    p = os.path.join(bot_dir, "config.json")
    try:
        m = os.stat(p).st_mtime
    except OSError:
        return
    if m == st.get("cfg_m"):
        return
    try:
        with open(p, encoding="utf-8") as f:
            new = json.load(f)
        cfg.clear()
        cfg.update(new)
        st["cfg_m"] = m
    except Exception:
        pass  # archivo a medio escribir: se reintenta en la siguiente vuelta


def _active_client():
    for c, _loop in reversed(_clients):
        try:
            if not c.is_closed():
                return c
        except Exception:
            pass
    return None


def _install_hook():
    """Registra cada discord.Client que arranca para poder cerrarlo limpiamente."""
    try:
        import discord
    except Exception:
        return
    if getattr(discord.Client, "_bothost_hooked", False):
        return
    orig = discord.Client.start

    async def start(self, *args, **kwargs):
        _clients.append((self, asyncio.get_running_loop()))
        return await orig(self, *args, **kwargs)

    discord.Client.start = start

    orig_dispatch = discord.Client.dispatch

    def dispatch(self, event, *args, **kwargs):
        try:
            if not event.startswith("socket_"):
                _ev[event] = _ev.get(event, 0) + 1
        except Exception:
            pass
        return orig_dispatch(self, event, *args, **kwargs)

    discord.Client.dispatch = dispatch
    discord.Client._bothost_hooked = True


_last_alert = 0.0


def _alert(cfg, text, force=False, wait=False):
    """Avisa por webhook de Discord (si hay uno configurado). No bloquea (salvo wait) y limita el spam."""
    global _last_alert
    url = (cfg.get("webhook") or "").strip()
    if not url.startswith("https://"):
        return
    now = time.time()
    if not force and now - _last_alert < 45:
        return
    _last_alert = now

    def go():
        try:
            import urllib.request
            body = json.dumps({"content": ("[%s] %s" % (cfg.get("name", "bot"), text))[:1900],
                               "allowed_mentions": {"parse": []}}).encode("utf-8")
            req = urllib.request.Request(url, body, {"Content-Type": "application/json",
                                                     "User-Agent": "BotHost/1.2"})
            urllib.request.urlopen(req, timeout=10).read()
        except Exception as e:
            print("[host] no se pudo enviar la alerta: %s" % (e,))

    t = threading.Thread(target=go)
    t.daemon = True
    t.start()
    if wait:
        t.join(6)


def _write_json(path, obj):
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(obj, f)
        os.replace(path + ".tmp", path)
    except Exception:
        pass


def _heartbeat(bot_dir, started, cfg):
    path = os.path.join(bot_dir, "heartbeat.json")
    mpath = os.path.join(bot_dir, "metrics.json")
    st = {"over": {}, "cool": {}, "cfg_m": None}
    try:
        st["cfg_m"] = os.stat(os.path.join(bot_dir, "config.json")).st_mtime
    except OSError:
        pass
    hist = {"mem": [], "cpu": [], "ping": [], "ev": []}
    prev_cpu = None
    last_hist = 0.0
    last_gc = time.time()
    evwin = collections.deque()
    net0 = _net_bytes()
    bad_since = None  # desde cuando el cliente existe pero no esta conectado (watchdog)
    while not _stopping:
        now = time.time()
        _reload_cfg(bot_dir, cfg, st)
        interval = int(min(10, max(2, _num(cfg, "sampleSecs", 3))))

        mem, peak, threads = _proc_status()
        ticks = _cpu_ticks()
        cpu = 0.0
        if ticks is not None and prev_cpu is not None and now > prev_cpu[1]:
            cpu = round(max(0.0, (ticks - prev_cpu[0]) / float(_HZ) / (now - prev_cpu[1]) * 100.0), 1)
        if ticks is not None:
            prev_cpu = (ticks, now)

        total_ev = sum(_ev.values())
        evwin.append((now, total_ev))
        while evwin and now - evwin[0][0] > 60:
            evwin.popleft()
        evpm = 0
        if len(evwin) > 1 and evwin[-1][0] > evwin[0][0]:
            evpm = int(round((evwin[-1][1] - evwin[0][1]) * 60.0 / (evwin[-1][0] - evwin[0][0])))

        info = {
            "t": now,
            "started": started,
            "ready": False,
            "mem": mem,
            "peak": peak,
            "cpu": cpu,
            "threads": threads,
            "pid": os.getpid(),
            "interval": interval,
            "msgs": _ev.get("message", 0),
            "cmds": _ev.get("command", 0) + _ev.get("app_command_completion", 0),
            "errs": _ev.get("command_error", 0) + _ev.get("error", 0),
            "evts": total_ev,
            "evpm": evpm,
        }
        nb = _net_bytes()
        if nb is not None:
            if net0 is None:
                net0 = nb
            info["rx"] = max(0, nb[0] - net0[0])
            info["tx"] = max(0, nb[1] - net0[1])

        c = _active_client()
        if c is not None:
            try:
                info["ready"] = bool(c.is_ready())
                user = c.user
                info["user"] = str(user) if user else ""
                guilds = list(c.guilds)
                info["guilds"] = len(guilds)
                info["users"] = sum((g.member_count or 0) for g in guilds)
                info["channels"] = sum(len(g.channels) for g in guilds)
                info["voice"] = len(c.voice_clients)
                lat = c.latency
                info["ping"] = int(lat * 1000) if lat == lat and lat != float("inf") else -1
            except Exception:
                pass
            if info["ready"]:
                bad_since = None
            else:
                bad_since = bad_since or now
                if now - bad_since > 600 and cfg.get("autoRestart", True):
                    print("[host] watchdog: sin conexion a Discord hace 10 min; reiniciando")
                    _alert(cfg, "🟠 Watchdog: sin conexión a Discord hace 10 min; reiniciando", True)
                    bad_since = None
                    for cc, lp in list(_clients):
                        if cc is c:
                            try:
                                asyncio.run_coroutine_threadsafe(c.close(), lp)
                            except Exception:
                                pass
        else:
            bad_since = None

        _write_json(path, info)

        if now - last_hist >= max(5, interval):
            last_hist = now
            for k, v in (("mem", mem), ("cpu", cpu), ("ping", info.get("ping", -1)), ("ev", evpm)):
                lst = hist[k]
                lst.append(v)
                if len(lst) > 120:
                    del lst[0]
            _write_json(mpath, {"t": now, "step": max(5, interval), "mem": hist["mem"],
                                "cpu": hist["cpu"], "ping": hist["ping"], "ev": hist["ev"]})

        gm = _num(cfg, "gcMinutes")
        if gm > 0 and now - last_gc >= gm * 60:
            last_gc = now
            try:
                gc.collect()
            except Exception:
                pass

        try:
            _check_limits(bot_dir, cfg, st, info, started, now)
        except Exception:
            traceback.print_exc()
        time.sleep(interval)


def _apply_env(cfg):
    token = (cfg.get("token") or "").strip()
    if token:
        for k in ("DISCORD_TOKEN", "TOKEN", "BOT_TOKEN", "DISCORD_BOT_TOKEN"):
            os.environ[k] = token
    for line in (cfg.get("env") or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        if k:
            os.environ[k] = v


def run(bot_dir):
    """Ejecuta el archivo principal y lo reinicia si se cae (segun config). Bloquea hasta stop()."""
    global _stopping
    _stopping = False
    bot_dir = str(bot_dir)

    log = _Log(os.path.join(bot_dir, "log.txt"))
    sys.stdout = log
    sys.stderr = log

    try:
        os.chdir(bot_dir)
    except OSError:
        pass
    if bot_dir not in sys.path:
        sys.path.insert(0, bot_dir)

    try:
        with open(os.path.join(bot_dir, "config.json"), encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
    _apply_env(cfg)
    nv = int(min(19, max(0, _num(cfg, "nice", 0))))
    if nv > 0:  # en Linux es por hilo: los hilos que se creen despues lo heredan
        try:
            os.setpriority(os.PRIO_PROCESS, 0, nv)
            print("[host] prioridad de CPU baja (nice %d)" % nv)
        except Exception as e:
            print("[host] no se pudo cambiar la prioridad: %s" % (e,))
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    try:  # certificados CA propios por si el sistema no los expone a OpenSSL
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    libs = os.path.join(bot_dir, "libs")  # paquetes de Python puro copiados a mano
    if libs not in sys.path:
        sys.path.insert(1, libs)
    if not (cfg.get("token") or "").strip() and not os.environ.get("DISCORD_TOKEN"):
        print("[host] aviso: no hay token configurado (pegalo en la pantalla del bot)")
    _install_hook()

    t = threading.Thread(target=_heartbeat, args=(bot_dir, time.time(), cfg))
    t.daemon = True
    t.start()

    if cfg.get("installReqs", True):
        try:
            _install_requirements(bot_dir)
        except Exception:
            traceback.print_exc()

    try:
        _setup_music(bot_dir)
    except Exception:
        traceback.print_exc()

    entry_rel = (cfg.get("entry") or "main.py").strip().replace("\\", "/") or "main.py"
    entry = os.path.realpath(os.path.join(bot_dir, entry_rel))
    if not entry.startswith(os.path.realpath(bot_dir) + os.sep):
        entry = os.path.join(bot_dir, "main.py")
        entry_rel = "main.py"
    edir = os.path.dirname(entry)
    if edir != os.path.realpath(bot_dir) and edir not in sys.path:
        sys.path.insert(0, edir)  # como "python src/main.py": la carpeta del script va en sys.path
    _note_start(bot_dir)
    autorestart = bool(cfg.get("autoRestart", True))
    print("[host] Python %s - bot '%s' (%s)" % (sys.version.split()[0], cfg.get("name", "?"), entry_rel))
    _alert(cfg, "🟢 Iniciado", True)

    attempt = 0
    while not _stopping:
        started = time.time()
        fatal = False
        err = "el script terminó"
        hint_txt = None
        if not os.path.isfile(entry):
            print("[host] no existe el archivo principal '%s'. Elige otro en Avanzado > Archivo "
                  "principal (o usa 'Detectar')." % entry_rel)
            _alert(cfg, "⛔ Detenido: no existe el archivo principal %s" % entry_rel, True)
            break
        print("[host] iniciando %s" % entry_rel)
        try:
            runpy.run_path(entry, run_name="__main__")
            print("[host] el script termino")
        except SystemExit as e:
            print("[host] SystemExit: %s" % (e.code,))
            err = "SystemExit %s" % (e.code,)
        except BaseException as e:
            traceback.print_exc()
            err = ("%s: %s" % (type(e).__name__, e))[:300]
            h = _hint(e)
            if h:
                hint_txt = h[0]
                print("[host] %s" % h[0])
                fatal = h[1]

        if _restarting:
            while True:  # _restart_process mata el proceso en unos segundos
                time.sleep(1)
        if _stopping:
            break
        _note_crash(bot_dir, err, autorestart and not fatal)
        if fatal:
            print("[host] error que no se arregla reiniciando; deteniendo")
            _alert(cfg, "⛔ Detenido: %s" % (hint_txt or err), True)
            break
        if not autorestart:
            print("[host] auto-reinicio desactivado; deteniendo")
            _alert(cfg, "⏹ Detenido (auto-reinicio desactivado): %s" % err, True)
            break

        attempt = 0 if time.time() - started > 60 else attempt + 1
        delay = min(60, 5 * (2 ** (attempt - 1))) if attempt else 5
        print("[host] reiniciando en %ds" % delay)
        _alert(cfg, "🔴 Se cayó: %s. Reiniciando en %ds" % (err, delay))
        for _ in range(delay):
            if _stopping:
                break
            time.sleep(1)

    print("[host] bot detenido")
    log.flush()


def stop():
    """Cierra los clientes de discord con gracia (Java mata el proceso despues)."""
    global _stopping
    _stopping = True
    for client, loop in list(_clients):
        try:
            if not client.is_closed():
                fut = asyncio.run_coroutine_threadsafe(client.close(), loop)
                fut.result(timeout=6)
        except Exception as e:
            print("[host] error al cerrar: %s" % (e,))
