package com.mini.bothost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.FileOutputStream;
import java.io.IOException;

public class BotActivity extends Activity {

    private String id;
    private Store.Bot bot;
    private boolean deleted;

    private ScrollView sv;
    private LinearLayout content;
    private EditText name;
    private EditText token;
    private EditText env;
    private CheckBox autoRestart;
    private CheckBox autoStart;
    private TextView status;
    private TextView logView;
    private Button toggle;

    private String lastLog = null;
    private boolean restartPending;
    private long idleSince;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            h.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        id = getIntent().getStringExtra("id");
        bot = id == null ? null : Store.load(this, id);
        if (bot == null) {
            finish();
            return;
        }

        sv = new ScrollView(this);
        sv.setFitsSystemWindows(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        content.setPadding(p, p, p, p);
        sv.addView(content);
        setContentView(sv);

        content.addView(Ui.text(this, "Bot", 24, Ui.TXT, true));
        status = Ui.text(this, "", 14, Ui.TXT2, false);
        status.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        content.addView(status);

        // --- control ---
        LinearLayout ctl = row();
        toggle = Ui.button(this, "Iniciar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Store.isActive(BotActivity.this, bot)) {
                    BotService.stop(BotActivity.this, bot);
                    Ui.toast(BotActivity.this, "Deteniendo…");
                } else {
                    saveFields();
                    BotService.start(BotActivity.this, bot);
                    Ui.toast(BotActivity.this, "Iniciando…");
                }
                refresh();
            }
        });
        ctl.addView(toggle, weight());
        ctl.addView(Ui.button(this, "Reiniciar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFields();
                if (Store.isActive(BotActivity.this, bot)) {
                    BotService.stop(BotActivity.this, bot);
                    restartPending = true;
                    idleSince = 0;
                    Ui.toast(BotActivity.this, "Reiniciando…");
                } else {
                    BotService.start(BotActivity.this, bot);
                }
            }
        }), weight());
        content.addView(ctl);

        // --- configuracion ---
        content.addView(label("Nombre"));
        name = edit(bot.name, "Nombre del bot", false);
        content.addView(name);

        content.addView(label("Token de Discord (llega al código como DISCORD_TOKEN)"));
        token = edit(bot.token, "Pega aquí el token", false);
        token.setTransformationMethod(PasswordTransformationMethod.getInstance());
        content.addView(token);
        CheckBox show = check("Mostrar token", false);
        show.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                token.setTransformationMethod(on
                        ? HideReturnsTransformationMethod.getInstance()
                        : PasswordTransformationMethod.getInstance());
            }
        });
        content.addView(show);

        content.addView(label("Variables de entorno (una por línea: CLAVE=valor)"));
        env = edit(bot.env, "PREFIX=!\nOWNER_ID=123456789", true);
        content.addView(env);

        autoRestart = check("Reiniciar automáticamente si se cae", bot.autoRestart);
        content.addView(autoRestart);
        autoStart = check("Iniciar cuando se encienda el celular", bot.autoStart);
        content.addView(autoStart);

        LinearLayout r2 = row();
        r2.addView(Ui.button(this, "Guardar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFields();
                Ui.toast(BotActivity.this, "Guardado. Reinicia el bot para aplicar.");
            }
        }), weight());
        r2.addView(Ui.button(this, "Editar código", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFields();
                startActivity(new Intent(BotActivity.this, CodeActivity.class).putExtra("id", id));
            }
        }), weight());
        content.addView(r2);

        // --- logs ---
        TextView logTitle = Ui.text(this, "Logs", 18, Ui.TXT, true);
        logTitle.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
        content.addView(logTitle);
        LinearLayout r3 = row();
        r3.addView(Ui.button(this, "Copiar log", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("log",
                            Store.readTail(Store.logFile(BotActivity.this, id), 200000)));
                    Ui.toast(BotActivity.this, "Log copiado");
                }
            }
        }), weight());
        r3.addView(Ui.button(this, "Limpiar log", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    new FileOutputStream(Store.logFile(BotActivity.this, id)).close();
                } catch (IOException ignored) {
                    // nada
                }
                lastLog = null;
                refresh();
            }
        }), weight());
        content.addView(r3);

        logView = Ui.text(this, "", 11, 0xFFB0BEC5, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setBackground(Ui.card(this));
        logView.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10));
        content.addView(logView);

        Button del = Ui.button(this, "Eliminar bot", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDelete();
            }
        });
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = Ui.dp(this, 20);
        content.addView(del, dlp);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bot != null) {
            h.post(tick);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        if (bot != null && !deleted) {
            saveFields();
        }
    }

    // ---------- logica ----------

    private void saveFields() {
        String n = name.getText().toString().trim();
        if (!n.isEmpty()) {
            bot.name = n;
        }
        bot.token = token.getText().toString().trim();
        bot.env = env.getText().toString();
        bot.autoRestart = autoRestart.isChecked();
        bot.autoStart = autoStart.isChecked();
        Store.save(this, bot);
    }

    private void refresh() {
        boolean active = Store.isActive(this, bot);
        status.setText(Store.statusText(this, bot));
        toggle.setText(active ? "Detener" : "Iniciar");

        if (restartPending) {
            if (active) {
                idleSince = 0;
            } else if (idleSince == 0) {
                idleSince = System.currentTimeMillis();
            } else if (System.currentTimeMillis() - idleSince >= 1000) {
                restartPending = false;
                BotService.start(this, bot);
            }
        }

        String t = Store.readTail(Store.logFile(this, id), 6000);
        if (!t.equals(lastLog)) {
            boolean atBottom = sv.getScrollY() + sv.getHeight() >= content.getHeight() - Ui.dp(this, 80);
            lastLog = t;
            logView.setText(t.isEmpty() ? "(sin logs todavía)" : t);
            if (atBottom) {
                sv.post(new Runnable() {
                    @Override
                    public void run() {
                        sv.scrollTo(0, content.getHeight());
                    }
                });
            }
        }
    }

    private void confirmDelete() {
        if (Store.isActive(this, bot)) {
            Ui.toast(this, "Detén el bot antes de eliminarlo");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Eliminar “" + bot.name + "”")
                .setMessage("Se borrarán su código, configuración y logs.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        deleted = true;
                        Store.delete(BotActivity.this, id);
                        finish();
                    }
                })
                .show();
    }

    // ---------- helpers de UI ----------

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 13, Ui.TXT2, false);
        t.setPadding(0, Ui.dp(this, 14), 0, 0);
        return t;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(Ui.TXT);
        c.setChecked(on);
        return c;
    }

    private EditText edit(String value, String hint, boolean multiline) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(Ui.TXT);
        e.setHintTextColor(0x66FFFFFF);
        if (multiline) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
        }
        return e;
    }
}
