# Bot Host

App Android para hostear bots de Discord en Python (discord.py) directamente en el celular.
Python viene embebido con Chaquopy; cada bot corre en su propio proceso.

## Incluido
discord.py (con aiohttp), requests, python-dotenv, aiosqlite, pytz, tzdata, aiofiles, python-dateutil, beautifulsoup4.
Para agregar más librerías edita `app/build.gradle` (bloque `pip { install "paquete" }`).
Solo funcionan paquetes puros de Python o que Chaquopy ya tenga compilados para Android.

## Cómo usarla
1. Instala el APK y acepta las notificaciones.
2. Toca **Ahorro de batería** y elige **Sin restricciones** (si no, Android puede cerrar los bots).
3. **+ Nuevo bot** (trae un ejemplo con `!ping`) o **Importar .py** con tu archivo.
4. Dentro del bot pega el **token**; en el código léelo con `os.getenv("DISCORD_TOKEN")`.
5. **Iniciar**. Verás estado, servidores, ping, RAM y logs en vivo (también en la notificación).
6. **Archivos del bot**: agrega cogs, .json, etc. (puedes usar subcarpetas como `cogs/musica.py`), edítalos, expórtalos o bórralos.
7. **Iniciar todos / Detener todos** desde la pantalla principal; **Compartir** envía el log por cualquier app.

## Compilar
- Android Studio: abre la carpeta y *Build > Build APK(s)*.
- GitHub: sube el proyecto; `.github/workflows/build.yml` compila y deja el APK en *Actions > Artifacts*.
  Para poder actualizar encima de versiones anteriores, guarda tu keystore en base64 en el secret `KEYSTORE_BASE64`.

## Notas
- Si falta un módulo, el log lo explica y el bot se detiene (reiniciar no lo arreglaría). Lo mismo con token inválido, intents privilegiados sin activar o errores de sintaxis.
- Paquetes de Python puro se pueden copiar a mano en la carpeta `libs/` del bot (ya está en `sys.path`).
- Los bots marcados con "Iniciar cuando se encienda el celular" también se reinician tras actualizar la app.
- Máximo 4 bots a la vez (un proceso por bot). Para más, agrega clases `S4`, `S5`… en `BotService.java` y su `<service>` en el manifest.
- Usa `bot.run(TOKEN)` o `asyncio.run(...)` con `bot.start(...)`; ambos se detienen limpio.
- El token también queda como `TOKEN` y `BOT_TOKEN`; las variables del bot se cargan en `os.environ`.
- Sin voz (PyNaCl no está incluido) para mantener la app liviana.
