package com.mini.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Launcher minimo: reloj, buscador y lista alfabetica de apps.
 * Sin librerias, sin layouts XML ni iconos: pesa muy poco y gasta poca RAM.
 */
public class MainActivity extends Activity {

    private static class App {
        String label;
        String lower;
        String pkg;
        ComponentName cn;
    }

    private final ArrayList<App> all = new ArrayList<>();
    private final ArrayList<App> shown = new ArrayList<>();
    private AppAdapter adapter;
    private EditText search;
    private ListView list;
    private LinearLayout root;
    private float d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        d = getResources().getDisplayMetrics().density;

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0x88000000); // velo oscuro sobre el fondo de pantalla
        root.setFitsSystemWindows(true);
        root.setFocusableInTouchMode(true);

        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 56);
        clock.setTextColor(Color.WHITE);
        clock.setPadding(dp(24), dp(16), dp(24), 0);
        root.addView(clock, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, d MMMM");
        date.setFormat24Hour("EEEE, d MMMM");
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        date.setTextColor(0xCCFFFFFF);
        date.setPadding(dp(26), 0, dp(24), dp(12));
        root.addView(date, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        search = new EditText(this);
        search.setHint("Buscar app");
        search.setHintTextColor(0x99FFFFFF);
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_GO);
        search.setBackgroundColor(0x33FFFFFF);
        search.setPadding(dp(16), dp(10), dp(16), dp(10));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(dp(16), 0, dp(16), dp(8));
        root.addView(search, sp);

        list = new ListView(this);
        list.setDivider(null);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setFastScrollEnabled(true);
        adapter = new AppAdapter();
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { filter(); }
            @Override public void afterTextChanged(Editable s) { }
        });

        // Al pulsar "Ir" en el teclado abre el primer resultado
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (!shown.isEmpty()) {
                    launch(shown.get(0));
                }
                return true;
            }
        });

        list.setOnItemClickListener((parent, view, position, id) -> launch(shown.get(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            showOptions(shown.get(position));
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        filter();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Boton Home: limpiar busqueda y volver al inicio de la lista
        resetUi();
    }

    @Override
    public void onBackPressed() {
        // Un launcher no se cierra con "atras"
        resetUi();
    }

    private void resetUi() {
        search.setText("");
        hideKeyboard();
        list.setSelection(0);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
        }
        search.clearFocus();
        root.requestFocus();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        all.clear();
        for (ResolveInfo r : found) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) {
                continue;
            }
            App a = new App();
            a.label = String.valueOf(r.loadLabel(pm));
            a.lower = a.label.toLowerCase();
            a.pkg = pkg;
            a.cn = new ComponentName(pkg, r.activityInfo.name);
            all.add(a);
        }
        Collections.sort(all, new Comparator<App>() {
            @Override
            public int compare(App x, App y) {
                return x.lower.compareTo(y.lower);
            }
        });
    }

    private void filter() {
        String q = search.getText().toString().trim().toLowerCase();
        shown.clear();
        for (App a : all) {
            if (q.isEmpty() || a.lower.contains(q)) {
                shown.add(a);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void launch(App a) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void showOptions(final App a) {
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(new String[]{"Info de la app", "Desinstalar"},
                        (dialog, which) -> {
                            Uri uri = Uri.fromParts("package", a.pkg, null);
                            Intent i = (which == 0)
                                    ? new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
                                    : new Intent(Intent.ACTION_DELETE, uri);
                            try {
                                startActivity(i);
                            } catch (Exception e) {
                                Toast.makeText(this, "No disponible", Toast.LENGTH_SHORT).show();
                            }
                        })
                .show();
    }

    private int dp(int v) {
        return (int) (v * d + 0.5f);
    }

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int position) { return shown.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView t = (TextView) convertView;
            if (t == null) {
                t = new TextView(MainActivity.this);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                t.setTextColor(Color.WHITE);
                t.setSingleLine(true);
                t.setPadding(dp(28), dp(14), dp(24), dp(14));
            }
            t.setText(shown.get(position).label);
            return t;
        }
    }
}
