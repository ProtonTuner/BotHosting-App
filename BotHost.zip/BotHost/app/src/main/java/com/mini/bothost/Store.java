package com.mini.bothost;

import android.content.Context;
import android.net.Uri;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Persistencia en archivos (la leen varios procesos, por eso no usamos SharedPreferences).
 * filesDir/bots/ID/{config.json, main.py, log.txt, heartbeat.json}
 * filesDir/slots/slotN  -> id del bot que ocupa el proceso N mientras corre
 */
final class Store {
    static final int MAX_BOTS = 4;

    static final String TEMPLATE =
            "import os\n"
            + "import discord\n"
            + "from discord.ext import commands\n"
            + "\n"
            + "TOKEN = os.getenv(\"DISCORD_TOKEN\")  # se configura en la pantalla del bot\n"
            + "\n"
            + "intents = discord.Intents.default()\n"
            + "intents.message_content = True  # activalo tambien en el Developer Portal\n"
            + "bot = commands.Bot(command_prefix=\"!\", intents=intents)\n"
            + "\n"
            + "\n"
            + "@bot.event\n"
            + "async def on_ready():\n"
            + "    print(f\"Conectado como {bot.user}\")\n"
            + "\n"
            + "\n"
            + "@bot.command()\n"
            + "async def ping(ctx):\n"
            + "    await ctx.send(f\"Pong! {round(bot.latency * 1000)} ms\")\n"
            + "\n"
            + "\n"
            + "bot.run(TOKEN)\n";

    static class Bot {
        String id = "";
        String name = "Bot";
        String token = "";
        String env = "";
        boolean autoRestart = true;
        boolean autoStart = false;
        int slot = 0;
    }

    private Store() { }

    // ---------- rutas ----------

    static File botsDir(Context c) {
        File f = new File(c.getFilesDir(), "bots");
        if (!f.exists()) {
            f.mkdirs();
        }
        return f;
    }

    static File dir(Context c, String id) {
        return new File(botsDir(c), id);
    }

    static File mainPy(Context c, String id) {
        return new File(dir(c, id), "main.py");
    }

    static File logFile(Context c, String id) {
        return new File(dir(c, id), "log.txt");
    }

    static File heartbeatFile(Context c, String id) {
        return new File(dir(c, id), "heartbeat.json");
    }

    static File slotFile(Context c, int slot) {
        File d = new File(c.getFilesDir(), "slots");
        if (!d.exists()) {
            d.mkdirs();
        }
        return new File(d, "slot" + slot);
    }

    // ---------- bots ----------

    static List<Bot> list(Context c) {
        List<Bot> out = new ArrayList<>();
        File[] dirs = botsDir(c).listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                Bot b = load(c, d.getName());
                if (b != null) {
                    out.add(b);
                }
            }
        }
        Collections.sort(out, new Comparator<Bot>() {
            @Override
            public int compare(Bot a, Bot b) {
                return a.slot - b.slot;
            }
        });
        return out;
    }

    static Bot load(Context c, String id) {
        File f = new File(dir(c, id), "config.json");
        if (!f.exists()) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(readText(f));
            Bot b = new Bot();
            b.id = id;
            b.name = o.optString("name", "Bot");
            b.token = o.optString("token", "");
            b.env = o.optString("env", "");
            b.autoRestart = o.optBoolean("autoRestart", true);
            b.autoStart = o.optBoolean("autoStart", false);
            b.slot = o.optInt("slot", 0);
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    static void save(Context c, Bot b) {
        try {
            JSONObject o = new JSONObject();
            o.put("name", b.name);
            o.put("token", b.token);
            o.put("env", b.env);
            o.put("autoRestart", b.autoRestart);
            o.put("autoStart", b.autoStart);
            o.put("slot", b.slot);
            writeText(new File(dir(c, b.id), "config.json"), o.toString());
        } catch (JSONException ignored) {
            // no deberia pasar
        }
    }

    /** Devuelve null si ya hay MAX_BOTS. */
    static Bot create(Context c, String name, String code) {
        boolean[] used = new boolean[MAX_BOTS];
        for (Bot x : list(c)) {
            if (x.slot >= 0 && x.slot < MAX_BOTS) {
                used[x.slot] = true;
            }
        }
        int slot = -1;
        for (int i = 0; i < MAX_BOTS; i++) {
            if (!used[i]) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            return null;
        }
        Bot b = new Bot();
        b.id = UUID.randomUUID().toString().substring(0, 8);
        b.name = name;
        b.slot = slot;
        dir(c, b.id).mkdirs();
        writeText(mainPy(c, b.id), code);
        save(c, b);
        return b;
    }

    static void delete(Context c, String id) {
        Bot b = load(c, id);
        if (b != null) {
            slotFile(c, b.slot).delete();
        }
        deleteRec(dir(c, id));
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                deleteRec(k);
            }
        }
        f.delete();
    }

    // ---------- archivos extra del bot (cogs, json, etc.) ----------

    private static final String[] HIDDEN = {
            "config.json", "log.txt", "log.txt.1", "heartbeat.json", "heartbeat.json.tmp"};

    private static boolean isHidden(String rel) {
        for (String h : HIDDEN) {
            if (h.equals(rel)) {
                return true;
            }
        }
        return false;
    }

    /** Ruta segura dentro de la carpeta del bot, o null si no es valida. */
    static File resolve(Context c, String id, String rel) {
        if (rel == null) {
            return null;
        }
        rel = rel.trim().replace('\\', '/');
        while (rel.startsWith("/")) {
            rel = rel.substring(1);
        }
        if (rel.isEmpty() || rel.contains("..") || rel.endsWith("/") || isHidden(rel)) {
            return null;
        }
        return new File(dir(c, id), rel);
    }

    /** Archivos del usuario (rutas relativas), sin config/logs/__pycache__/libs. */
    static List<String> userFiles(Context c, String id) {
        List<String> out = new ArrayList<>();
        collect(dir(c, id), "", 0, out);
        Collections.sort(out);
        return out;
    }

    private static void collect(File d, String prefix, int depth, List<String> out) {
        File[] kids = d.listFiles();
        if (kids == null) {
            return;
        }
        for (File k : kids) {
            String name = k.getName();
            String rel = prefix + name;
            if (k.isDirectory()) {
                if (depth < 3 && !name.equals("__pycache__") && !name.equals("libs")) {
                    collect(k, rel + "/", depth + 1, out);
                }
            } else if (!isHidden(rel) && !name.endsWith(".pyc")) {
                out.add(rel);
            }
        }
    }

    static boolean isTextName(String n) {
        n = n.toLowerCase(Locale.ROOT);
        String[] ok = {".py", ".txt", ".json", ".env", ".md", ".yml", ".yaml", ".csv", ".ini", ".toml", ".cfg"};
        for (String e : ok) {
            if (n.endsWith(e)) {
                return true;
            }
        }
        return false;
    }

    /** Copia binaria uri -> archivo. */
    static boolean copyFromUri(Context c, Uri uri, File dest) {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = c.getContentResolver().openInputStream(uri);
            if (in == null) {
                return false;
            }
            File p = dest.getParentFile();
            if (p != null && !p.exists()) {
                p.mkdirs();
            }
            out = new FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    /**
     * Extrae un zip dentro de destDir. Evita rutas peligrosas (zip-slip), ignora __MACOSX y los
     * archivos internos del host, quita la carpeta raiz si todo viene dentro de una sola, y corta
     * si pasa de 100 MB. Devuelve cuantos archivos extrajo, o -1 si fallo.
     */
    static int unzip(File zip, File destDir) {
        java.util.zip.ZipFile zf = null;
        try {
            zf = new java.util.zip.ZipFile(zip);
            String common = null;
            boolean single = true;
            java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName().replace('\\', '/');
                if (n.startsWith("__MACOSX/")) {
                    continue;
                }
                int i = n.indexOf('/');
                if (i < 0) {
                    single = false;
                    break;
                }
                String top = n.substring(0, i + 1);
                if (common == null) {
                    common = top;
                } else if (!common.equals(top)) {
                    single = false;
                    break;
                }
            }
            String strip = (single && common != null) ? common : "";
            String root = destDir.getCanonicalPath() + File.separator;
            long total = 0;
            int count = 0;
            en = zf.entries();
            while (en.hasMoreElements()) {
                java.util.zip.ZipEntry e = en.nextElement();
                String n = e.getName().replace('\\', '/');
                if (n.startsWith("__MACOSX/") || e.isDirectory()) {
                    continue;
                }
                if (!strip.isEmpty() && n.startsWith(strip)) {
                    n = n.substring(strip.length());
                }
                if (n.isEmpty() || isHidden(n)) {
                    continue;
                }
                File out = new File(destDir, n);
                if (!out.getCanonicalPath().startsWith(root)) {
                    continue;
                }
                File p = out.getParentFile();
                if (p != null && !p.exists()) {
                    p.mkdirs();
                }
                InputStream in = zf.getInputStream(e);
                FileOutputStream fo = new FileOutputStream(out);
                try {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = in.read(buf)) != -1) {
                        total += r;
                        if (total > 100L * 1024 * 1024) {
                            return -1;
                        }
                        fo.write(buf, 0, r);
                    }
                } finally {
                    in.close();
                    fo.close();
                }
                count++;
            }
            return count;
        } catch (IOException e) {
            return -1;
        } finally {
            try {
                if (zf != null) {
                    zf.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    /** Copia binaria archivo -> uri (para exportar). */
    static boolean copyToUri(Context c, File src, Uri uri) {
        InputStream in = null;
        java.io.OutputStream out = null;
        try {
            in = new java.io.FileInputStream(src);
            out = c.getContentResolver().openOutputStream(uri);
            if (out == null) {
                return false;
            }
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException ignored) {
                // nada
            }
        }
    }

    // ---------- estado ----------

    /** Texto corto para la notificacion. */
    static String shortStatus(Context c, Bot b) {
        JSONObject hb = heartbeat(c, b.id);
        if (hb == null) {
            return "Iniciando…";
        }
        if (!hb.optBoolean("ready")) {
            return "Conectando…";
        }
        String s = "En línea · " + hb.optInt("guilds", 0) + " servidores";
        int ping = hb.optInt("ping", -1);
        if (ping >= 0) {
            s += " · " + ping + " ms";
        }
        return s;
    }

    /** Latido escrito por Python cada 3 s; null si no hay o esta viejo. */
    static JSONObject heartbeat(Context c, String id) {
        File f = heartbeatFile(c, id);
        if (!f.exists()) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(readText(f));
            double age = System.currentTimeMillis() / 1000.0 - o.optDouble("t", 0);
            return age < 12 ? o : null;
        } catch (Exception e) {
            return null;
        }
    }

    static boolean starting(Context c, Bot b) {
        File sf = slotFile(c, b.slot);
        return sf.exists()
                && System.currentTimeMillis() - sf.lastModified() < 45000
                && readText(sf).trim().equals(b.id);
    }

    static boolean isActive(Context c, Bot b) {
        return heartbeat(c, b.id) != null || starting(c, b);
    }

    static String statusText(Context c, Bot b) {
        JSONObject hb = heartbeat(c, b.id);
        if (hb != null) {
            boolean ready = hb.optBoolean("ready");
            StringBuilder sb = new StringBuilder(ready ? "● En línea" : "◐ Conectando…");
            if (ready) {
                String user = hb.optString("user", "");
                if (!user.isEmpty()) {
                    sb.append(" · ").append(user);
                }
                sb.append(" · ").append(hb.optInt("guilds", 0)).append(" servidores");
                int ping = hb.optInt("ping", -1);
                if (ping >= 0) {
                    sb.append(" · ").append(ping).append(" ms");
                }
            }
            sb.append("\nRAM ").append(Math.round(hb.optDouble("mem", 0))).append(" MB");
            long up = (long) (System.currentTimeMillis() / 1000.0 - hb.optDouble("started", 0));
            sb.append(" · activo ").append(fmtDur(Math.max(0, up)));
            return sb.toString();
        }
        if (starting(c, b)) {
            return "◐ Iniciando…";
        }
        return "○ Detenido";
    }

    private static String fmtDur(long s) {
        if (s < 60) {
            return s + "s";
        }
        if (s < 3600) {
            return (s / 60) + "m";
        }
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }

    // ---------- archivos ----------

    static String readText(File f) {
        return readTail(f, 4 * 1024 * 1024);
    }

    static String readTail(File f, int maxBytes) {
        if (f == null || !f.exists()) {
            return "";
        }
        RandomAccessFile r = null;
        try {
            r = new RandomAccessFile(f, "r");
            long len = r.length();
            long start = Math.max(0L, len - (long) maxBytes);
            r.seek(start);
            byte[] buf = new byte[(int) (len - start)];
            r.readFully(buf);
            String s = new String(buf, StandardCharsets.UTF_8);
            if (start > 0) {
                int nl = s.indexOf('\n');
                if (nl >= 0) {
                    s = s.substring(nl + 1);
                }
            }
            return s;
        } catch (IOException e) {
            return "";
        } finally {
            if (r != null) {
                try {
                    r.close();
                } catch (IOException ignored) {
                    // nada
                }
            }
        }
    }

    static void writeText(File f, String s) {
        try {
            File p = f.getParentFile();
            if (p != null && !p.exists()) {
                p.mkdirs();
            }
            FileOutputStream o = new FileOutputStream(f);
            try {
                o.write(s.getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
            // sin espacio o sin permisos: no hay mucho que hacer
        }
    }

    static void appendLog(Context c, String id, String msg) {
        try {
            String line = new SimpleDateFormat("HH:mm:ss ", Locale.US).format(new Date()) + msg + "\n";
            FileOutputStream o = new FileOutputStream(logFile(c, id), true);
            try {
                o.write(line.getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
            // nada
        }
    }
}
