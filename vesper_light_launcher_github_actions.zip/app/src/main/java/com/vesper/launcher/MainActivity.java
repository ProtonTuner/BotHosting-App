package com.vesper.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(13, 15, 27);
    private final int panel = Color.rgb(26, 29, 48);
    private final int accent = Color.rgb(163, 111, 255);
    private final int ink = Color.rgb(245, 245, 252);
    private final int muted = Color.rgb(164, 169, 191);
    private final List<AppEntry> allApps = new ArrayList<>();
    private final List<AppEntry> shownApps = new ArrayList<>();
    private AppsAdapter adapter;
    private EditText search;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildApps();
        buildUi();
    }

    private void buildApps() {
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(intent, 0);
        allApps.clear();
        for (ResolveInfo ri : found) {
            if (ri.activityInfo == null || getPackageName().equals(ri.activityInfo.packageName)) continue;
            AppEntry e = new AppEntry();
            e.label = ri.loadLabel(pm).toString();
            e.pkg = ri.activityInfo.packageName;
            e.activity = ri.activityInfo.name;
            e.icon = ri.loadIcon(pm);
            allApps.add(e);
        }
        Collections.sort(allApps, (a,b) -> a.label.compareToIgnoreCase(b.label));
        shownApps.clear();
        shownApps.addAll(allApps);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(8));
        root.setBackgroundColor(bg);

        TextView brand = text("VESPER", 13, accent, true);
        brand.setLetterSpacing(0.18f);
        root.addView(brand);

        TextView clock = text(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 42, ink, true);
        clock.setPadding(0, dp(12), 0, 0);
        root.addView(clock);

        TextView date = text(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()), 14, muted, false);
        root.addView(date);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.setGravity(Gravity.CENTER_VERTICAL);
        quick.setPadding(dp(14), dp(12), dp(14), dp(12));
        quick.setBackground(round(panel, 18));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, dp(58));
        qlp.topMargin = dp(20);
        root.addView(quick, qlp);
        TextView mark = text("⌕", 25, accent, true);
        quick.addView(mark);
        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(ink);
        search.setHintTextColor(muted);
        search.setHint("Buscar aplicaciones");
        search.setTextSize(15);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(dp(10), 0, 0, 0);
        quick.addView(search, new LinearLayout.LayoutParams(0, -1, 1));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) { filter(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(0, dp(18), 0, dp(8));
        TextView appsLabel = text("Aplicaciones", 18, ink, true);
        heading.addView(appsLabel, new LinearLayout.LayoutParams(0, -2, 1));
        TextView count = text(String.valueOf(allApps.size()), 12, muted, false);
        count.setTag("count");
        heading.addView(count);
        root.addView(heading);

        GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(dp(12));
        grid.setHorizontalSpacing(dp(4));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        adapter = new AppsAdapter();
        grid.setAdapter(adapter);
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("Ligero · privado · sin anuncios", 11, muted, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(10), 0, dp(6));
        root.addView(footer);
        setContentView(root);
    }

    private void filter(String q) {
        shownApps.clear();
        String needle = q.toLowerCase(Locale.getDefault()).trim();
        for (AppEntry a : allApps) if (a.label.toLowerCase(Locale.getDefault()).contains(needle)) shownApps.add(a);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private class AppsAdapter extends BaseAdapter {
        public int getCount() { return shownApps.size(); }
        public Object getItem(int p) { return shownApps.get(p); }
        public long getItemId(int p) { return p; }
        public View getView(int position, View convert, ViewGroup parent) {
            AppEntry app = shownApps.get(position);
            LinearLayout cell = new LinearLayout(MainActivity.this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(2), dp(8), dp(2), dp(6));
            android.widget.ImageView icon = new android.widget.ImageView(MainActivity.this);
            icon.setImageDrawable(app.icon);
            cell.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
            TextView label = text(app.label, 10.5f, ink, false);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(30));
            lp.topMargin = dp(5);
            cell.addView(label, lp);
            cell.setOnClickListener(v -> {
                try {
                    Intent launch = new Intent(Intent.ACTION_MAIN);
                    launch.addCategory(Intent.CATEGORY_LAUNCHER);
                    launch.setClassName(app.pkg, app.activity);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                } catch (Exception ex) {
                    new AlertDialog.Builder(MainActivity.this).setMessage("No se pudo abrir esta aplicación.").setPositiveButton("OK", null).show();
                }
            });
            cell.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle(app.label)
                    .setItems(new String[]{"Abrir", "Información de la aplicación"}, (dialog, which) -> {
                        if (which == 0) {
                            try { startActivity(getPackageManager().getLaunchIntentForPackage(app.pkg)); } catch (Exception ignored) {}
                        } else {
                            Intent info = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            info.setData(android.net.Uri.parse("package:" + app.pkg));
                            startActivity(info);
                        }
                    }).show();
                return true;
            });
            return cell;
        }
    }

    private static class AppEntry {
        String label, pkg, activity;
        android.graphics.drawable.Drawable icon;
    }
}
