#!/usr/bin/env python3
"""Compila `davey` (Rust, protocolo DAVE de Discord) para Android arm64 y arma un wheel
que Chaquopy puede instalar. Pensado para correr en GitHub Actions (ubuntu + NDK + Rust).

Uso: make_davey_wheel.py --pylib <carpeta con libpython3.11.so de Chaquopy> --out app/wheels
"""
import argparse
import base64
import glob
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
import zipfile

PYVER = "3.11"
API = 21  # mismo nivel que usan los wheels de Chaquopy (android_21_*)


def sh(cmd, **kw):
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True, **kw)


def rec_hash(data):
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pylib", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    ndk = (os.environ.get("ANDROID_NDK_LATEST_HOME") or os.environ.get("ANDROID_NDK_HOME")
           or os.environ.get("ANDROID_NDK_ROOT"))
    if not ndk:
        sys.exit("No encuentro el NDK (ANDROID_NDK_HOME)")
    bin_dir = os.path.join(ndk, "toolchains", "llvm", "prebuilt", "linux-x86_64", "bin")
    clang = os.path.join(bin_dir, "aarch64-linux-android%d-clang" % API)
    pylib = os.path.abspath(a.pylib)
    if not os.path.exists(os.path.join(pylib, "libpython%s.so" % PYVER)):
        sys.exit("Falta libpython%s.so en %s" % (PYVER, pylib))

    meta = json.load(urllib.request.urlopen("https://pypi.org/pypi/davey/json"))
    ver = meta["info"]["version"]
    url = next(f["url"] for f in meta["urls"] if f["packagetype"] == "sdist")
    tmp = tempfile.mkdtemp()
    tgz = os.path.join(tmp, "davey.tar.gz")
    urllib.request.urlretrieve(url, tgz)
    with tarfile.open(tgz) as t:
        t.extractall(tmp)
    src = glob.glob(os.path.join(tmp, "davey-*", ""))[0]
    print("davey", ver, "->", src, flush=True)

    env = dict(os.environ)
    env.update({
        "CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER": clang,
        "PYO3_CROSS": "1",
        "PYO3_CROSS_LIB_DIR": pylib,
        "PYO3_CROSS_PYTHON_VERSION": PYVER,
        "PYO3_CROSS_PYTHON_IMPLEMENTATION": "CPython",
        "RUSTFLAGS": "-C link-arg=-L%s -C link-arg=-lpython%s -C link-arg=-Wl,-z,max-page-size=16384"
                     % (pylib, PYVER),
    })
    sh(["cargo", "build", "--release", "--target", "aarch64-linux-android",
        "-p", "davey-python", "--features", "pyo3/extension-module"], cwd=src, env=env)
    so = os.path.join(src, "target", "aarch64-linux-android", "release", "libdavey.so")
    if not os.path.exists(so):
        sys.exit("No se generó " + so)

    tag = "cp%s-cp%s-android_%d_arm64_v8a" % (PYVER.replace(".", ""), PYVER.replace(".", ""), API)
    di = "davey-%s.dist-info" % ver
    files = {
        "davey.so": open(so, "rb").read(),
        di + "/METADATA": ("Metadata-Version: 2.1\nName: davey\nVersion: %s\n"
                           "Summary: DAVE protocol (Android arm64 build)\nRequires-Python: >=3.8\n"
                           "License: MIT\n" % ver).encode(),
        di + "/WHEEL": ("Wheel-Version: 1.0\nGenerator: bothost\nRoot-Is-Purelib: false\nTag: %s\n"
                        % tag).encode(),
    }
    record = "".join("%s,%s,%d\n" % (n, rec_hash(d), len(d)) for n, d in files.items())
    record += di + "/RECORD,,\n"
    files[di + "/RECORD"] = record.encode()

    os.makedirs(a.out, exist_ok=True)
    for old in glob.glob(os.path.join(a.out, "davey-*.whl")):
        os.remove(old)
    out = os.path.join(a.out, "davey-%s-%s.whl" % (ver, tag))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in files.items():
            z.writestr(n, d)
    print("OK ->", out, os.path.getsize(out) // 1024, "KB")


if __name__ == "__main__":
    main()
