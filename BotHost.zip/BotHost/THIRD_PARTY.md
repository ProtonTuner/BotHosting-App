# Componentes de terceros (música opcional)

- **ffmpeg** (build estático arm64 de `imageio-ffmpeg` 0.6.0, compilado con `--enable-gpl --enable-version3`):
  licencia **GPL v3**. Código fuente y build: https://ffmpeg.org y https://github.com/imageio/imageio-ffmpeg.
  Si distribuyes un APK que lo incluye (por ejemplo en Play Store) debes cumplir la GPL (texto de la licencia y
  oferta/enlace del código fuente). Para uso personal con repositorio privado no hay distribución.
- **libopus** 1.5.2 (BSD-3-Clause): https://opus-codec.org
- **davey** (MIT): https://github.com/Snazzah/davey
- **PyNaCl** (Apache-2.0) y **libsodium** (ISC).
