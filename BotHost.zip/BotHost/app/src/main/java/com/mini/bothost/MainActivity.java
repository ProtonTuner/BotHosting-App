package com.mini.bothost;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_IMPORT = 7;

    private LinearLayout list;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            render();
            h.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        sv.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, p, p, p);
        sv.addView(root);
        setContentView(sv);

        root.addView(Ui.text(this, "Bot Host", 28, Ui.TXT, true));
        TextView sub = Ui.text(this, "Hosting de bots de Discord (Python) en tu celular", 14, Ui.TXT2, false);
        sub.setPadding(0, 0, 0, Ui.dp(this, 12));
        root.addView(sub);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(Ui.button(this, "+ Nuevo bot", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newBot();
            }
        }), weight());
        row1.addView(Ui.button(this, "Importar .py", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_IMPORT);
            }
        }), weight());
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(Ui.button(this, "Ahorro de batería", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                batterySettings();
            }
        }), weight());
        row2.addView(Ui.button(this, "Detener todos", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Store.Bot b : Store.list(MainActivity.this)) {
                    if (Store.isActive(MainActivity.this, b)) {
                        BotService.stop(MainActivity.this, b);
                    }
                }
                Ui.toast(MainActivity.this, "Deteniendo…");
            }
        }), weight());
        root.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.addView(Ui.button(this, "Iniciar todos", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Store.Bot b : Store.list(MainActivity.this)) {
                    if (!Store.isActive(MainActivity.this, b)) {
                        BotService.start(MainActivity.this, b);
                    }
                }
                Ui.toast(MainActivity.this, "Iniciando…");
            }
        }), weight());
        root.addView(row3);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        root.addView(list, lp);

        TextView tip = Ui.text(this,
                "Consejo: pulsa “Ahorro de batería” y elige “Sin restricciones” para que Android "
                        + "no cierre tus bots. Máximo " + Store.MAX_BOTS + " bots a la vez.",
                12, Ui.TXT2, false);
        tip.setPadding(0, Ui.dp(this, 16), 0, 0);
        root.addView(tip);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    private void render() {
        list.removeAllViews();
        List<Store.Bot> bots = Store.list(this);
        if (bots.isEmpty()) {
            TextView empty = Ui.text(this, "Aún no tienes bots.\nToca “+ Nuevo bot” o importa tu archivo .py.",
                    15, Ui.TXT2, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, Ui.dp(this, 32), 0, Ui.dp(this, 32));
            list.addView(empty);
            return;
        }
        for (final Store.Bot b : bots) {
            final boolean active = Store.isActive(this, b);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Ui.card(this));
            int pad = Ui.dp(this, 14);
            card.setPadding(pad, pad, pad, pad);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(this, 10);
            card.setLayoutParams(lp);

            card.addView(Ui.text(this, b.name, 18, Ui.TXT, true));
            TextView st = Ui.text(this, Store.statusText(this, b), 13, Ui.TXT2, false);
            st.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 6));
            card.addView(st);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            Button toggle = Ui.button(this, active ? "Detener" : "Iniciar", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (active) {
                        BotService.stop(MainActivity.this, b);
                        Ui.toast(MainActivity.this, "Deteniendo…");
                    } else {
                        BotService.start(MainActivity.this, b);
                        Ui.toast(MainActivity.this, "Iniciando…");
                    }
                    render();
                }
            });
            row.addView(toggle, weight());
            row.addView(Ui.button(this, "Abrir", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openBot(b.id);
                }
            }), weight());
            card.addView(row);

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openBot(b.id);
                }
            });
            list.addView(card);
        }
    }

    private void openBot(String id) {
        startActivity(new Intent(this, BotActivity.class).putExtra("id", id));
    }

    private void newBot() {
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setText("Bot " + (Store.list(this).size() + 1));
        new AlertDialog.Builder(this)
                .setTitle("Nuevo bot")
                .setMessage("Nombre del bot")
                .setView(name)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String n = name.getText().toString().trim();
                        createAndOpen(n.isEmpty() ? "Bot" : n, Store.TEMPLATE);
                    }
                })
                .show();
    }

    private void createAndOpen(String name, String code) {
        Store.Bot b = Store.create(this, name, code);
        if (b == null) {
            Ui.toast(this, "Máximo " + Store.MAX_BOTS + " bots. Borra uno primero.");
            return;
        }
        openBot(b.id);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                String code = Ui.readUri(this, uri);
                createAndOpen(Ui.displayName(this, uri), code);
            } catch (Exception e) {
                Ui.toast(this, "No se pudo leer el archivo");
            }
        }
    }

    private void batterySettings() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Ui.toast(this, "Ya está sin restricciones de batería");
                return;
            }
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e2) {
                Ui.toast(this, "Abre Ajustes > Batería y quita las restricciones a Bot Host");
            }
        }
    }
}
