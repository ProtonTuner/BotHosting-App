package com.vesper.runtime

import android.app.Activity
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.StatFs
import android.app.ActivityManager
import android.graphics.Color
import android.content.pm.PackageManager
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.InputFilter
import org.json.JSONObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var console: TextView
    private lateinit var status: TextView
    private lateinit var currentFileLabel: TextView
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private lateinit var projectsDir: File
    private lateinit var botsDir: File
    private lateinit var requirementsFile: File
    private var currentFile: File? = null
    private var running = false // Accessed only on the main thread.
    private var receiverRegistered = false
    private var runtimeUiInitialized = false
    private var pendingProjectExportName: String? = null
    private var pendingProjectExportText: String? = null
    private var lastLogBytesRead = 0L
    private lateinit var screenHost: LinearLayout
    private lateinit var navBar: LinearLayout
    private var currentTab: String = "home"
    private var homeEngineStatus: TextView? = null
    private val navItems = linkedMapOf<String, LinearLayout>()
    private val exportRequirementsRequestCode = 4307
    private val importProjectRequestCode = 4308
    private val importFilesRequestCode = 4311
    private val importBotZipRequestCode = 4312
    private val exportProjectRequestCode = 4309
    private val notificationPermissionRequestCode = 4310
    private val maxImportedProjectBytes = 1_000_000
    private val maxImportedArchiveBytes = 20 * 1024 * 1024
    private val maxArchiveEntries = 500

    private val runtimeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                RuntimeService.ACTION_STATE -> {
                    val fullStatus = intent.getStringExtra(RuntimeService.EXTRA_STATUS) ?: "Status: READY"
                    running = intent.getBooleanExtra(RuntimeService.EXTRA_RUNNING, false)
                    status.text = if (running) "EN EJECUCIÓN" else if (fullStatus.contains("ERROR", true)) "ERROR" else "LISTO"
                    if (currentTab != "home" && currentTab != "projects") runButton.isEnabled = !running
                    stopButton.isEnabled = running
                    editor.isEnabled = !running
                    homeEngineStatus?.apply {
                        text = if (running) "EN EJECUCIÓN" else if (fullStatus.contains("ERROR", true)) "REQUIERE ATENCIÓN" else "LISTO PARA INICIAR"
                        setTextColor(if (running) Color.rgb(108, 240, 181) else Color.rgb(226, 232, 255))
                    }
                    // Bot cards cache their button state when rendered. Rebuild this screen
                    // on service state changes so Start/Stop cannot become stale.
                    if (currentTab == "projects") showTab("projects")
                }
                RuntimeService.ACTION_OUTPUT -> {
                    val outputText = intent.getStringExtra(RuntimeService.EXTRA_OUTPUT) ?: "(no output)"
                    val startOffset = intent.getLongExtra(RuntimeService.EXTRA_OUTPUT_START_OFFSET, -1L)
                    val endOffset = intent.getLongExtra(RuntimeService.EXTRA_OUTPUT_OFFSET, -1L)
                    if (startOffset < 0L || endOffset < 0L) {
                        appendConsoleRaw(outputText)
                        return
                    }
                    // Log catch-up and live broadcasts can race while this Activity returns
                    // to the foreground. Byte offsets prevent duplicate console chunks.
                    if (endOffset <= lastLogBytesRead) return
                    if (startOffset > lastLogBytesRead) appendMissedRunningOutput(startOffset)
                    var chunkToAppend = outputText
                    if (startOffset < lastLogBytesRead) {
                        val bytes = outputText.toByteArray(Charsets.UTF_8)
                        val skipBytes = (lastLogBytesRead - startOffset).coerceAtMost(bytes.size.toLong()).toInt()
                        if (skipBytes >= bytes.size) {
                            lastLogBytesRead = maxOf(lastLogBytesRead, endOffset)
                            return
                        }
                        chunkToAppend = String(bytes.copyOfRange(skipBytes, bytes.size), Charsets.UTF_8)
                    }
                    appendConsoleRaw(chunkToAppend)
                    lastLogBytesRead = maxOf(lastLogBytesRead, endOffset)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        } catch (e: Exception) {
            showFatalRuntimeError("Python could not start: ${e.message ?: e.javaClass.simpleName}")
            return
        }

        projectsDir = File(filesDir, "projects").apply { mkdirs() }
        botsDir = File(filesDir, "discord_bots").apply { mkdirs() }
        requirementsFile = File(filesDir, "requirements.txt")
        if (!requirementsFile.exists()) {
            try {
                assets.open("requirements.txt").use { input -> requirementsFile.writeBytes(input.readBytes()) }
            } catch (e: Exception) {
                requirementsFile.writeText("# Vesper Runtime Python dependencies\n")
            }
        }
        val starter = File(projectsDir, "main.py")
        if (!starter.exists()) {
            try {
                assets.open("main.py").use { input -> starter.writeBytes(input.readBytes()) }
            } catch (e: Exception) {
                starter.writeText("print('Vesper Runtime is ready.')\n")
            }
        }
        val hostingPrefs = getSharedPreferences("vesper_hosting", MODE_PRIVATE)
        val preferredStartupName = hostingPrefs.getString("startup_script", starter.name) ?: starter.name
        val preferredStartup = projectsDir.listFiles { file ->
            file.isFile && file.extension.equals("py", true) && file.name == preferredStartupName
        }?.firstOrNull()
        currentFile = preferredStartup ?: starter
        if (preferredStartup == null) {
            hostingPrefs.edit().putString("startup_script", starter.name).apply()
        }

        // Create the working views once so switching sections never discards unsaved text or logs.
        editor = EditText(this).apply {
            setText((currentFile ?: starter).readText())
            setTextColor(Color.rgb(224, 231, 255))
            setHintTextColor(Color.rgb(125, 136, 161))
            hint = "# Your Python script\nprint('Vesper is ready')"
            textSize = 14f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundColor(Color.rgb(8, 12, 23))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            minLines = 8
            isVerticalScrollBarEnabled = true
        }
        console = TextView(this).apply {
            text = "Vesper BotHost 10.0 listo.\nCrea un bot de Discord, configura su token y luego inícialo.\n"
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(Color.rgb(142, 239, 194))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(5, 8, 16))
            setTextIsSelectable(true)
        }
        currentFileLabel = TextView(this).apply {
            text = "Espacio de trabajo / ${currentFile?.name ?: starter.name}"
            textSize = 12f
            letterSpacing = 0.02f
            setTextColor(Color.rgb(190, 200, 229))
            setPadding(dp(2), dp(4), dp(2), dp(4))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(6))
            setBackgroundColor(Color.rgb(8, 12, 24))
        }
        ViewCompat.setOnApplyWindowInsetsListener(page) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(dp(12) + bars.left, dp(4) + bars.top, dp(12) + bars.right, dp(6) + bars.bottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(10))
        }
        val logo = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_vesper_launcher_foreground)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(Color.rgb(19, 23, 52))
                setStroke(dp(1), Color.rgb(93, 79, 180))
            }
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val brandBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        brandBlock.addView(TextView(this).apply {
            text = "VESPER"
            textSize = 19f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(242, 240, 255))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, wrapMatch())
        brandBlock.addView(TextView(this).apply {
            text = "BOTHOST 10.0  •  CONTROL DISCORD"
            textSize = 9f
            letterSpacing = 0.04f
            setTextColor(Color.rgb(137, 151, 183))
        }, wrapMatch())
        header.addView(brandBlock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        status = TextView(this).apply {
            text = "LISTO"
            textSize = 10f
            letterSpacing = 0.02f
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Color.rgb(115, 244, 187))
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.rgb(15, 54, 48))
                setStroke(dp(1), Color.rgb(37, 106, 88))
            }
        }
        header.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        page.addView(header, wrapMatch())

        screenHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(screenHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(6), dp(3), dp(2))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.rgb(16, 22, 39))
                setStroke(dp(1), Color.rgb(37, 47, 75))
            }
        }
        page.addView(navBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)).apply {
            topMargin = dp(7)
        })
        buildNavigationBar()
        showTab("home")
        setContentView(page)
        runtimeUiInitialized = true
        syncRuntimeState()
    }

    private fun buildNavigationBar() {
        navBar.removeAllViews()
        navItems.clear()
        val destinations = listOf(
            Triple("home", "⌂", "Inicio"),
            Triple("projects", "◉", "Bots"),
            Triple("editor", "</>", "Editor"),
            Triple("console", ">_", "Consola"),
            Triple("more", "•••", "Más")
        )
        destinations.forEach { (key, glyph, label) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(5), dp(2), dp(4))
                isClickable = true
                isFocusable = true
                setOnClickListener { showTab(key) }
            }
            item.addView(TextView(this).apply {
                text = glyph
                textSize = if (glyph == "</>") 13f else 19f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(182, 192, 224))
                setTypeface(null, android.graphics.Typeface.BOLD)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(25)))
            item.addView(TextView(this).apply {
                text = label
                textSize = 9f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(158, 170, 200))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)))
            navItems[key] = item
            navBar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        updateNavigationSelection()
    }

    private fun updateNavigationSelection() {
        val selected = if (currentTab == "files") "projects" else currentTab
        navItems.forEach { (key, view) ->
            val active = key == selected
            view.background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (active) Color.rgb(41, 43, 91) else Color.TRANSPARENT)
                if (active) setStroke(dp(1), Color.rgb(94, 82, 183))
            }
            for (index in 0 until view.childCount) {
                (view.getChildAt(index) as? TextView)?.setTextColor(
                    if (active) Color.rgb(190, 173, 255) else Color.rgb(158, 170, 200)
                )
            }
        }
    }

    private fun showTab(tab: String) {
        currentTab = tab
        homeEngineStatus = null
        screenHost.removeAllViews()
        val screen = when (tab) {
            "projects" -> buildProjectsScreen()
            "editor" -> buildEditorScreen()
            "console" -> buildConsoleScreen()
            "files" -> buildFilesScreen()
            "more" -> buildMoreScreen()
            else -> buildHomeScreen()
        }
        screenHost.addView(screen, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        updateNavigationSelection()
        if (runtimeUiInitialized) syncRuntimeState()
    }

    private fun makeScrollScreen(builder: LinearLayout.() -> Unit): ScrollView {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(14))
            builder()
        }
        return ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            addView(body, ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun addQuickTile(parent: LinearLayout, glyph: String, title: String, subtitle: String, action: () -> Unit) {
        val tile = dashboardCard().apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        tile.addView(TextView(this).apply {
            text = glyph
            textSize = 22f
            setTextColor(Color.rgb(163, 131, 255))
        }, wrapMatch())
        tile.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(237, 240, 255))
            setPadding(0, dp(6), 0, 0)
        }, wrapMatch())
        tile.addView(TextView(this).apply {
            text = subtitle
            textSize = 10f
            setTextColor(Color.rgb(139, 153, 184))
            setPadding(0, dp(3), 0, 0)
        }, wrapMatch())
        parent.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dp(4); rightMargin = dp(4); bottomMargin = dp(7)
        })
    }

    private fun quickTileRow(parent: LinearLayout, first: Triple<String, String, () -> Unit>, second: Triple<String, String, () -> Unit>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addQuickTile(row, first.first, first.second, "Abrir espacio de trabajo", first.third)
        addQuickTile(row, second.first, second.second, "Administrar y configurar", second.third)
        parent.addView(row, wrapMatch())
    }

    private fun buildHomeScreen(): android.view.View = makeScrollScreen {
        addView(TextView(this@MainActivity).apply {
            text = "CENTRO DE CONTROL DISCORD"
            textSize = 10f
            letterSpacing = 0.13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(151, 163, 196))
            setPadding(dp(2), dp(7), 0, dp(7))
        }, wrapMatch())
        val welcome = dashboardCard().apply {
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(39, 34, 86), Color.rgb(20, 35, 64))
            ).apply { cornerRadius = dp(19).toFloat(); setStroke(dp(1), Color.rgb(75, 78, 142)) }
        }
        welcome.addView(TextView(this@MainActivity).apply {
            text = "Tus bots. Bajo tu control."
            textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(246, 244, 255))
        }, wrapMatch())
        welcome.addView(TextView(this@MainActivity).apply {
            text = "Crea, configura, ejecuta y supervisa tus bots desde Android."
            textSize = 12f
            setTextColor(Color.rgb(187, 194, 229))
            setPadding(0, dp(5), 0, dp(12))
        }, wrapMatch())
        welcome.addView(makeButton("＋  NUEVO BOT DE DISCORD") { createBotProjectDialog() }.apply { styleButton(this, accent = true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        addView(welcome, sectionParams())

        val statusCard = dashboardCard()
        val statusRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusRow.addView(TextView(this@MainActivity).apply {
            text = "◉"
            textSize = 25f
            setTextColor(Color.rgb(113, 241, 186))
            setPadding(0, 0, dp(10), 0)
        }, wrapMatch())
        val statusText = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        statusText.addView(TextView(this@MainActivity).apply {
            text = "MOTOR DE BOTS DISCORD"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(145, 159, 191))
        }, wrapMatch())
        homeEngineStatus = TextView(this@MainActivity).apply {
            text = if (running) "EN EJECUCIÓN" else "LISTO PARA INICIAR"
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(if (running) Color.rgb(108, 240, 181) else Color.rgb(226, 232, 255))
            setPadding(0, dp(3), 0, 0)
        }
        statusText.addView(homeEngineStatus, wrapMatch())
        statusRow.addView(statusText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        statusRow.addView(TextView(this@MainActivity).apply {
            val bots = listBotProjects().size
            text = "$bots bots"
            textSize = 10f
            setTextColor(Color.rgb(170, 184, 215))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.rgb(30, 38, 60)) }
            setPadding(dp(9), dp(7), dp(9), dp(7))
        }, wrapMatch())
        statusCard.addView(statusRow, wrapMatch())
        val controls = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        runButton = makeButton("◉  GESTIONAR BOTS") { showTab("projects") }.apply { styleButton(this, accent = true) }
        stopButton = makeButton("■  DETENER") { stopScript() }.apply { styleButton(this); isEnabled = running }
        controls.addView(runButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(5) })
        controls.addView(stopButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(5) })
        statusCard.addView(controls, wrapMatch())
        addView(statusCard, sectionParams())

        addView(sectionHeading("ACCESO RÁPIDO", "Controla tus bots y herramientas desde aquí"), wrapMatch())
        quickTileRow(this,
            Triple("◉", "Bots Discord", { showTab("projects") }),
            Triple("</>", "Editor de código", { showTab("editor") }))
        quickTileRow(this,
            Triple("▤", "Archivos", { showTab("files") }),
            Triple(">_", "Consola", { showTab("console") }))
        quickTileRow(this,
            Triple("◇", "Dependencias", { showDependencyManager() }),
            Triple("☁", "Panel de hosting", { showHostingPanel() }))

        val selectedName = currentFile?.name ?: "No script selected"
        val projectCard = dashboardCard()
        projectCard.addView(TextView(this@MainActivity).apply {
            text = "ARCHIVO ACTIVO"
            textSize = 10f
            letterSpacing = 0.1f
            setTextColor(Color.rgb(145, 159, 191))
        }, wrapMatch())
        projectCard.addView(TextView(this@MainActivity).apply {
            text = selectedName
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(236, 240, 255))
            setPadding(0, dp(5), 0, dp(8))
        }, wrapMatch())
        projectCard.addView(makeButton("ABRIR EN EL EDITOR") { showTab("editor") }.apply { styleButton(this) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        addView(projectCard, sectionParams())
    }

    private fun buildProjectsScreen(): android.view.View = makeScrollScreen {
        addView(sectionHeading("GESTOR DE BOTS DISCORD", "Cada bot tiene su carpeta, configuración y token privado."), wrapMatch())
        val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(makeButton("＋ Nuevo bot") { createBotProjectDialog() }.apply { styleButton(this, accent = true) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(5) })
        actions.addView(makeButton("Importar ZIP") { chooseBotZipImport() }.apply { styleButton(this) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(5) })
        addView(actions, sectionParams())
        val hostInfo = dashboardCard()
        hostInfo.addView(TextView(this@MainActivity).apply {
            text = "HOST LOCAL DE BOTS"
            textSize = 10f
            letterSpacing = 0.1f
            setTextColor(Color.rgb(151, 163, 196))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, wrapMatch())
        hostInfo.addView(TextView(this@MainActivity).apply {
            text = "Bots activos: ${if (running) 1 else 0}  •  Ranuras de ejecución: 1  •  Python 3.11 / discord.py 2.7.1\n\nEl proceso se ejecuta en este teléfono. Mantén Vesper en aplicaciones recientes y revisa las restricciones de batería para sesiones largas. No es un hosting cloud ni garantiza disponibilidad 24/7."
            textSize = 12f
            setTextColor(Color.rgb(189, 199, 224))
            setPadding(0, dp(7), 0, 0)
        }, wrapMatch())
        hostInfo.addView(makeButton("ABRIR PANEL DE HOSTING") { showHostingPanel() }.apply { styleButton(this) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)).apply { topMargin = dp(8) })
        addView(hostInfo, sectionParams())

        val botProjects = dashboardCard()
        val bots = listBotProjects()
        if (bots.isEmpty()) {
            botProjects.addView(TextView(this@MainActivity).apply {
                text = "Todavía no hay bots de Discord\nCrea un proyecto inicial o importa un ZIP. La plantilla incluye el comando slash /ping y configuración privada del token."
                textSize = 13f
                setTextColor(Color.rgb(185, 197, 222))
                setPadding(0, dp(8), 0, dp(8))
            }, wrapMatch())
        } else {
            bots.forEach { bot -> renderBotProjectCard(botProjects, bot) }
        }
        addView(botProjects, sectionParams())

        val scripts = dashboardCard()
        addView(sectionHeading("SCRIPTS PYTHON", "Las utilidades independientes se mantienen separadas de los bots Discord."), wrapMatch())
        val plainScripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        if (plainScripts.isEmpty()) {
            scripts.addView(TextView(this@MainActivity).apply {
                text = "No hay scripts independientes."
                textSize = 12f
                setTextColor(Color.rgb(152, 166, 194))
            }, wrapMatch())
        } else {
            plainScripts.forEach { file ->
                addActionRow(scripts, file.name, "Script Python independiente · ${file.length() / 1024} KB", "EDIT") {
                    openProject(file)
                    showTab("editor")
                }
            }
        }
        addView(scripts, sectionParams())
        val tools = dashboardCard()
        addActionRow(tools, "Dependencias de Python", "Consulta los paquetes integrados en la APK; no instala paquetes en tiempo real", "GESTIONAR") { showDependencyManager() }
        addActionRow(tools, "Archivos importados", "Explora archivos importados desde el selector o archivos ZIP", "ARCHIVOS") { showImportedFiles() }
        addView(tools, sectionParams())
    }


    private fun botHostApi() = Python.getInstance().getModule("vesper_bot_host")

    private fun listBotProjects(): List<JSONObject> {
        return try {
            val raw = botHostApi().callAttr("list_projects_json", botsDir.absolutePath)?.toString()
                ?: return emptyList()
            val array = JSONObject(raw).optJSONArray("projects") ?: return emptyList()
            (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
        } catch (e: Exception) {
            appendConsole("Bot registry read failed: ${e.message ?: e.javaClass.simpleName}")
            emptyList()
        }
    }

    private fun createBotProjectDialog() {
        if (running) {
            Toast.makeText(this, "Detén el proceso activo antes de crear un bot", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            hint = "my_discord_bot"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
            filters = arrayOf(InputFilter.LengthFilter(40))
        }
        AlertDialog.Builder(this)
            .setTitle("Crear bot de Discord")
            .setMessage("Crea una carpeta independiente con bot.py, el comando slash /ping, requirements.txt y configuración privada del token.")
            .setView(input)
             .setPositiveButton("Crear", null)
             .setNegativeButton("Cancelar", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val projectId = input.text.toString().trim()
                            .replace(Regex("\\s+"), "_")
                        if (!projectId.matches(Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,39}"))) {
                            input.error = "Use 1–40 letters, digits, underscores or hyphens"
                            return@setOnClickListener
                        }
                        try {
                            val raw = botHostApi().callAttr("create_project_json", botsDir.absolutePath, projectId)?.toString()
                                ?: throw IllegalStateException("Bot project manager returned no result")
                            val result = JSONObject(raw)
                            if (!result.optBoolean("ok", false)) {
                                input.error = result.optString("error", "Could not create the bot")
                                return@setOnClickListener
                            }
                            dialog.dismiss()
                            appendConsole("Created Discord bot project: $projectId")
                            showTab("projects")
                            configureBotToken(projectId)
                        } catch (e: Exception) {
                            input.error = e.message ?: "Could not create bot project"
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun renderBotProjectCard(parent: LinearLayout, bot: JSONObject) {
        val projectId = bot.optString("id", "")
        if (!projectId.matches(Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,39}"))) return
        val projectDir = File(botsDir, projectId).canonicalFile
        val entrypoint = bot.optString("entrypoint", "bot.py")
        val tokenConfigured = bot.optBoolean("token_configured", false)
        val entrypointExists = bot.optBoolean("entrypoint_exists", false)
        val statePrefs = getSharedPreferences(RuntimeService.PREFS_NAME, MODE_PRIVATE)
        val activePath = statePrefs.getString(RuntimeService.KEY_ACTIVE_PROJECT_DIR, null)
        val isActive = running && try { File(activePath ?: "").canonicalFile == projectDir } catch (_: Exception) { false }
        val displayName = bot.optString("display_name", projectId).take(80)
        val card = dashboardCard().apply { setPadding(dp(13), dp(12), dp(13), dp(12)) }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = displayName
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(242, 244, 255))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        titleRow.addView(TextView(this).apply {
            text = when { isActive -> "EN EJECUCIÓN"; !entrypointExists -> "FALTA SCRIPT"; !tokenConfigured -> "CONFIGURAR"; else -> "DETENIDO" }
            textSize = 9f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(when { isActive -> Color.rgb(109, 242, 185); !entrypointExists -> Color.rgb(255, 145, 145); !tokenConfigured -> Color.rgb(255, 205, 113); else -> Color.rgb(166, 177, 207) })
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(when { isActive -> Color.rgb(16, 58, 48); !entrypointExists -> Color.rgb(64, 30, 43); !tokenConfigured -> Color.rgb(62, 48, 26); else -> Color.rgb(32, 39, 59) })
            }
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }, wrapMatch())
        card.addView(titleRow, wrapMatch())
        card.addView(TextView(this).apply {
            text = "$entrypoint  •  ${if (tokenConfigured) "token configurado" else "token sin configurar"}  •  ${bot.optLong("size_bytes", 0L) / 1024} KB"
            textSize = 11f
            setTextColor(Color.rgb(148, 163, 194))
            setPadding(0, dp(5), 0, dp(10))
        }, wrapMatch())
        val primary = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val actionLabel = if (isActive) "■ Detener" else "▶ Iniciar"
        val startButton = makeButton(actionLabel) {
            if (isActive) stopScript() else startBotProject(projectId, entrypoint, tokenConfigured, entrypointExists)
        }.apply { styleButton(this, accent = !isActive); isEnabled = isActive || !running }
        primary.addView(startButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(4) })
        primary.addView(makeButton("Token") { configureBotToken(projectId) }.apply { styleButton(this) },
            LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        primary.addView(makeButton("Código") {
            val script = File(projectDir, entrypoint)
            if (script.isFile) {
                openProject(script)
                showTab("editor")
            } else Toast.makeText(this, "Falta el script de inicio", Toast.LENGTH_LONG).show()
        }.apply { styleButton(this); isEnabled = entrypointExists && !running },
            LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(4) })
        card.addView(primary, wrapMatch())

        val secondary = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(5), 0, 0) }
        secondary.addView(makeButton("Archivos") { showFileBrowser(projectDir) }.apply { styleButton(this) },
            LinearLayout.LayoutParams(0, dp(38), 1f).apply { rightMargin = dp(4) })
        secondary.addView(makeButton("Script inicial") { chooseBotEntrypoint(projectId) }.apply { styleButton(this); isEnabled = !running },
            LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        secondary.addView(makeButton("Eliminar") { confirmDeleteBot(projectId, isActive) }.apply { styleButton(this) },
            LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(4) })
        card.addView(secondary, wrapMatch())
        parent.addView(card, sectionParams())
    }

    private fun startBotProject(projectId: String, entrypoint: String, tokenConfigured: Boolean, entrypointExists: Boolean) {
        if (!tokenConfigured) {
            Toast.makeText(this, "Configura DISCORD_TOKEN antes de iniciar este bot", Toast.LENGTH_LONG).show()
            configureBotToken(projectId)
            return
        }
        if (!entrypointExists) {
            Toast.makeText(this, "No se encuentra el script de inicio configurado", Toast.LENGTH_LONG).show()
            return
        }
        val directory = File(botsDir, projectId).canonicalFile
        val script = File(directory, entrypoint).canonicalFile
        if (script.parentFile != directory || !script.isFile) {
            Toast.makeText(this, "El script de inicio del bot no es válido", Toast.LENGTH_LONG).show()
            return
        }
        startManagedScript(script)
    }

    private fun configureBotToken(projectId: String) {
        val input = EditText(this).apply {
            hint = "Pega el token del bot de Discord"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
            filters = arrayOf(InputFilter.LengthFilter(512))
        }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(5), dp(20), dp(5))
            addView(TextView(this@MainActivity).apply {
                text = "Se guarda en el archivo .env privado de Vesper. Esta pantalla no vuelve a mostrar el token. No lo pegues en chats, registros ni archivos que vayas a compartir."
                textSize = 12f
                setTextColor(Color.rgb(181, 194, 221))
                setPadding(0, 0, 0, dp(10))
            }, wrapMatch())
            addView(input, wrapMatch())
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Token del bot · $projectId")
            .setView(holder)
            .setPositiveButton("Guardar token", null)
            .setNeutralButton("Quitar token", null)
             .setNegativeButton("Cancelar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val token = input.text.toString().trim()
                if (token.isBlank() || token.length > 512 || token.any { it == '\n' || it == '\r' || it == '\u0000' }) {
                    input.error = "Enter a token on one line (1–512 characters)"
                    return@setOnClickListener
                }
                try {
                    val response = botHostApi().callAttr("set_discord_token_json", botsDir.absolutePath, projectId, token)?.toString()
                        ?: throw IllegalStateException("Token manager returned no result")
                    if (!JSONObject(response).optBoolean("ok", false)) throw IllegalStateException("Could not store token")
                    input.setText("")
                    dialog.dismiss()
                    Toast.makeText(this, "Token guardado en privado para $projectId", Toast.LENGTH_SHORT).show()
                    showTab("projects")
                } catch (e: Exception) {
                    input.error = e.message ?: "Could not store token"
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("¿Quitar el token del bot?")
                    .setMessage("El bot no podrá iniciarse hasta que configures otro token.")
                     .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Remove") { _, _ ->
                        try {
                            botHostApi().callAttr("clear_discord_token_json", botsDir.absolutePath, projectId)
                            input.setText("")
                            dialog.dismiss()
                            Toast.makeText(this, "Token eliminado", Toast.LENGTH_SHORT).show()
                            showTab("projects")
                        } catch (e: Exception) {
                            Toast.makeText(this, "Could not remove token: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                        }
                    }.show()
            }
        }
        dialog.show()
    }

    private fun chooseBotEntrypoint(projectId: String) {
        val directory = File(botsDir, projectId).canonicalFile
        if (!directory.isDirectory || directory.parentFile != botsDir.canonicalFile) {
            Toast.makeText(this, "Invalid bot directory", Toast.LENGTH_LONG).show()
            return
        }
        val scripts = directory.listFiles { file -> file.isFile && file.extension.equals("py", true) && file.name.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}\\.py", RegexOption.IGNORE_CASE)) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        if (scripts.isEmpty()) {
            Toast.makeText(this, "No root-level Python entrypoint found", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Script inicial · $projectId")
            .setItems(scripts.map { it.name }.toTypedArray()) { _, index ->
                try {
                    val response = botHostApi().callAttr("set_project_metadata_json", botsDir.absolutePath, projectId,
                        listBotProjects().firstOrNull { it.optString("id") == projectId }?.optString("display_name") ?: projectId,
                        scripts[index].name)?.toString() ?: "{}"
                    if (!JSONObject(response).optBoolean("ok", false)) throw IllegalStateException("Could not update entrypoint")
                    showTab("projects")
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not update startup file: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
             .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteBot(projectId: String, isActive: Boolean) {
        if (isActive) {
            Toast.makeText(this, "Detén este bot antes de eliminar su proyecto", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("¿Eliminar $projectId?")
            .setMessage("Esto elimina el código, la configuración, los registros y el token privado de este bot. Exporta primero los archivos que quieras conservar.")
             .setNegativeButton("Cancelar", null)
            .setPositiveButton("Delete") { _, _ ->
                try {
                    botHostApi().callAttr("delete_project_json", botsDir.absolutePath, projectId)
                    if (currentFile?.canonicalPath?.startsWith(File(botsDir, projectId).canonicalPath + File.separator) == true) {
                        currentFile = File(projectsDir, "main.py")
                        editor.setText(currentFile?.readText() ?: "")
                        currentFileLabel.text = "Espacio de trabajo / main.py"
                    }
                    Toast.makeText(this, "Deleted $projectId", Toast.LENGTH_SHORT).show()
                    showTab("projects")
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun chooseBotZipImport() {
        if (running) {
            Toast.makeText(this, "Detén el proceso activo antes de importar un bot", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importBotZipRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open ZIP picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importBotZip(uri: Uri, archiveName: String) {
        var staging: File? = null
        var target: File? = null
        try {
            val base = archiveName.substringBeforeLast('.', archiveName)
                .replace(Regex("[^A-Za-z0-9_-]"), "_").trim('_').take(40).ifBlank { "discord_bot" }
            val projectId = uniqueBotProjectId(base)
            staging = uniqueImportedFile(importedFilesDir(), "bot_staging_${System.currentTimeMillis()}").apply { mkdirs() }.canonicalFile
            var entryCount = 0
            var totalBytes = 0L
            val stream = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open ZIP")
            ZipInputStream(stream.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entryCount++
                    if (entryCount > maxArchiveEntries) throw IllegalArgumentException("ZIP has too many entries (limit $maxArchiveEntries)")
                    val normalizedName = entry.name.replace('\\', '/')
                    val parts = normalizedName.split('/')
                    if (parts.any { it.lowercase() in setOf(".env", ".git", ".venv", "venv", "__pycache__", "node_modules", ".vesper-logs", "vesper-bot.json") }) {
                        zip.closeEntry()
                        continue
                    }
                    val relative = cleanImportedPath(entry.name)
                    val output = File(staging, relative).canonicalFile
                    if (output != staging && !output.path.startsWith(staging.path + File.separator)) throw SecurityException("ZIP entry escapes destination")
                    if (entry.isDirectory) {
                        output.mkdirs()
                    } else {
                        if (output.exists()) throw IllegalArgumentException("ZIP contains duplicate file paths")
                        output.parentFile?.mkdirs()
                        output.outputStream().buffered().use { destination ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                totalBytes += count
                                if (totalBytes > maxImportedArchiveBytes) throw IllegalArgumentException("Expanded ZIP exceeds 20 MB")
                                destination.write(buffer, 0, count)
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
            if (entryCount == 0) throw IllegalArgumentException("ZIP is empty or invalid")
            val archiveEntries = staging.listFiles()?.filterNot { it.name == "__MACOSX" || it.name == ".DS_Store" || it.name == ".env.example" || it.name.startsWith(".") }.orEmpty()
            var sourceRoot = staging
            val rootScripts = archiveEntries.filter { it.isFile && isRunnablePythonFile(it) }
            if (rootScripts.isEmpty()) {
                val wrapperDirs = archiveEntries.filter { it.isDirectory }
                val rootFiles = archiveEntries.filter { it.isFile }
                if (wrapperDirs.size == 1 && rootFiles.isEmpty() && listProjectPythonFiles(wrapperDirs.single()).isNotEmpty()) sourceRoot = wrapperDirs.single().canonicalFile
            }
            val pythonFiles = listProjectPythonFiles(sourceRoot)
            val selected = chooseStartupPythonFile(pythonFiles, sourceRoot)
                ?: throw IllegalArgumentException("ZIP contains no runnable Python source")
            target = File(botsDir, projectId).canonicalFile
            if (target.parentFile != botsDir.canonicalFile || target.exists()) throw IllegalStateException("Bot destination already exists")
            target.mkdirs()
            copyBotProjectTree(sourceRoot, target, selected.canonicalFile)
            val entrypoint = if (selected.parentFile?.canonicalFile == sourceRoot.canonicalFile) selected.name else "bot.py"
            if (entrypoint == "bot.py" && selected.parentFile?.canonicalFile != sourceRoot.canonicalFile) {
                selected.copyTo(File(target, "bot.py"), overwrite = false)
            }
            val response = botHostApi().callAttr("register_imported_project_json", botsDir.absolutePath, projectId, base.replace('_', ' ').replace('-', ' '), entrypoint)?.toString()
                ?: throw IllegalStateException("Could not register imported bot")
            if (!JSONObject(response).optBoolean("ok", false)) throw IllegalStateException("Could not register imported bot")
            Toast.makeText(this, "$projectId importado. Configura DISCORD_TOKEN y revisa las dependencias antes de iniciarlo.", Toast.LENGTH_LONG).show()
            showTab("projects")
        } catch (e: Exception) {
            target?.deleteRecursively()
            Toast.makeText(this, "Falló la importación del ZIP: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        } finally {
            staging?.deleteRecursively()
        }
    }

    private fun uniqueBotProjectId(base: String): String {
        val normalized = base.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifBlank { "discord_bot" }
        var candidate = normalized
        var suffix = 2
        while (File(botsDir, candidate).exists()) {
            val tail = "_$suffix"
            candidate = normalized.take(40 - tail.length) + tail
            suffix++
            if (suffix > 10_000) throw IllegalStateException("Could not create a unique bot project ID")
        }
        return candidate
    }

    private fun copyBotProjectTree(source: File, target: File, selectedEntrypoint: File) {
        val targetRoot = target.canonicalFile
        val ignored = setOf(".env", ".git", ".venv", "venv", "__pycache__", "node_modules", ".vesper-logs", "vesper-bot.json")
        fun copyNode(node: File) {
            if (node.name.lowercase() in ignored) return
            val canonicalNode = node.canonicalFile
            val destination = File(targetRoot, node.relativeTo(source).path).canonicalFile
            if (destination != targetRoot && !destination.path.startsWith(targetRoot.path + File.separator)) throw SecurityException("Imported bot file escapes destination")
            if (node.isDirectory) {
                destination.mkdirs()
                node.listFiles()?.forEach { copyNode(it) }
            } else if (node.isFile && canonicalNode != selectedEntrypoint) {
                destination.parentFile?.mkdirs()
                if (!destination.exists()) node.copyTo(destination, overwrite = false)
            }
        }
        source.listFiles()?.forEach { copyNode(it) }
        if (selectedEntrypoint.parentFile?.canonicalFile == source.canonicalFile) {
            val destination = File(targetRoot, selectedEntrypoint.name)
            selectedEntrypoint.copyTo(destination, overwrite = false)
        }
    }


    private fun buildEditorScreen(): android.view.View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(2))
        }
        root.addView(sectionHeading("EDITOR DE CÓDIGO", "Edita el script y guarda los cambios antes de ejecutarlo"), wrapMatch())
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        detachView(currentFileLabel)
        toolbar.addView(currentFileLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toolbar.addView(makeButton("GUARDAR") { saveCurrentProject(showToast = true) }.apply { styleButton(this, accent = true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(5) })
        runButton = makeButton("▶ EJECUTAR") { runScript() }.apply { styleButton(this); isEnabled = !running }
        toolbar.addView(runButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(5) })
        root.addView(toolbar, wrapMatch())
        val info = TextView(this).apply {
            text = "UTF-8  •  Python 3.11  •  ${currentFile?.name ?: "main.py"}"
            textSize = 10f
            setTextColor(Color.rgb(133, 151, 188))
            setPadding(dp(2), dp(5), 0, dp(6))
        }
        root.addView(info, wrapMatch())
        detachView(editor)
        editor.isEnabled = !running
        root.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildConsoleScreen(): android.view.View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(4), dp(2), dp(2)) }
        root.addView(sectionHeading("CONSOLA", "Salida en directo y diagnóstico del runtime"), wrapMatch())
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        runButton = makeButton("▶ EJECUTAR") { runScript() }.apply { styleButton(this, accent = true); isEnabled = !running }
        stopButton = makeButton("■ DETENER") { stopScript() }.apply { styleButton(this); isEnabled = running }
        toolbar.addView(runButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(5) })
        toolbar.addView(stopButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(5); rightMargin = dp(5) })
        toolbar.addView(makeButton("LIMPIAR") { console.text = "Consola limpia.\n" }.apply { styleButton(this) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)).apply { leftMargin = dp(5) })
        root.addView(toolbar, wrapMatch())
        detachView(console)
        val consoleScroll = ScrollView(this).apply {
            isFillViewport = true
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.rgb(5, 8, 16)); setStroke(dp(1), Color.rgb(41, 51, 77)) }
            addView(console, ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(consoleScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })
        val hint = TextView(this).apply {
            text = "Solo se ejecuta un script Python a la vez. La salida se conserva al cambiar de pestaña."
            textSize = 10f
            setTextColor(Color.rgb(131, 147, 180))
            setPadding(dp(2), dp(7), dp(2), 0)
        }
        root.addView(hint, wrapMatch())
        return root
    }

    private fun buildFilesScreen(): android.view.View = makeScrollScreen {
        addView(sectionHeading("GESTOR DE ARCHIVOS", "Explora proyectos, archivos comprimidos e importaciones"), wrapMatch())
        val actions = dashboardCard()
        addActionRow(actions, "Importar proyecto ZIP", "Extrae un proyecto completo, con carpetas y módulos", "IMPORTAR ZIP") { importAnyFile() }
        addActionRow(actions, "Importar archivo individual", "Añade un script Python u otro archivo compatible", "IMPORTAR") { importAnyFile() }
        addActionRow(actions, "Proyectos locales", "Explora los archivos de proyecto de la aplicación", "EXPLORAR") { showFileBrowser(projectsDir) }
        addActionRow(actions, "Archivos importados", "Archivos extraídos de archivos comprimidos", "ABRIR") { showImportedFiles() }
        addActionRow(actions, "Dependencias Python", "Valida requirements.txt antes de compilar la APK", "GESTIONAR") { showDependencyManager() }
        addActionRow(actions, "Exportar dependencias", "Guarda el manifiesto de dependencias fuera de Vesper", "EXPORTAR") { exportRequirements() }
        addView(actions, sectionParams())
        val security = dashboardCard()
        security.addView(TextView(this@MainActivity).apply {
            text = "OPERACIONES DE ARCHIVOS SEGURAS"
            textSize = 10f
            letterSpacing = 0.09f
            setTextColor(Color.rgb(148, 162, 195))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, wrapMatch())
        security.addView(TextView(this@MainActivity).apply {
            text = "Las rutas del archivo comprimido se validan antes de extraerlo. El código importado puede realizar acciones al ejecutarse: revisa los proyectos desconocidos."
            textSize = 12f
            setTextColor(Color.rgb(188, 198, 223))
            setPadding(0, dp(7), 0, 0)
        }, wrapMatch())
        addView(security, sectionParams())
    }

    private fun buildMoreScreen(): android.view.View = makeScrollScreen {
        addView(sectionHeading("MÁS HERRAMIENTAS", "Hosting, dependencias, exportación y ajustes del dispositivo"), wrapMatch())
        val hosting = dashboardCard()
        addActionRow(hosting, "Panel de hosting", "Estado, almacenamiento, memoria y recuperación", "ABRIR") { showHostingPanel() }
        addActionRow(hosting, "Script de inicio", "Selecciona el punto de entrada Python por defecto", "ELEGIR") { chooseStartupScript() }
        addActionRow(hosting, "Ejecución en segundo plano", "Revisa las restricciones de batería de Android", "ANDROID") { openBackgroundSettings() }
        addView(hosting, sectionParams())

        val dev = dashboardCard()
        addActionRow(dev, "Dependencias", "Edita y valida requirements.txt", "GESTIONAR") { showDependencyManager() }
        addActionRow(dev, "Exportar script actual", "Guarda el archivo .py seleccionado", "EXPORTAR") { exportCurrentProject() }
        addActionRow(dev, "Exportar dependencias", "Guarda el manifiesto de paquetes Python", "EXPORTAR") { exportRequirements() }
        addActionRow(dev, "Explorar archivos", "Renombra, mueve, duplica y administra archivos", "ARCHIVOS") { showTab("files") }
        addView(dev, sectionParams())

        val about = dashboardCard()
        about.addView(TextView(this@MainActivity).apply {
            text = "VESPER BOTHOST 10.0.0"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(239, 238, 255))
        }, wrapMatch())
        about.addView(TextView(this@MainActivity).apply {
            text = "Entorno para bots Discord con Python 3.11 y Chaquopy. Los bots se ejecutan en este teléfono Android, no en un servidor remoto.\n\nEl paquete discord.py se integra al compilar la APK. Las dependencias adicionales necesitan una rueda compatible con Android y una nueva compilación. Esta edición ejecuta un solo proceso Python a la vez; Android puede interrumpir bots de larga duración."
            textSize = 12f
            setTextColor(Color.rgb(164, 179, 207))
            setPadding(0, dp(6), 0, 0)
        }, wrapMatch())
        addView(about, sectionParams())
    }

    private fun detachView(view: android.view.View) {
        (view.parent as? ViewGroup)?.removeView(view)
    }

    override fun onStart() {
        super.onStart()
        // Python initialization can fail before the UI is constructed. The fatal-error
        // dialog is still shown, but lifecycle callbacks must not touch lateinit views.
        if (!runtimeUiInitialized) return
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(RuntimeService.ACTION_STATE)
                addAction(RuntimeService.ACTION_OUTPUT)
            }
            ContextCompat.registerReceiver(this, runtimeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        syncRuntimeState()
        if (running) appendMissedRunningOutput()
        // Ask the service to confirm state so a stale persisted RUNNING flag cannot
        // leave the controls disabled if Android killed the process.
        try {
            startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_QUERY))
        } catch (_: Exception) {
            // The UI still reflects the most recent persisted state if querying fails.
        }
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(runtimeReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun syncRuntimeState() {
        val prefs = getSharedPreferences(RuntimeService.PREFS_NAME, MODE_PRIVATE)
        val fullStatus = prefs.getString(RuntimeService.KEY_STATUS, "Status: READY") ?: "Status: READY"
        status.text = if (prefs.getBoolean(RuntimeService.KEY_RUNNING, false)) "EN EJECUCIÓN" else if (fullStatus.contains("ERROR", true)) "ERROR" else "LISTO"
        running = prefs.getBoolean(RuntimeService.KEY_RUNNING, false)
        if (currentTab != "home" && currentTab != "projects") runButton.isEnabled = !running
        stopButton.isEnabled = running
        editor.isEnabled = !running
        homeEngineStatus?.apply {
            text = if (running) "EN EJECUCIÓN" else if (fullStatus.contains("ERROR", true)) "REQUIERE ATENCIÓN" else "LISTO PARA INICIAR"
            setTextColor(if (running) Color.rgb(108, 240, 181) else Color.rgb(226, 232, 255))
        }
        val lastOutput = prefs.getString(RuntimeService.KEY_LAST_OUTPUT, "").orEmpty()
        if (lastOutput.isNotBlank() && console.text.toString().trim() == "Vesper BotHost 10.0 listo.\nCrea un bot de Discord, configura su token y luego inícialo.") {
            appendConsole(lastOutput)
        }
    }

    private fun appendMissedRunningOutput(untilOffset: Long? = null) {
        val prefs = getSharedPreferences(RuntimeService.PREFS_NAME, MODE_PRIVATE)
        val logPath = prefs.getString(RuntimeService.KEY_OUTPUT_LOG_PATH, null)
        val logFile = if (logPath.isNullOrBlank()) File(filesDir, "runtime-output.log") else File(logPath)
        if (!logFile.isFile) return
        try {
            RandomAccessFile(logFile, "r").use { stream ->
                val targetOffset = minOf(untilOffset ?: stream.length(), stream.length())
                while (lastLogBytesRead < targetOffset) {
                    stream.seek(lastLogBytesRead)
                    val remaining = (targetOffset - lastLogBytesRead).coerceAtMost(256_000L).toInt()
                    val bytes = ByteArray(remaining)
                    val count = stream.read(bytes)
                    if (count <= 0) break
                    appendConsoleRaw(String(bytes, 0, count, Charsets.UTF_8))
                    lastLogBytesRead += count
                }
            }
        } catch (e: Exception) {
            appendConsole("Could not restore recent output: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun sectionHeading(title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(2), dp(7), dp(2), dp(10))
        addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 11f
            letterSpacing = 0.12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(144, 157, 185))
        }, wrapMatch())
        addView(TextView(this@MainActivity).apply {
            text = subtitle
            textSize = 12f
            setTextColor(Color.rgb(103, 117, 145))
            setPadding(0, dp(3), 0, 0)
        }, wrapMatch())
    }

    private fun dashboardCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(22, 28, 43))
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.rgb(42, 52, 75))
        }
    }

    private fun sectionParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(14) }

    private fun styleButton(button: Button, accent: Boolean = false) {
        button.textSize = 10f
        button.isAllCaps = false
        button.setTextColor(if (accent) Color.WHITE else Color.rgb(218, 226, 246))
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (accent) Color.rgb(100, 78, 255) else Color.rgb(39, 49, 71)
        )
        button.setPadding(dp(8), dp(3), dp(8), dp(3))
        button.minHeight = dp(38)
        button.minimumHeight = dp(38)
    }

    private fun addActionRow(parent: LinearLayout, title: String, subtitle: String, actionLabel: String, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.rgb(230, 235, 249))
        }, wrapMatch())
        labels.addView(TextView(this).apply {
            text = subtitle
            textSize = 10f
            setTextColor(Color.rgb(132, 146, 174))
            setPadding(0, dp(2), 0, 0)
        }, wrapMatch())
        row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(makeButton(actionLabel, action).apply { styleButton(this) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        parent.addView(row, wrapMatch())
        val divider = android.view.View(this).apply { setBackgroundColor(Color.rgb(39, 48, 68)) }
        parent.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setOnClickListener { action() }
    }

    private fun weightedButton() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    /** Wispbyte-inspired local hosting dashboard. Python jobs still run on this phone. */
    private fun showHostingPanel() {
        val scripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        val prefs = getSharedPreferences("vesper_hosting", MODE_PRIVATE)
        val startup = prefs.getString("startup_script", "main.py") ?: "main.py"
        val stat = StatFs(filesDir.absolutePath)
        val freeMb = stat.availableBytes / (1024 * 1024)
        val totalMb = stat.totalBytes / (1024 * 1024)
        val memory = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        memory.getMemoryInfo(memInfo)
        val botProjects = listBotProjects()
        val activeProjectPath = getSharedPreferences(RuntimeService.PREFS_NAME, MODE_PRIVATE)
            .getString(RuntimeService.KEY_ACTIVE_PROJECT_DIR, null)
        val activeBot = botProjects.firstOrNull { bot ->
            try { File(botsDir, bot.optString("id")).canonicalPath == File(activeProjectPath ?: "").canonicalPath }
            catch (_: Exception) { false }
        }
        val runningText = if (running) "RUNNING" else "STOPPED"
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(4))
        }
        val autoRestart = prefs.getBoolean(RuntimeService.KEY_AUTO_RESTART, false)
        panel.addView(TextView(this).apply {
            text = "BotHost runtime: $runningText\nActive Discord bot: ${activeBot?.optString("display_name") ?: if (running) "Standalone script" else "None"}\nDiscord bot projects: ${botProjects.size}\nStandalone scripts: ${scripts.size}\nRuntime slots: 1 (one script/bot at a time)\nApp storage free: ${freeMb} MB / ${totalMb} MB\nDevice RAM available: ${memInfo.availMem / (1024 * 1024)} MB\nUnexpected-kill recovery: ${if (autoRestart) "ON" else "OFF"}\n\nRuns on this Android device. Recovery is best-effort; Android and device vendors can still restrict services."
            textSize = 14f
        })
        panel.addView(makeButton(if (autoRestart) "AUTO-RESTART: ON (TAP TO DISABLE)" else "AUTO-RESTART: OFF (TAP TO ENABLE)") {
            prefs.edit().putBoolean(RuntimeService.KEY_AUTO_RESTART, !autoRestart).apply()
            Toast.makeText(this, if (!autoRestart) "Unexpected-kill recovery enabled" else "Unexpected-kill recovery disabled", Toast.LENGTH_SHORT).show()
            showHostingPanel()
        })
        panel.addView(makeButton("BATTERY / BACKGROUND SETTINGS") {
            openBackgroundSettings()
        })
        AlertDialog.Builder(this)
            .setTitle("VESPER BOTHOST · LOCAL CONTROL")
            .setView(panel)
            .setPositiveButton(if (running) "STOP RUNTIME" else "OPEN BOTS") { _, _ ->
                if (running) stopScript() else showTab("projects")
            }
            .setNeutralButton("START STANDALONE SCRIPT") { _, _ ->
                val chosen = scripts.firstOrNull { it.name == startup }
                    ?: scripts.firstOrNull { it.name == "main.py" }
                    ?: scripts.firstOrNull()
                if (chosen == null) {
                    Toast.makeText(this, "No standalone script. Open Bots to create or import a Discord bot.", Toast.LENGTH_LONG).show()
                } else {
                    openProject(chosen)
                    runScript()
                }
            }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun openBackgroundSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            } else {
                Intent(android.provider.Settings.ACTION_SETTINGS)
            }
            startActivity(intent)
        } catch (e: Exception) {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            catch (_: Exception) {
                Toast.makeText(this, "Open Android Settings and review Vesper BotHost battery/background restrictions.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun chooseStartupScript() {
        val scripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        if (scripts.isEmpty()) {
            Toast.makeText(this, "Create or import a Python script first", Toast.LENGTH_SHORT).show()
            return
        }
        val current = getSharedPreferences("vesper_hosting", MODE_PRIVATE).getString("startup_script", "main.py")
        AlertDialog.Builder(this)
            .setTitle("Choose startup script")
            .setSingleChoiceItems(scripts.map { if (it.name == current) "✓ ${it.name}" else it.name }.toTypedArray(),
                scripts.indexOfFirst { it.name == current }.coerceAtLeast(-1)) { dialog, which ->
                val selected = scripts[which]
                getSharedPreferences("vesper_hosting", MODE_PRIVATE).edit().putString("startup_script", selected.name).apply()
                openProject(selected)
                Toast.makeText(this, "Startup script: ${selected.name}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showProjects() {
        val files = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", ignoreCase = true) }
            ?.sortedBy { it.name.lowercase() }
            .orEmpty()
        if (files.isEmpty()) {
            Toast.makeText(this, "No Python projects found", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Open Python project")
            .setItems(files.map { it.name }.toTypedArray()) { _, index -> openProject(files[index]) }
             .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun isManagedPythonFile(file: File): Boolean {
        return try {
            val target = file.canonicalFile
            val parent = target.parentFile ?: return false
            val projectsRoot = projectsDir.canonicalFile
            val botsRoot = botsDir.canonicalFile
            target.isFile && target.extension.equals("py", ignoreCase = true) &&
                (parent == projectsRoot || (parent.parentFile == botsRoot && parent.name.matches(Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,39}"))))
        } catch (_: Exception) {
            false
        }
    }

    private fun openProject(file: File) {
        if (running) {
            Toast.makeText(this, "Wait for the running job to finish before switching code", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val canonicalFile = file.canonicalFile
            if (!isManagedPythonFile(canonicalFile)) {
                Toast.makeText(this, "Invalid Python file outside the Vesper workspace", Toast.LENGTH_LONG).show()
                return
            }
            if (canonicalFile.length() > maxImportedProjectBytes) {
                Toast.makeText(this, "Project file exceeds ${maxImportedProjectBytes / 1000} KB", Toast.LENGTH_LONG).show()
                return
            }
            editor.setText(canonicalFile.readText(Charsets.UTF_8))
            currentFile = canonicalFile
            val relative = try { canonicalFile.relativeTo(filesDir.canonicalFile).path } catch (_: Exception) { canonicalFile.name }
            currentFileLabel.text = "Espacio de trabajo / $relative"
            status.text = "LISTO"
        } catch (e: Exception) {
            appendConsole("Could not open project: ${e.message ?: e.javaClass.simpleName}")
        }
    }


    private fun createProjectDialog() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before creating a project", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            hint = "example_bot"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Create Python project")
            .setMessage("Use letters, numbers, underscores or hyphens.")
            .setView(input)
             .setPositiveButton("Crear", null)
             .setNegativeButton("Cancelar", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val rawName = input.text.toString().trim().removeSuffix(".py")
                        if (!rawName.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}"))) {
                            input.error = "Enter a valid name (1–40 characters)"
                            return@setOnClickListener
                        }
                        val file = File(projectsDir, "$rawName.py")
                        if (file.exists()) {
                            input.error = "That project already exists"
                            return@setOnClickListener
                        }
                        try {
                            file.writeText("# $rawName\n\nprint(\"Hello from Vesper Runtime\")\n")
                            openProject(file)
                            dialog.dismiss()
                            Toast.makeText(this, "Created ${file.name}", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            input.error = "Could not create file: ${e.message ?: "unknown error"}"
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun saveCurrentProject(showToast: Boolean): Boolean {
        val file = currentFile ?: run {
            Toast.makeText(this, "Select or create a project first", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val target = file.canonicalFile
            if (!isManagedPythonFile(target)) {
                appendConsole("Save blocked: project path is outside the managed Python workspaces")
                false
            } else {
                val content = editor.text.toString()
                if (content.length > maxImportedProjectBytes || content.toByteArray(Charsets.UTF_8).size > maxImportedProjectBytes) {
                    Toast.makeText(this, "Project exceeds ${maxImportedProjectBytes / 1000} KB", Toast.LENGTH_LONG).show()
                    return false
                }
                target.writeText(content, Charsets.UTF_8)
                if (showToast) Toast.makeText(this, "Saved ${target.name}", Toast.LENGTH_SHORT).show()
                true
            }
        } catch (e: Exception) {
            appendConsole("Could not save project: ${e.message ?: e.javaClass.simpleName}")
            false
        }
    }

    private fun showDependencyManager() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before editing dependencies", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            setText(readRequirements())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            hint = "requests>=2.32,<3.0"
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundColor(Color.rgb(34, 34, 47))
            setPadding(14, 14, 14, 14)
            minLines = 9
            filters = arrayOf(InputFilter.LengthFilter(32_768))
        }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 4)
            addView(TextView(this@MainActivity).apply {
                text = "One package per line. Examples: requests>=2.32,<3.0 or discord.py>=2.4,<3.0.\n\nThese requirements are packaged into a new APK at build time. They do not install into the already-installed APK."
                setTextColor(Color.LTGRAY)
                textSize = 13f
                setPadding(0, 0, 0, 10)
            }, wrapMatch())
            addView(ScrollView(this@MainActivity).apply { addView(input) }, LinearLayout.LayoutParams(-1, dp(280)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Python dependencies")
            .setView(holder)
            .setPositiveButton("Save", null)
            .setNeutralButton("Validate", null)
             .setNegativeButton("Cancelar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val report = try {
                    validateRequirements(input.text.toString())
                } catch (e: Exception) {
                    Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                showRequirementsReport(report)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val report = try {
                    validateRequirements(input.text.toString())
                } catch (e: Exception) {
                    Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!report.optBoolean("valid", false)) {
                    showRequirementsReport(report)
                    return@setOnClickListener
                }
                try {
                    val saved = report.optString("normalized_text", input.text.toString())
                    requirementsFile.writeText(saved)
                    val count = report.optJSONArray("requirements")?.length() ?: 0
                    dialog.dismiss()
                    Toast.makeText(
                        this,
                        "Saved $count requirement(s). Export app/requirements.txt and rebuild the APK.",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not save requirements: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
        dialog.show()
    }

    private fun readRequirements(): String = try {
        requirementsFile.readText()
    } catch (_: Exception) {
        "# Vesper Runtime Python dependencies\n"
    }

    private fun validateRequirements(contents: String): JSONObject {
        val jsonText = Python.getInstance().getModule("vesper_dependencies")
            .callAttr("validate_requirements_json", contents)?.toString()
            ?: throw IllegalStateException("Dependency validator returned no result")
        return JSONObject(jsonText)
    }

    private fun showRequirementsReport(report: JSONObject) {
        val errors = jsonArrayToLines(report.optJSONArray("errors"))
        val packages = jsonArrayToLines(report.optJSONArray("requirements"))
        val warnings = jsonArrayToLines(report.optJSONArray("warnings"))
        val message = buildString {
            append(if (report.optBoolean("valid", false)) "Syntax check: PASS" else "Syntax check: FAILED")
            append("\n\nPackages: ").append(packages.size)
            if (errors.isNotEmpty()) {
                append("\n\nErrors:\n")
                append(errors.joinToString("\n"))
            }
            if (warnings.isNotEmpty()) {
                append("\n\nImportant:\n")
                append(warnings.joinToString("\n"))
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Dependency validation")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun jsonArrayToLines(array: org.json.JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            array.optString(index).takeIf { it.isNotBlank() }
        }
    }

    private fun exportRequirements() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before exporting dependencies", Toast.LENGTH_LONG).show()
            return
        }
        val content = readRequirements()
        val report = try {
            validateRequirements(content)
        } catch (e: Exception) {
            Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            return
        }
        if (!report.optBoolean("valid", false)) {
            showRequirementsReport(report)
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "requirements.txt")
        }
        try {
            startActivityForResult(intent, exportRequirementsRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open document picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses the platform document picker for broad API-level compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) {
            if (requestCode == exportProjectRequestCode) {
                pendingProjectExportName = null
                pendingProjectExportText = null
            }
            return
        }
        val uri = data?.data ?: return
        when (requestCode) {
            importProjectRequestCode -> importSelectedProject(uri)
            importFilesRequestCode -> importSelectedFileOrArchive(uri)
            importBotZipRequestCode -> importBotZip(uri, displayName(uri) ?: "discord_bot.zip")
            exportRequirementsRequestCode -> {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                        writer.write(readRequirements())
                    } ?: throw IllegalStateException("Could not open the selected destination")
                    Toast.makeText(this, "Exported requirements.txt. Copy it to app/requirements.txt in the source project, then rebuild the APK.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Export failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
            exportProjectRequestCode -> {
                val exportText = pendingProjectExportText
                val exportName = pendingProjectExportName ?: "project.py"
                pendingProjectExportText = null
                pendingProjectExportName = null
                try {
                    if (exportText == null) throw IllegalStateException("No project content to export")
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(exportText) }
                        ?: throw IllegalStateException("Could not open destination")
                    Toast.makeText(this, "Exported $exportName", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Project export failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun importProject() {
        if (running) {
            Toast.makeText(this, "Stop the current script before importing a project", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importProjectRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importAnyFile() {
        if (running) {
            Toast.makeText(this, "Stop the current script before importing files", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "text/*", "application/octet-stream", "application/json", "application/pdf", "image/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importFilesRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importedFilesDir(): File = File(filesDir, "imports").apply { mkdirs() }

    private fun cleanImportedPath(raw: String): String {
        val normalized = raw.replace('\\', '/').trimStart('/')
        val parts = normalized.split('/')
        if (normalized.isBlank() || parts.any { it.isBlank() || it == "." || it == ".." } || normalized.contains(':')) {
            throw SecurityException("Archive contains an unsafe path")
        }
        return parts.joinToString("/") { part -> part.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(100).ifBlank { "file" } }
    }

    private fun uniqueImportedFile(parent: File, name: String): File {
        val base = name.substringAfterLast('/').ifBlank { "imported_file" }
        var candidate = File(parent, base)
        var n = 2
        while (candidate.exists()) {
            val stem = base.substringBeforeLast('.', base)
            val ext = if (base.contains('.')) "." + base.substringAfterLast('.') else ""
            candidate = File(parent, "${stem.take(80)}_$n$ext")
            n++
            if (n > 10000) throw IllegalStateException("Could not create a unique filename")
        }
        return candidate.canonicalFile.also {
            if (it.parentFile?.canonicalFile != parent.canonicalFile) throw SecurityException("Invalid import destination")
        }
    }

    private fun importSelectedFileOrArchive(uri: Uri) {
        try {
            val sourceName = displayName(uri) ?: "imported_file"
            if (sourceName.endsWith(".zip", ignoreCase = true)) {
                importZip(uri, sourceName)
            } else {
                val bytes = readLimited(uri, maxImportedArchiveBytes)
                val target = uniqueImportedFile(importedFilesDir(), sourceName.replace(Regex("[^A-Za-z0-9._ -]"), "_"))
                target.writeBytes(bytes)
                if (target.extension.equals("py", ignoreCase = true)) {
                    // Python projects live in their own workspace; copy there with a collision-safe name.
                    val projectTarget = uniqueImportedFile(projectsDir, target.name)
                    target.copyTo(projectTarget)
                    openProject(projectTarget)
                    Toast.makeText(this, "Imported ${projectTarget.name}. Review it before running.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Imported ${target.name} to Vesper/imports", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importZip(uri: Uri, archiveName: String) {
        val root = importedFilesDir().canonicalFile
        val folderName = archiveName.substringBeforeLast('.', archiveName)
            .replace(Regex("[^A-Za-z0-9_-]"), "_").take(50).ifBlank { "archive" }
        val destination = uniqueImportedFile(root, folderName).apply { mkdirs() }.canonicalFile
        var entryCount = 0
        var totalBytes = 0L
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open ZIP")
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entryCount++
                    if (entryCount > maxArchiveEntries) throw IllegalArgumentException("ZIP has too many entries (limit $maxArchiveEntries)")
                    val relative = cleanImportedPath(entry.name)
                    val output = File(destination, relative).canonicalFile
                    if (output != destination && !output.path.startsWith(destination.path + File.separator)) {
                        throw SecurityException("ZIP entry escapes destination")
                    }
                    if (entry.isDirectory) {
                        output.mkdirs()
                    } else {
                        output.parentFile?.mkdirs()
                        var entryBytes = 0L
                        output.outputStream().buffered().use { stream ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                entryBytes += count
                                totalBytes += count
                                if (totalBytes > maxImportedArchiveBytes) throw IllegalArgumentException("Expanded ZIP exceeds 20 MB")
                                stream.write(buffer, 0, count)
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
            if (entryCount == 0) throw IllegalArgumentException("ZIP is empty or invalid")

            // Prefer a project root script over incidental package files such as
            // bot/__init__.py. If the ZIP wraps the whole project in one directory,
            // import that directory's contents as the workspace root. Otherwise
            // preserve the archive root, including packages in sibling folders.
            val archiveEntries = destination.listFiles()?.filterNot {
                it.name == "__MACOSX" || it.name == ".DS_Store" || it.name.startsWith(".")
            }.orEmpty()
            var sourceRoot = destination
            val rootScripts = archiveEntries.filter { it.isFile && isRunnablePythonFile(it) }
            if (rootScripts.isEmpty()) {
                val wrapperDirs = archiveEntries.filter { it.isDirectory }
                val rootFiles = archiveEntries.filter { it.isFile }
                if (wrapperDirs.size == 1 && rootFiles.isEmpty()) {
                    val wrapper = wrapperDirs.single()
                    if (listProjectPythonFiles(wrapper).isNotEmpty()) sourceRoot = wrapper.canonicalFile
                }
            }

            val pythonFiles = listProjectPythonFiles(sourceRoot)
            val extractedPy = chooseStartupPythonFile(pythonFiles, sourceRoot)
                ?: throw IllegalArgumentException("ZIP contains no runnable Python script (.py)")
            val projectTarget = uniqueImportedFile(projectsDir, extractedPy.name)
            copyProjectDirectory(sourceRoot, projectsDir, extractedPy.canonicalFile, projectTarget)
            openProject(projectTarget)
            Toast.makeText(
                this,
                "Imported $entryCount ZIP entries. Startup: ${projectTarget.name}. Local modules were included; review dependencies before running.",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            destination.deleteRecursively()
            throw e
        }
    }

    private fun isRunnablePythonFile(file: File): Boolean =
        file.isFile && file.extension.equals("py", ignoreCase = true) &&
            !file.name.equals("__init__.py", ignoreCase = true)

    private fun listProjectPythonFiles(root: File): List<File> {
        val ignored = setOf("__MACOSX", "__pycache__", ".git", ".venv", "venv", "env", "node_modules", "build", "dist")
        return root.walkTopDown().onEnter { dir -> dir == root || dir.name !in ignored }
            .maxDepth(20)
            .filter { isRunnablePythonFile(it) }
            .toList()
    }

    private fun chooseStartupPythonFile(files: List<File>, root: File): File? {
        if (files.isEmpty()) return null
        val preferredNames = listOf("main.py", "main_2.py", "bot.py", "app.py", "run.py", "start.py", "server.py")
        val rootFiles = files.filter { it.parentFile?.canonicalFile == root.canonicalFile }
        for (preferred in preferredNames) {
            rootFiles.firstOrNull { it.name.equals(preferred, ignoreCase = true) }?.let { return it }
        }
        rootFiles.firstOrNull { !it.name.startsWith("test_", ignoreCase = true) }?.let { return it }
        for (preferred in preferredNames) {
            files.firstOrNull { it.name.equals(preferred, ignoreCase = true) }?.let { return it }
        }
        return files.firstOrNull { !it.name.startsWith("test_", ignoreCase = true) } ?: files.first()
    }

    private fun copyProjectDirectory(source: File, targetRoot: File, startupSource: File, startupTarget: File) {
        val canonicalRoot = targetRoot.canonicalFile

        // Validate every target before copying any file. This prevents a conflicting
        // import from leaving a half-copied project behind in the runnable workspace.
        fun validateNode(node: File) {
            val canonicalNode = node.canonicalFile
            if (canonicalNode == startupSource) return // This file is renamed to startupTarget.
            val destination = File(canonicalRoot, node.relativeTo(source).path).canonicalFile
            if (destination != canonicalRoot && !destination.path.startsWith(canonicalRoot.path + File.separator)) {
                throw SecurityException("Project file escapes workspace")
            }
            if (node.isDirectory) {
                if (destination.exists() && !destination.isDirectory) {
                    throw IllegalStateException("Cannot import ${node.name}: a file with that name already exists")
                }
                node.listFiles()?.forEach { validateNode(it) }
            } else if (destination.exists()) {
                throw IllegalStateException("Cannot import ${node.name}: file already exists in the project workspace")
            }
        }
        source.listFiles()?.forEach { validateNode(it) }
        if (startupTarget.exists()) throw IllegalStateException("Startup file already exists: ${startupTarget.name}")

        fun copyNode(node: File) {
            val canonicalNode = node.canonicalFile
            if (canonicalNode == startupSource) {
                startupTarget.parentFile?.mkdirs()
                startupSource.copyTo(startupTarget, overwrite = false)
                return
            }
            val destination = File(canonicalRoot, node.relativeTo(source).path).canonicalFile
            if (destination != canonicalRoot && !destination.path.startsWith(canonicalRoot.path + File.separator)) {
                throw SecurityException("Project file escapes workspace")
            }
            if (node.isDirectory) {
                if (destination.exists() && !destination.isDirectory) {
                    throw IllegalStateException("Cannot import ${node.name}: a file with that name already exists")
                }
                destination.mkdirs()
                node.listFiles()?.forEach { copyNode(it) }
            } else {
                destination.parentFile?.mkdirs()
                if (destination.exists()) {
                    throw IllegalStateException("Cannot import ${node.name}: file already exists in the project workspace")
                }
                node.copyTo(destination, overwrite = false)
            }
        }
        source.listFiles()?.forEach { copyNode(it) }
        if (!startupTarget.isFile) throw IllegalStateException("Startup script was not copied")
    }

    private fun showImportedFiles() {
        showFileBrowser(importedFilesDir())
    }

    /** In-app file manager: keeps navigation inside Vesper's private workspace. */
    private fun showFileBrowser(directory: File) {
        val roots = listOf(importedFilesDir(), projectsDir, botsDir).map { it.canonicalFile }
        val current = directory.canonicalFile
        val root = roots.firstOrNull { current == it || current.path.startsWith(it.path + File.separator) }
        if (root == null) {
            Toast.makeText(this, "Invalid folder path", Toast.LENGTH_SHORT).show()
            return
        }
        current.mkdirs()
        val entries = current.listFiles()
            ?.filterNot { it.name.equals(".env", ignoreCase = true) || it.name.equals(".vesper-logs", ignoreCase = true) || it.name.equals("__pycache__", ignoreCase = true) }
            ?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
        val rootLabel = when (root) {
            botsDir.canonicalFile -> "bots"
            projectsDir.canonicalFile -> "projects"
            else -> "imports"
        }
        val labels = mutableListOf<String>()
        if (current != root) labels.add("⬆  ..")
        labels.add("＋  Import ZIP / files")
        labels.add("◉  Discord bot manager")
        labels.addAll(entries.map { (if (it.isDirectory) "📁  " else fileIcon(it) + "  ") + it.name + if (it.isDirectory) "/" else "" })
        AlertDialog.Builder(this)
            .setTitle("Files  ·  $rootLabel / ${if (current == root) "" else current.relativeTo(root).path}")
            .setItems(labels.toTypedArray()) { _, index ->
                when {
                    current != root && index == 0 -> showFileBrowser(current.parentFile ?: root)
                    index == if (current != root) 1 else 0 -> importAnyFile()
                    index == if (current != root) 2 else 1 -> showTab("projects")
                    else -> {
                        val entryIndex = index - (if (current != root) 3 else 2)
                        if (entryIndex in entries.indices) {
                            val selected = entries[entryIndex]
                            if (selected.isDirectory) showFileBrowser(selected) else showFileActions(selected, current)
                        }
                    }
                }
            }
            .setPositiveButton("＋ Import", null)
            .setNeutralButton("Refresh") { _, _ -> showFileBrowser(current) }
            .setNegativeButton("Close", null)
            .show()
    }


    private fun fileIcon(file: File): String = when (file.extension.lowercase()) {
        "py" -> "🐍"
        "zip", "gz", "rar", "7z" -> "▣"
        "json", "txt", "md", "yml", "yaml" -> "▤"
        "sqlite", "db" -> "▤"
        else -> "▧"
    }

    private fun showFileActions(file: File, parent: File) {
        val options = mutableListOf("Open / Preview", "Select", "Duplicate", "Rename", "Move", "Download / Export", "Unarchive", "Pin to sidebar", "Delete")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(options.toTypedArray()) { _, index ->
                when (index) {
                    0 -> openOrPreviewFile(file)
                    1 -> Toast.makeText(this, "Selected: ${file.name}", Toast.LENGTH_SHORT).show()
                    2 -> duplicateManagedFile(file)
                    3 -> promptRename(file, parent)
                    4 -> moveManagedFile(file)
                    5 -> exportManagedFile(file)
                    6 -> unarchiveManagedFile(file)
                    7 -> {
                        getSharedPreferences("vesper_runtime", MODE_PRIVATE).edit().putString("pinned_file", file.absolutePath).apply()
                        Toast.makeText(this, "Pinned ${file.name} to quick access", Toast.LENGTH_SHORT).show()
                    }
                    8 -> AlertDialog.Builder(this).setTitle("Delete ${file.name}?")
                        .setMessage("This permanently removes this item from Vesper's private workspace.")
                         .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Delete") { _, _ ->
                            val allowedRoots = listOf(importedFilesDir(), projectsDir, botsDir).map { it.canonicalFile }
                            val target = file.canonicalFile
                            val allowed = allowedRoots.any { root -> target.path.startsWith(root.path + File.separator) && target != root }
                            if (file.name.equals(".env", ignoreCase = true)) {
                                Toast.makeText(this, "Remove secrets from Bot settings instead.", Toast.LENGTH_LONG).show()
                            } else if (allowed) {
                                target.deleteRecursively()
                                Toast.makeText(this, "Deleted ${file.name}", Toast.LENGTH_SHORT).show()
                            } else Toast.makeText(this, "This item cannot be deleted here", Toast.LENGTH_LONG).show()
                        }.show()
                }
            } .setNegativeButton("Cancelar", null).show()
    }

    private fun openOrPreviewFile(file: File) {
        if (file.isDirectory) { showFileBrowser(file); return }
        if (file.name.equals(".env", ignoreCase = true)) {
            Toast.makeText(this, "Secret files are hidden. Manage DISCORD_TOKEN from the Bot settings screen.", Toast.LENGTH_LONG).show()
            return
        }
        if (file.extension.equals("py", true) && file.length() <= maxImportedProjectBytes) {
            try {
                if (isManagedPythonFile(file)) {
                    openProject(file)
                } else {
                    val projectTarget = uniqueImportedFile(projectsDir, file.name)
                    file.copyTo(projectTarget)
                    openProject(projectTarget)
                }
                Toast.makeText(this, "Opened ${file.name}; review code before running", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this, "Could not open file: ${e.message}", Toast.LENGTH_LONG).show() }
        } else {
            val preview = if (file.length() <= 100_000 && file.extension.lowercase() in setOf("txt", "md", "json", "log", "yml", "yaml", "env", "py")) {
                try { file.readText(Charsets.UTF_8) } catch (_: Exception) { "Preview unavailable" }
            } else "${file.name}\n\n${file.length()} bytes\n\nStored in Vesper's private workspace."
            val text = TextView(this).apply { this.text = preview; textSize = 13f; setTextColor(Color.LTGRAY); setPadding(dp(16), dp(12), dp(16), dp(12)) }
            AlertDialog.Builder(this).setTitle(file.name).setView(ScrollView(this).apply { addView(text) }).setPositiveButton("OK", null).show()
        }
    }

    private fun duplicateManagedFile(file: File) {
        try {
            val target = uniqueImportedFile(file.parentFile ?: importedFilesDir(), "${file.name.substringBeforeLast('.', file.name)}_copy${if (file.name.contains('.')) ".${file.name.substringAfterLast('.')}" else ""}")
            if (file.isDirectory) file.copyRecursively(target, overwrite = false) else file.copyTo(target)
            Toast.makeText(this, "Duplicated as ${target.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Duplicate failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun promptRename(file: File, parent: File) {
        val input = EditText(this).apply { setText(file.name); setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Rename item").setView(input)
             .setNegativeButton("Cancelar", null).setPositiveButton("Rename") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank() || name in setOf(".", "..") || name.contains('/') || name.contains('\\')) {
                    Toast.makeText(this, "Invalid filename", Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                val target = File(parent, name)
                if (target.exists()) Toast.makeText(this, "An item with that name already exists", Toast.LENGTH_SHORT).show()
                else if (file.renameTo(target)) Toast.makeText(this, "Renamed to $name", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "Rename failed", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun moveManagedFile(file: File) {
        val destinations = arrayOf("Imports", "Python projects")
        AlertDialog.Builder(this).setTitle("Move ${file.name} to…").setItems(destinations) { _, which ->
            val targetDir = if (which == 0) importedFilesDir() else projectsDir
            try {
                val target = uniqueImportedFile(targetDir, file.name)
                val moved = if (file.isDirectory) file.renameTo(target) else file.renameTo(target)
                if (moved) Toast.makeText(this, "Moved to ${targetDir.name}", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "Move failed; try duplicating then deleting", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this, "Move failed: ${e.message}", Toast.LENGTH_LONG).show() }
        }.show()
    }

    private fun exportManagedFile(file: File) {
        if (file.name.equals(".env", ignoreCase = true) || file.name.equals(".vesper-logs", ignoreCase = true)) {
            Toast.makeText(this, "Private bot secrets and runtime logs cannot be exported from this menu", Toast.LENGTH_LONG).show()
            return
        }
        if (file.isDirectory) { Toast.makeText(this, "Export folders as ZIP by using Import / Export tools", Toast.LENGTH_LONG).show(); return }
        pendingProjectExportName = file.name
        pendingProjectExportText = try { file.readText(Charsets.UTF_8) } catch (_: Exception) { null }
        if (pendingProjectExportText == null) {
            Toast.makeText(this, "This file type cannot be exported as text from this menu", Toast.LENGTH_LONG).show(); return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, file.name)
        }
        try { startActivityForResult(intent, exportProjectRequestCode) }
        catch (e: Exception) { Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun unarchiveManagedFile(file: File) {
        if (!file.isFile || !file.name.endsWith(".zip", true)) {
            Toast.makeText(this, "Unarchive currently supports ZIP files", Toast.LENGTH_SHORT).show(); return
        }
        try {
            val destination = uniqueImportedFile(file.parentFile ?: importedFilesDir(), file.name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._ -]"), "_")).apply { mkdirs() }.canonicalFile
            var count = 0; var total = 0L
            ZipInputStream(file.inputStream().buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    count++; if (count > maxArchiveEntries) throw IllegalArgumentException("Too many archive entries")
                    val relative = cleanImportedPath(entry.name)
                    val out = File(destination, relative).canonicalFile
                    if (out != destination && !out.path.startsWith(destination.path + File.separator)) throw SecurityException("Unsafe archive path")
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().buffered().use { stream ->
                            val buffer = ByteArray(8192)
                            while (true) { val n = zip.read(buffer); if (n < 0) break; total += n; if (total > maxImportedArchiveBytes) throw IllegalArgumentException("Expanded archive exceeds 20 MB"); stream.write(buffer, 0, n) }
                        }
                    }
                    zip.closeEntry()
                }
            }
            if (count == 0) throw IllegalArgumentException("ZIP is empty or invalid")
            Toast.makeText(this, "Extracted $count entries to ${destination.name}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Unarchive failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun exportCurrentProject() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before exporting", Toast.LENGTH_LONG).show()
            return
        }
        val file = currentFile ?: return
        if (!saveCurrentProject(showToast = false)) return
        try {
            pendingProjectExportName = file.name
            pendingProjectExportText = file.readText(Charsets.UTF_8)
        } catch (e: Exception) {
            pendingProjectExportName = null
            pendingProjectExportText = null
            Toast.makeText(this, "Could not read project: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/x-python"
            putExtra(Intent.EXTRA_TITLE, file.name)
        }
        try {
            startActivityForResult(intent, exportProjectRequestCode)
        } catch (e: Exception) {
            pendingProjectExportName = null
            pendingProjectExportText = null
            Toast.makeText(this, "Could not open export picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun readLimited(uri: Uri, limit: Int): ByteArray {
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open selected file")
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                if (total > limit) throw IllegalArgumentException("Python file exceeds ${limit / 1000} KB")
                out.write(buffer, 0, count)
            }
            return out.toByteArray()
        }
    }

    private fun displayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } else null
        } catch (_: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }

    private fun safeImportedName(displayName: String): String {
        val raw = displayName.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("(?i)\\.py$"), "")
        return if (raw.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}"))) raw else "imported_script"
    }

    private fun importSelectedProject(uri: Uri) {
        try {
            val sourceName = displayName(uri) ?: throw IllegalArgumentException("Could not determine the selected filename")
            if (!sourceName.endsWith(".py", ignoreCase = true)) {
                throw IllegalArgumentException("Select a .py Python source file")
            }
            val content = readLimited(uri, maxImportedProjectBytes).toString(Charsets.UTF_8)
            val baseName = safeImportedName(sourceName)
            var candidateName = "$baseName.py"
            var suffix = 2
            while (File(projectsDir, candidateName).exists()) {
                val suffixedBase = "${baseName.take(34)}_$suffix"
                candidateName = "$suffixedBase.py"
                suffix++
                if (suffix > 10_000) throw IllegalStateException("Could not generate a unique filename")
            }
            val target = File(projectsDir, candidateName).canonicalFile
            if (target.parentFile != projectsDir.canonicalFile) throw SecurityException("Invalid import destination")
            target.writeText(content, Charsets.UTF_8)
            openProject(target)
            Toast.makeText(this, "Imported ${target.name}. Review the code before running it.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopScript() {
        if (!running) return
        stopButton.isEnabled = false
        status.text = "DETENIENDO"
        startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_STOP))
    }

    private fun runScript() {
        val selectedFile = currentFile ?: return
        if (currentFile?.canonicalPath == selectedFile.canonicalPath && !saveCurrentProject(showToast = false)) return
        startManagedScript(selectedFile)
    }

    private fun startManagedScript(selectedFile: File) {
        if (running) {
            appendConsole("La ranura de ejecución está ocupada. Vesper BotHost 10.0 ejecuta un solo proceso Python a la vez.")
            return
        }
        val script = try { selectedFile.canonicalFile } catch (_: Exception) {
            Toast.makeText(this, "La ruta del script no es válida", Toast.LENGTH_LONG).show()
            return
        }
        if (!isManagedPythonFile(script) || script.length() > maxImportedProjectBytes) {
            Toast.makeText(this, "El script debe ser un archivo .py administrado de hasta 1 MB", Toast.LENGTH_LONG).show()
            return
        }
        val projectDir = script.parentFile ?: return
        running = true
        lastLogBytesRead = 0L
        if (currentTab != "home" && currentTab != "projects") runButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "INICIANDO"
        appendConsole("\n> Iniciando ${script.name} desde ${projectDir.name} ...")

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationPermissionRequestCode)
        }
        val intent = Intent(this, RuntimeService::class.java).apply {
            action = RuntimeService.ACTION_RUN
            putExtra(RuntimeService.EXTRA_SCRIPT_NAME, script.name)
            putExtra(RuntimeService.EXTRA_PROJECT_DIR, projectDir.canonicalPath)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            running = false
            if (currentTab != "home" && currentTab != "projects") runButton.isEnabled = true
            stopButton.isEnabled = false
            status.text = "ERROR"
            appendConsole("Could not start foreground service: ${e.message ?: e.javaClass.simpleName}")
        }
    }


    private fun appendConsole(message: String) {
        appendConsoleRaw(message + if (message.endsWith("\n")) "" else "\n")
    }

    private fun appendConsoleRaw(chunk: String) {
        if (chunk.isEmpty()) return
        val maxChars = 100_000
        val existing = console.text.toString()
        val combined = existing + chunk
        console.text = if (combined.length > maxChars) {
            "[Earlier console output trimmed]\n" + combined.takeLast(maxChars - 34)
        } else combined
    }

    private fun showFatalRuntimeError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Vesper Runtime could not start")
            .setMessage(message)
            .setPositiveButton("Close") { _, _ -> finish() }
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun wrapMatch() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
