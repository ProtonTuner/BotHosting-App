# Vesper Runtime 1.7.0 — Verification report

## Verified in this workspace
- Python host-side unit and integration tests are run with `python -m unittest discover -s tests -v`.
- Tests cover output capture, stop behavior, bounded output, local imports from both root and nested project directories, missing-module diagnostics, requirements validation, ZIP/file-import implementation contracts, service wiring, and version metadata.
- Android manifest is parsed and checked by integration tests.
- ZIP integrity is checked after the release archive is produced.

## Not verified here
- Android Gradle compilation or APK assembly: no local Gradle executable/wrapper or configured Android SDK is available in this workspace.
- Physical-device installation, startup, background service, network access, or memory behavior.
- Compatibility of arbitrary user dependency lists. Chaquopy packages dependencies into the APK at build time; an installed APK cannot universally `pip install` arbitrary packages on demand. Packages must support the Android/Chaquopy target ABI and Python version.
- A user's complete bot ZIP, because no such project archive was supplied as part of this release workspace.

## Known runtime constraints
- Imports are resolved against the imported project's workspace and subdirectories. A package must actually be present in the ZIP to be imported as local code.
- Third-party dependencies must be listed in `app/requirements.txt` in the Android source project and the APK must be rebuilt. Some packages, especially those requiring unsupported native extensions or desktop OS APIs, will not work on Android.
- Foreground-service recovery is best-effort. Android can still stop apps, and Vesper Runtime is not a guarantee of uninterrupted 24/7 hosting.
- This is a source ZIP. A successful host-side test suite does not prove that an Android build or every third-party project will run without errors.
