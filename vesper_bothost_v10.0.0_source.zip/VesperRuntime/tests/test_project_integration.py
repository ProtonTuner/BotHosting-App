import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parents[1]
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"


class ProjectIntegrationTests(unittest.TestCase):
    def test_chaquopy_build_reads_requirements_manifest(self):
        gradle = (ROOT / "app" / "build.gradle").read_text(encoding="utf-8")
        self.assertIn("install('-r', 'requirements.txt')", gradle)
        self.assertTrue((ROOT / "app" / "requirements.txt").is_file())

    def test_default_runtime_manifest_matches_build_template(self):
        source = (ROOT / "app" / "requirements.txt").read_text(encoding="utf-8")
        asset = (ROOT / "app" / "src" / "main" / "assets" / "requirements.txt").read_text(encoding="utf-8")
        self.assertEqual(source, asset)
        self.assertIn("discord.py==2.7.1", source)

    def test_manifest_has_internet_permission_and_exported_launcher(self):
        manifest_path = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
        tree = ET.parse(manifest_path)
        manifest = tree.getroot()
        permissions = {node.attrib.get(ANDROID_NS + "name") for node in manifest.findall("uses-permission")}
        self.assertIn("android.permission.INTERNET", permissions)
        activity = manifest.find("application/activity")
        self.assertIsNotNone(activity)
        self.assertEqual(activity.attrib.get(ANDROID_NS + "exported"), "true")

    def test_runtime_service_is_non_exported_and_declares_special_use(self):
        manifest_path = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
        tree = ET.parse(manifest_path)
        manifest = tree.getroot()
        permissions = {node.attrib.get(ANDROID_NS + "name") for node in manifest.findall("uses-permission")}
        self.assertIn("android.permission.FOREGROUND_SERVICE", permissions)
        self.assertIn("android.permission.FOREGROUND_SERVICE_SPECIAL_USE", permissions)
        app = manifest.find("application")
        service = app.find("service")
        self.assertIsNotNone(service)
        self.assertEqual(service.attrib.get(ANDROID_NS + "exported"), "false")
        self.assertEqual(service.attrib.get(ANDROID_NS + "foregroundServiceType"), "specialUse")
        service_src = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        self.assertIn("ServiceCompat.startForeground", service_src)
        self.assertIn("ACTION_STOP", service_src)
        self.assertIn("ACTION_QUERY", service_src)
        self.assertIn("startOutputPolling", service_src)
        self.assertIn("EXTRA_OUTPUT_OFFSET", service_src)

    def test_main_activity_has_project_transfer_and_stop_controls(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('private fun importSelectedProject(uri: Uri)', source)
        self.assertIn('Import ZIP / files', source)
        self.assertIn('private fun exportCurrentProject()', source)
        self.assertIn('private fun stopScript()', source)
        self.assertIn('makeButton("■ DETENER")', source)
        self.assertIn("maxImportedProjectBytes", source)

    def test_github_workflow_tests_and_uploads_debug_apk(self):
        workflow = (ROOT / ".github" / "workflows" / "android-apk.yml").read_text(encoding="utf-8")
        self.assertIn("workflow_dispatch:", workflow)
        self.assertIn("python -m unittest discover -s tests -v", workflow)
        self.assertIn("gradle --no-daemon :app:assembleDebug", workflow)
        self.assertIn("actions/upload-artifact@v4", workflow)
        self.assertIn("app/build/outputs/apk/debug/app-debug.apk", workflow)

    def test_activity_guards_lifecycle_after_python_initialization_failure(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("private var runtimeUiInitialized = false", source)
        self.assertIn("if (!runtimeUiInitialized) return", source)
        self.assertIn("runtimeUiInitialized = true", source)

    def test_run_handoff_uses_private_script_file_not_large_intent_payload(self):
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        service = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        self.assertNotIn("EXTRA_CODE", activity)
        self.assertIn("scriptFile.readText(Charsets.UTF_8)", service)
        self.assertIn("MAX_SCRIPT_BYTES", service)
        self.assertIn("content.toByteArray(Charsets.UTF_8).size > maxImportedProjectBytes", activity)

    def test_live_log_uses_byte_ranges_and_utf8_safe_chunks(self):
        service = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("EXTRA_OUTPUT_START_OFFSET", service)
        self.assertIn("completeUtf8PrefixLength", service)
        self.assertIn("endOffset <= lastLogBytesRead", activity)
        self.assertIn("appendMissedRunningOutput(startOffset)", activity)

    def test_version_is_ten_point_zero(self):
        gradle = (ROOT / "app" / "build.gradle").read_text(encoding="utf-8")
        self.assertIn("versionName '10.0.0'", gradle)
        self.assertIn("versionCode 100000", gradle)

    def test_zip_import_prefers_real_startup_and_preserves_project_tree(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("chooseStartupPythonFile(pythonFiles, sourceRoot)", source)
        self.assertIn('listOf("main.py", "main_2.py", "bot.py", "app.py", "run.py", "start.py", "server.py")', source)
        self.assertIn("copyProjectDirectory(sourceRoot, projectsDir, extractedPy.canonicalFile, projectTarget)", source)
        self.assertIn("Validate every target before copying any file", source)

    def test_in_app_file_manager_actions_and_safe_unarchive_exist(self):
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("private fun showFileBrowser", activity)
        self.assertIn("private fun showFileActions", activity)
        self.assertIn("private fun duplicateManagedFile", activity)
        self.assertIn("private fun unarchiveManagedFile", activity)
        self.assertIn("Expanded archive exceeds 20 MB", activity)
        self.assertIn("Unsafe archive path", activity)

    def test_service_supports_opt_in_sticky_recovery(self):
        service = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "RuntimeService.kt").read_text(encoding="utf-8")
        activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("return START_STICKY", service)
        self.assertIn("resumeAfterSystemRestart", service)
        self.assertIn("KEY_DESIRED_RUNNING", service)
        self.assertIn("clearDesiredRun()", service)
        self.assertIn("AUTO-RESTART: ON", activity)
        self.assertIn("BATTERY / BACKGROUND SETTINGS", activity)
        self.assertIn("ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS", activity)

    def test_local_hosting_panel_and_startup_script_controls_exist(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('"Panel de hosting"', source)
        self.assertIn('"Script de inicio"', source)
        self.assertIn('private fun showHostingPanel()', source)
        self.assertIn('private fun chooseStartupScript()', source)
        self.assertIn('putString("startup_script", selected.name)', source)
        self.assertIn('StatFs(filesDir.absolutePath)', source)
        self.assertIn('startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_STOP))', source)

    def test_zip_and_general_file_import_controls_exist(self):
        source = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text()
        self.assertIn('Import ZIP / files', source)
        self.assertIn('Archivos importados', source)
        self.assertIn('private fun importZip', source)
        self.assertIn('maxArchiveEntries', source)
        self.assertIn('cleanImportedPath', source)

    def test_in_app_dependency_controls_and_export_flow_exist(self):
        source = (ROOT / "app" / "src" / "main" / "java" / "com" / "vesper" / "runtime" / "MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('Dependencias', source)
        self.assertIn('showDependencyManager()', source)
        self.assertIn('"Exportar dependencias"', source)
        self.assertIn('private fun exportRequirements()', source)
        self.assertIn("Intent.ACTION_CREATE_DOCUMENT", source)
        self.assertIn('callAttr("validate_requirements_json", contents)', source)

    def test_adaptive_launcher_icon_is_configured(self):
        manifest = ET.parse(ROOT / "app" / "src" / "main" / "AndroidManifest.xml").getroot()
        app = manifest.find("application")
        self.assertEqual(app.attrib.get(ANDROID_NS + "icon"), "@mipmap/ic_launcher")
        self.assertTrue((ROOT / "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml").is_file())
        self.assertTrue((ROOT / "app/src/main/res/drawable/ic_vesper_launcher_foreground.xml").is_file())
        activity = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn("setImageResource(R.drawable.ic_vesper_launcher_foreground)", activity)

    def test_bothost_branding_and_discord_project_manager_exist(self):
        manifest = ET.parse(ROOT / "app" / "src" / "main" / "AndroidManifest.xml").getroot()
        app = manifest.find("application")
        self.assertEqual(app.attrib.get(ANDROID_NS + "label"), "Vesper BotHost")
        activity = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text(encoding="utf-8")
        for marker in ("GESTOR DE BOTS DISCORD", "createBotProjectDialog", "chooseBotZipImport", "configureBotToken", "startBotProject", "confirmDeleteBot"):
            self.assertIn(marker, activity)
        helper = (ROOT / "app/src/main/python/vesper_bot_host.py").read_text(encoding="utf-8")
        self.assertIn("app_commands.CommandTree", helper)
        self.assertIn("set_discord_token_json", helper)
        self.assertIn("clear_discord_token_json", helper)

    def test_v10_home_routes_to_bot_manager_and_secret_paths_are_case_insensitive(self):
        activity = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text(encoding="utf-8")
        self.assertIn('makeButton("◉  GESTIONAR BOTS") { showTab("projects") }', activity)
        self.assertIn('it.name.equals(".env", ignoreCase = true)', activity)
        self.assertIn('parts.any { it.lowercase() in setOf(".env"', activity)
        self.assertIn('text = "Tus bots. Bajo tu control."', activity)

    def test_secrets_are_not_exported_or_shown_by_bot_manager(self):
        activity = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text(encoding="utf-8")
        helper = (ROOT / "app/src/main/python/vesper_bot_host.py").read_text(encoding="utf-8")
        self.assertIn('file.name.equals(".env", ignoreCase = true)', activity)
        self.assertIn('"token_configured": _has_env_key(env_file, "DISCORD_TOKEN")', helper)
        self.assertNotIn('"DISCORD_TOKEN": _read_env', helper)

    def test_main_activity_uses_compact_tabbed_navigation(self):
        source = (ROOT / "app/src/main/java/com/vesper/runtime/MainActivity.kt").read_text(encoding="utf-8")
        for screen in ("buildHomeScreen", "buildProjectsScreen", "buildEditorScreen", "buildConsoleScreen", "buildFilesScreen", "buildMoreScreen"):
            self.assertIn(f"private fun {screen}", source)
        self.assertIn("private fun buildNavigationBar()", source)
        self.assertIn('Triple("home", "⌂", "Inicio")', source)
        self.assertIn('Triple("editor", "</>", "Editor")', source)
        self.assertIn("private fun detachView", source)
        self.assertIn('getString("startup_script", starter.name)', source)


if __name__ == "__main__":
    unittest.main()
