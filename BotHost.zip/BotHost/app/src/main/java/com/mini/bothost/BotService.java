package com.mini.bothost;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Servicio en primer plano que ejecuta UN bot. Hay 4 subclases (S0..S3), cada una en su
 * propio proceso, asi que cada bot tiene su propio interprete de Python, memoria y entorno.
 */
public class BotService extends Service {

    public static class S0 extends BotService { }
    public static class S1 extends BotService { }
    public static class S2 extends BotService { }
    public static class S3 extends BotService { }

    static final Class<?>[] SLOTS = {S0.class, S1.class, S2.class, S3.class};

    static final String A_START = "com.mini.bothost.START";
    static final String A_STOP = "com.mini.bothost.STOP";
    private static final String CHANNEL = "bots";

    private final AtomicBoolean down = new AtomicBoolean(false);
    private final Handler main = new Handler(Looper.getMainLooper());
    private Thread worker;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;
    private String botId;
    private int slot;

    private final Runnable notifTick = new Runnable() {
        @Override
        public void run() {
            if (down.get() || botId == null) {
                return;
            }
            Store.Bot b = Store.load(BotService.this, botId);
            if (b != null) {
                try {
                    ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(
                            100 + slot, notification(b.name, Store.shortStatus(BotService.this, b)));
                } catch (Exception ignored) {
                    // no es critico
                }
            }
            main.postDelayed(this, 15000);
        }
    };

    // ---------- API estatica para la UI ----------

    static void start(Context c, Store.Bot b) {
        Intent i = new Intent(c, SLOTS[b.slot]).setAction(A_START).putExtra("id", b.id);
        if (Build.VERSION.SDK_INT >= 26) {
            c.startForegroundService(i);
        } else {
            c.startService(i);
        }
    }

    static void stop(Context c, Store.Bot b) {
        c.startService(new Intent(c, SLOTS[b.slot]).setAction(A_STOP));
    }

    // ---------- ciclo de vida ----------

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        String n = getClass().getSimpleName(); // "S0".."S3"
        slot = (n.length() == 2 && Character.isDigit(n.charAt(1))) ? n.charAt(1) - '0' : 0;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? A_START : intent.getAction();

        if (A_STOP.equals(action)) {
            if (worker == null) {
                // Este proceso se creo solo para recibir "detener": limpiar y salir.
                Store.slotFile(this, slot).delete();
                stopSelf();
                killLater();
            } else {
                shutdown();
            }
            return START_NOT_STICKY;
        }

        // Toda orden de inicio debe llamar a startForeground rapido.
        if (intent != null && intent.getStringExtra("id") != null) {
            botId = intent.getStringExtra("id");
        }
        if (botId == null) {
            // Reinicio automatico del sistema (intent nulo): recuperar el bot del slot.
            String s = Store.readText(Store.slotFile(this, slot)).trim();
            botId = s.isEmpty() ? null : s;
        }
        Store.Bot bot = botId == null ? null : Store.load(this, botId);
        startFg(notification(bot == null ? "Bot Host" : bot.name,
                bot == null ? "Sin bot asignado" : "En ejecución"));

        if (down.get()) {
            return START_NOT_STICKY; // se esta apagando; la UI reintenta
        }
        if (bot == null) {
            shutdown();
            return START_NOT_STICKY;
        }

        Store.writeText(Store.slotFile(this, slot), bot.id); // marca "iniciando"
        acquireLocks();
        if (worker == null) {
            startWorker(bot);
        }
        main.removeCallbacks(notifTick);
        main.postDelayed(notifTick, 8000);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(notifTick);
        releaseLocks();
        super.onDestroy();
    }

    // ---------- trabajo ----------

    private void startWorker(final Store.Bot bot) {
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    startPython();
                    Python.getInstance().getModule("host")
                            .callAttr("run", Store.dir(BotService.this, bot.id).getAbsolutePath());
                } catch (Throwable t) {
                    Store.appendLog(BotService.this, bot.id, "[host] error fatal: " + t);
                }
                shutdown();
            }
        }, "bot-runner");
        worker.start();
    }

    /** Arranca Python con un candado entre procesos para que no choquen al extraer archivos. */
    private void startPython() throws Exception {
        RandomAccessFile raf = new RandomAccessFile(new File(getFilesDir(), "py.lock"), "rw");
        FileChannel ch = raf.getChannel();
        FileLock lock = ch.lock();
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(getApplicationContext()));
            }
            Python.getInstance().getModule("host").callAttr("warmup");
        } finally {
            lock.release();
            ch.close();
            raf.close();
        }
    }

    private void shutdown() {
        if (!down.compareAndSet(false, true)) {
            return;
        }
        main.removeCallbacks(notifTick);
        final String id = botId;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (Python.isStarted()) {
                        Python.getInstance().getModule("host").callAttr("stop");
                    }
                } catch (Throwable ignored) {
                    // se mata el proceso de todos modos
                }
                if (id != null) {
                    Store.heartbeatFile(BotService.this, id).delete();
                }
                Store.slotFile(BotService.this, slot).delete();
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        stopForeground(true);
                        stopSelf();
                        killLater();
                    }
                });
            }
        }, "bot-stop").start();
    }

    private void killLater() {
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                Process.killProcess(Process.myPid());
            }
        }, 300);
    }

    // ---------- notificacion y bloqueos ----------

    private void startFg(Notification n) {
        int nid = 100 + slot;
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(nid, n);
        }
    }

    private Notification notification(String title, String text) {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "Bots en ejecución", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, BotActivity.class).putExtra("id", botId);
        PendingIntent pOpen = PendingIntent.getActivity(this, slot, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pStop = PendingIntent.getService(this, 10 + slot,
                new Intent(this, SLOTS[slot]).setAction(A_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pOpen)
                .addAction(0, "Detener", pStop);
        return b.build();
    }

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (wake == null) {
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bothost:cpu" + slot);
                wake.setReferenceCounted(false);
            }
            if (!wake.isHeld()) {
                wake.acquire();
            }
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm != null) {
                if (wifi == null) {
                    wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "bothost:wifi" + slot);
                    wifi.setReferenceCounted(false);
                }
                if (!wifi.isHeld()) {
                    wifi.acquire();
                }
            }
        } catch (Exception ignored) {
            // el bot sigue funcionando sin los bloqueos
        }
    }

    private void releaseLocks() {
        try {
            if (wake != null && wake.isHeld()) {
                wake.release();
            }
            if (wifi != null && wifi.isHeld()) {
                wifi.release();
            }
        } catch (Exception ignored) {
            // nada
        }
    }
}
