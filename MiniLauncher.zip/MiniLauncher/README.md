# Mini Launcher

Launcher ultraligero (Java puro, sin librerías) para Android 8.0+.

## Compilar el APK con GitHub
1. Crea un repositorio nuevo y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** → **Build APK** → **Run workflow** (también corre solo con cada push).
3. Cuando termine, descarga el artefacto **MiniLauncher-apk** y descomprímelo para obtener el `.apk`.

## Instalar y usarlo
1. Instala el APK (permite "instalar apps desconocidas" si te lo pide).
2. Ajustes → Aplicaciones → Elegir apps predeterminadas → **App de inicio** → Mini Launcher.

## Uso
- Toca una app para abrirla. Mantén pulsado para ver info o desinstalar.
- Escribe en el buscador y pulsa "Ir" para abrir el primer resultado.
