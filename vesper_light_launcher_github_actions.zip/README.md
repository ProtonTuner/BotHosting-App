# Vesper Light Launcher

Launcher Android independiente y ligero, diseñado como punto de partida para Samsung Galaxy A12 / Android 12.

## Incluye
- Pantalla de inicio configurable como launcher predeterminado de Android.
- Reloj y fecha al abrir la pantalla.
- Búsqueda local de aplicaciones instaladas y cuadrícula de iconos.
- Mantener pulsada una aplicación para abrirla o ir a su información.
- Sin servicios en segundo plano, anuncios, cuentas ni permisos de red.
- Interfaz oscura con acento violeta; implementación nativa sin bibliotecas de UI adicionales.

## Compilar
Abrir la carpeta en Android Studio con JDK 17 y Android SDK Platform 35 instalado. Sin wrapper incluido, Android Studio puede importar el proyecto y sincronizar Gradle. Generar un APK desde **Build > Build APK(s)**.

## Convertirlo en launcher predeterminado
Instalar el APK y pulsar Inicio. Android debería ofrecer elegir **Vesper Light** como aplicación de inicio; también se puede elegir desde Ajustes > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio (los nombres pueden variar según la versión de One UI).

## Limitaciones de esta entrega
Este ZIP contiene el proyecto fuente, no un APK compilado. No se ha compilado ni probado en un Galaxy A12 físico. La fecha y la hora se actualizan al recrear la pantalla; no se mantiene un servicio de reloj en segundo plano. Es una base ligera inicial, no un reemplazo completo de One UI: no incluye widgets, gestos avanzados, fondos configurables ni gestión de páginas.

## GitHub Actions: compilar el APK automáticamente

El archivo `.github/workflows/android.yml` configura una compilación en GitHub Actions.

1. Sube el contenido de esta carpeta a un repositorio de GitHub, conservando la carpeta `.github/workflows/`.
2. Abre la pestaña **Actions** y permite los workflows si GitHub lo solicita.
3. Cada push a `main` o `master`, cada pull request hacia esas ramas y la ejecución manual desde **Actions > Build Vesper Light Launcher > Run workflow** compilarán el proyecto.
4. Al terminar, abre la ejecución del workflow y descarga el artefacto **vesper-light-apk**. Contiene `VesperLight-debug.apk` y `SHA256SUMS.txt`.
5. Para publicar una Release, crea y sube una etiqueta, por ejemplo:

   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```

   El workflow compilará el APK y adjuntará el APK de depuración y su checksum a la GitHub Release.

**Importante:** este workflow automatiza la compilación; no demuestra que la app funcione correctamente en un Galaxy A12 físico. El artefacto generado es un APK `debug`, no una compilación `release` firmada para distribución. Antes de distribuir ampliamente, conviene configurar firma de release con un keystore guardado como GitHub Secrets y probar la app en el dispositivo.
