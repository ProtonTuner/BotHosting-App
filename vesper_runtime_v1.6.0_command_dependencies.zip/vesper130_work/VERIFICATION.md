# Verification — Vesper Runtime 1.6.0

- Source ZIP integrity is checked before delivery.
- Repository-level tests remain in `tests/` for CI; they are outside `app/src/main`, so Android Gradle does not package them as app assets.
- Python dependencies are bundled by Chaquopy from `app/requirements.txt` during APK build.
- Startup command parser accepts only `python filename.py` or `python3 filename.py`; shell syntax and paths are rejected.
- An actual Gradle APK build and on-device test have not been run in this environment. Run the included GitHub Actions workflow to verify Chaquopy package compatibility and compilation.
