"""Project management helpers for Vesper BotHost.

Projects and secrets are kept inside the app-private files directory. This is an
organizer, not a security sandbox: bot code executes with the app process's
permissions. Secret values are never returned by the public JSON helpers.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
PROJECT_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$")
SECRET_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")
MAX_SECRET_LENGTH = 512

BOT_TEMPLATE = '''"""A starter Discord bot for Vesper BotHost 10.0.

1. Open Bot settings in Vesper and set DISCORD_TOKEN.
2. Invite the bot to your server with the required scopes/permissions.
3. Start the bot and watch the Logs screen.

Uses slash commands, so Message Content Intent is not required by this template.
"""
import os
import discord
from discord import app_commands

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
if not TOKEN:
    raise RuntimeError(
        "DISCORD_TOKEN is not configured. Open Vesper BotHost > Bots > Settings."
    )

intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


@client.event
async def on_ready():
    print(f"Connected to Discord as {client.user} (ID: {client.user.id})")
    try:
        synced = await tree.sync()
        print(f"Slash commands synchronized: {len(synced)}")
    except Exception as exc:
        print(f"Slash command sync failed: {type(exc).__name__}: {exc}")


@tree.command(name="ping", description="Check whether this bot is responding")
async def ping(interaction: discord.Interaction):
    latency_ms = round(client.latency * 1000)
    await interaction.response.send_message(f"Pong! {latency_ms} ms", ephemeral=True)


if __name__ == "__main__":
    client.run(TOKEN, log_handler=None, reconnect=True)
'''

DEFAULT_FILES = {
    "bot.py": BOT_TEMPLATE,
    "requirements.txt": "# Dependencies are bundled into Vesper's APK at build time.\ndiscord.py==2.7.1\naiohttp==3.9.1\nyarl==1.9.3\nmultidict==5.1.0\nfrozenlist==1.4.0\n",
    ".env.example": "# Configure the real token in Bot settings; do not commit it.\nDISCORD_TOKEN=replace_me_in_app_settings\n",
    ".gitignore": ".env\n__pycache__/\n*.py[cod]\n.venv/\nvenv/\n",
    "README.md": """# Discord bot project\n\nThis project was created by Vesper BotHost 10.0. Configure `DISCORD_TOKEN`\nfrom the in-app Bot settings screen. The token is stored in this app's private\nworkspace in `.env`; it is not included in exports created by this template.\n\nThe starter uses a slash `/ping` command and does not request Message Content\nIntent. Invite the bot with the `bot` and `applications.commands` scopes.\n\nImportant: Vesper runs the bot on this Android device. Android may stop a process\nunder system or battery pressure; this is not guaranteed 24/7 cloud hosting.\n""",
}


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except (OSError, RuntimeError, ValueError):
        return False


def _safe_project_dir(workspace: str | os.PathLike[str], project_id: str) -> Path:
    if not isinstance(project_id, str) or not PROJECT_NAME_RE.fullmatch(project_id):
        raise ValueError("Invalid project ID.")
    root = Path(workspace).resolve()
    target = (root / project_id).resolve()
    if target.parent != root or not _inside(target, root):
        raise ValueError("Project path escapes the BotHost workspace.")
    return target


def _atomic_write(path: Path, contents: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".vesper-", dir=str(path.parent), text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(contents)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
        try:
            path.chmod(0o600)
        except OSError:
            pass
    except BaseException:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def create_project_json(workspace: str, project_id: str) -> str:
    """Create a complete starter project; fail rather than overwrite anything."""
    root = Path(workspace).resolve()
    root.mkdir(parents=True, exist_ok=True)
    target = _safe_project_dir(str(root), project_id)
    if target.exists():
        return json.dumps({"ok": False, "error": "A bot with that name already exists."})
    staging = Path(tempfile.mkdtemp(prefix=".new-bot-", dir=str(root)))
    try:
        for name, contents in DEFAULT_FILES.items():
            _atomic_write(staging / name, contents)
        config = {
            "schema_version": SCHEMA_VERSION,
            "id": project_id,
            "display_name": project_id.replace("_", " ").replace("-", " ").title(),
            "platform": "discord",
            "entrypoint": "bot.py",
            "created_at": int(time.time()),
            "auto_restart": False,
        }
        _atomic_write(staging / "vesper-bot.json", json.dumps(config, indent=2) + "\n")
        staging.rename(target)
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return json.dumps({"ok": True, "id": project_id, "path": str(target), "entrypoint": "bot.py"})


def _read_config(project_dir: Path) -> dict[str, Any]:
    config_path = project_dir / "vesper-bot.json"
    if config_path.is_file() and config_path.stat().st_size <= 16_384:
        with config_path.open("r", encoding="utf-8") as stream:
            config = json.load(stream)
        if not isinstance(config, dict):
            raise ValueError("Bot configuration must be a JSON object.")
    else:
        config = {
            "schema_version": SCHEMA_VERSION,
            "id": project_dir.name,
            "display_name": project_dir.name,
            "platform": "discord",
            "entrypoint": "bot.py",
            "auto_restart": False,
        }
    entrypoint = config.get("entrypoint", "bot.py")
    if not isinstance(entrypoint, str) or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_-]{0,39}\.py", entrypoint, re.I):
        raise ValueError("Invalid bot entrypoint in metadata.")
    return config


def list_projects_json(workspace: str) -> str:
    """Return metadata and status-safe booleans only; never reveal .env values."""
    root = Path(workspace).resolve()
    root.mkdir(parents=True, exist_ok=True)
    projects = []
    errors = []
    for directory in sorted(root.iterdir(), key=lambda p: p.name.casefold()):
        if not directory.is_dir() or directory.name.startswith(".") or not _inside(directory, root):
            continue
        if not PROJECT_NAME_RE.fullmatch(directory.name):
            continue
        try:
            config = _read_config(directory)
            entrypoint = config["entrypoint"]
            entry_file = (directory / entrypoint).resolve()
            if entry_file.parent != directory.resolve() or not entry_file.is_file():
                entrypoint_exists = False
            else:
                entrypoint_exists = True
            env_file = directory / ".env"
            projects.append({
                "id": directory.name,
                "display_name": str(config.get("display_name") or directory.name)[:80],
                "entrypoint": entrypoint,
                "entrypoint_exists": entrypoint_exists,
                "token_configured": _has_env_key(env_file, "DISCORD_TOKEN"),
                "auto_restart": bool(config.get("auto_restart", False)),
                "size_bytes": _directory_size(directory),
                "valid": entrypoint_exists,
            })
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            errors.append({"id": directory.name, "error": str(exc)[:200]})
    return json.dumps({"projects": projects, "errors": errors}, ensure_ascii=False)


def _directory_size(directory: Path) -> int:
    total = 0
    try:
        for path in directory.rglob("*"):
            if path.is_file() and not path.is_symlink():
                total += path.stat().st_size
    except OSError:
        pass
    return total


def parse_dotenv_text(contents: str) -> dict[str, str]:
    """Parse a conservative .env subset, with no shell expansion or execution."""
    if not isinstance(contents, str):
        raise TypeError("Environment content must be text.")
    if len(contents.encode("utf-8")) > 64 * 1024:
        raise ValueError(".env is larger than 64 KiB.")
    parsed: dict[str, str] = {}
    for number, raw in enumerate(contents.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            raise ValueError(f"Invalid environment entry on line {number}.")
        key, value = line.split("=", 1)
        key = key.strip()
        if not SECRET_KEY_RE.fullmatch(key):
            raise ValueError(f"Invalid environment variable name on line {number}.")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            quote = value[0]
            if quote == '"':
                # BotHost writes JSON-escaped double-quoted values. Decode those
                # with the JSON parser first so tabs, Unicode and backslashes round-trip.
                try:
                    decoded = json.loads(value)
                    value = decoded if isinstance(decoded, str) else value[1:-1]
                except (json.JSONDecodeError, TypeError):
                    value = value[1:-1].replace("\\n", "\n").replace("\\r", "\r").replace('\\"', '"').replace("\\\\", "\\")
            else:
                value = value[1:-1]
        else:
            value = re.split(r"\s+#", value, maxsplit=1)[0].rstrip()
        if "\x00" in value:
            raise ValueError(f"Invalid null byte in environment value on line {number}.")
        parsed[key] = value
    return parsed


def _read_dotenv(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    if not path.is_file() or path.stat().st_size > 64 * 1024:
        raise ValueError("Bot .env file is not a normal file or exceeds 64 KiB.")
    return parse_dotenv_text(path.read_text(encoding="utf-8"))


def _has_env_key(path: Path, key: str) -> bool:
    try:
        return bool(_read_dotenv(path).get(key, "").strip())
    except (OSError, ValueError, UnicodeError):
        return False


def set_discord_token_json(workspace: str, project_id: str, token: str) -> str:
    """Save a token privately and return only configured=true; no token echoes."""
    directory = _safe_project_dir(workspace, project_id)
    if not directory.is_dir() or not (directory / "vesper-bot.json").is_file():
        raise ValueError("Bot project was not found in the BotHost workspace.")
    if not isinstance(token, str):
        raise TypeError("Token must be text.")
    token = token.strip()
    if not token or len(token) > MAX_SECRET_LENGTH or any(ch in token for ch in "\r\n\x00"):
        raise ValueError("Enter a valid token value (1–512 characters, on one line).")
    path = directory / ".env"
    values = _read_dotenv(path)
    values["DISCORD_TOKEN"] = token
    content = "# Private BotHost environment; do not export or share.\n" + "".join(
        f"{key}={json.dumps(value, ensure_ascii=False)}\n" for key, value in sorted(values.items())
    )
    _atomic_write(path, content)
    return json.dumps({"ok": True, "token_configured": True})


def set_project_metadata_json(workspace: str, project_id: str, display_name: str, entrypoint: str) -> str:
    """Update non-secret project metadata with strict entrypoint validation."""
    directory = _safe_project_dir(workspace, project_id)
    if not directory.is_dir():
        raise ValueError("Bot project was not found.")
    if not isinstance(display_name, str) or not display_name.strip() or len(display_name.strip()) > 80:
        raise ValueError("Display name must contain 1–80 characters.")
    if not isinstance(entrypoint, str) or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_-]{0,39}\.py", entrypoint, re.I):
        raise ValueError("Entry point must be a simple .py filename in the bot root.")
    target = (directory / entrypoint).resolve()
    if target.parent != directory.resolve() or not target.is_file():
        raise ValueError("Entry point was not found in the bot root.")
    config = _read_config(directory)
    config.update({"schema_version": SCHEMA_VERSION, "id": project_id, "platform": "discord", "display_name": display_name.strip(), "entrypoint": entrypoint})
    _atomic_write(directory / "vesper-bot.json", json.dumps(config, indent=2, ensure_ascii=False) + "\n")
    return json.dumps({"ok": True, "display_name": display_name.strip(), "entrypoint": entrypoint})


def register_imported_project_json(workspace: str, project_id: str, display_name: str, entrypoint: str) -> str:
    """Register an already extracted, app-private project folder without overwrites."""
    directory = _safe_project_dir(workspace, project_id)
    if not directory.is_dir():
        raise ValueError("Imported project folder is missing.")
    if (directory / "vesper-bot.json").exists():
        return json.dumps({"ok": True, "id": project_id})
    if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_-]{0,39}\.py", entrypoint, re.I):
        raise ValueError("A root-level .py entrypoint is required.")
    script = (directory / entrypoint).resolve()
    if script.parent != directory.resolve() or not script.is_file():
        raise ValueError("Imported bot entrypoint was not found in the project root.")
    config = {"schema_version": SCHEMA_VERSION, "id": project_id, "display_name": display_name[:80] or project_id, "platform": "discord", "entrypoint": entrypoint, "created_at": int(time.time()), "auto_restart": False}
    _atomic_write(directory / "vesper-bot.json", json.dumps(config, indent=2, ensure_ascii=False) + "\n")
    if not (directory / "requirements.txt").exists():
        _atomic_write(directory / "requirements.txt", "# Dependencies must be bundled into Vesper's APK at build time.\ndiscord.py==2.7.1\n")
    if not (directory / ".env.example").exists():
        _atomic_write(directory / ".env.example", "DISCORD_TOKEN=configure_in_v_host_settings\n")
    return json.dumps({"ok": True, "id": project_id, "entrypoint": entrypoint})


def delete_project_json(workspace: str, project_id: str) -> str:
    """Delete only one validated project folder; caller must confirm with the user."""
    directory = _safe_project_dir(workspace, project_id)
    if not directory.is_dir() or not (directory / "vesper-bot.json").is_file():
        raise ValueError("Bot project was not found.")
    shutil.rmtree(directory)
    return json.dumps({"ok": True, "id": project_id})


def clear_discord_token_json(workspace: str, project_id: str) -> str:
    """Remove only DISCORD_TOKEN while preserving other project variables."""
    directory = _safe_project_dir(workspace, project_id)
    if not directory.is_dir() or not (directory / "vesper-bot.json").is_file():
        raise ValueError("Bot project was not found in the BotHost workspace.")
    path = directory / ".env"
    values = _read_dotenv(path)
    values.pop("DISCORD_TOKEN", None)
    if values:
        content = "# Private BotHost environment; do not export or share.\n" + "".join(
            f"{key}={json.dumps(value, ensure_ascii=False)}\n" for key, value in sorted(values.items())
        )
        _atomic_write(path, content)
    else:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    return json.dumps({"ok": True, "token_configured": False})
