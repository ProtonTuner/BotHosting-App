package com.vesper.runtime

import android.app.Activity
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.StatFs
import android.app.ActivityManager
import android.graphics.Color
import android.content.pm.PackageManager
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.InputFilter
import org.json.JSONObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var console: TextView
    private lateinit var status: TextView
    private lateinit var currentFileLabel: TextView
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private lateinit var projectsDir: File
    private lateinit var requirementsFile: File
    private var currentFile: File? = null
    private var running = false // Accessed only on the main thread.
    private var receiverRegistered = false
    private var runtimeUiInitialized = false
    private var pendingProjectExportName: String? = null
    private var pendingProjectExportText: String? = null
    private var lastLogBytesRead = 0L
    private val exportRequirementsRequestCode = 4307
    private val importProjectRequestCode = 4308
    private val importFilesRequestCode = 4311
    private val exportProjectRequestCode = 4309
    private val notificationPermissionRequestCode = 4310
    private val maxImportedProjectBytes = 1_000_000
    private val maxImportedArchiveBytes = 20 * 1024 * 1024
    private val maxArchiveEntries = 500

    private val runtimeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                RuntimeService.ACTION_STATE -> {
                    status.text = intent.getStringExtra(RuntimeService.EXTRA_STATUS) ?: "Status: READY"
                    running = intent.getBooleanExtra(RuntimeService.EXTRA_RUNNING, false)
                    runButton.isEnabled = !running
                    stopButton.isEnabled = running
                }
                RuntimeService.ACTION_OUTPUT -> {
                    val outputText = intent.getStringExtra(RuntimeService.EXTRA_OUTPUT) ?: "(no output)"
                    val startOffset = intent.getLongExtra(RuntimeService.EXTRA_OUTPUT_START_OFFSET, -1L)
                    val endOffset = intent.getLongExtra(RuntimeService.EXTRA_OUTPUT_OFFSET, -1L)
                    if (startOffset < 0L || endOffset < 0L) {
                        appendConsoleRaw(outputText)
                        return
                    }
                    // Log catch-up and live broadcasts can race while this Activity returns
                    // to the foreground. Byte offsets prevent duplicate console chunks.
                    if (endOffset <= lastLogBytesRead) return
                    if (startOffset > lastLogBytesRead) appendMissedRunningOutput(startOffset)
                    var chunkToAppend = outputText
                    if (startOffset < lastLogBytesRead) {
                        val bytes = outputText.toByteArray(Charsets.UTF_8)
                        val skipBytes = (lastLogBytesRead - startOffset).coerceAtMost(bytes.size.toLong()).toInt()
                        if (skipBytes >= bytes.size) {
                            lastLogBytesRead = maxOf(lastLogBytesRead, endOffset)
                            return
                        }
                        chunkToAppend = String(bytes.copyOfRange(skipBytes, bytes.size), Charsets.UTF_8)
                    }
                    appendConsoleRaw(chunkToAppend)
                    lastLogBytesRead = maxOf(lastLogBytesRead, endOffset)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        } catch (e: Exception) {
            showFatalRuntimeError("Python could not start: ${e.message ?: e.javaClass.simpleName}")
            return
        }

        projectsDir = File(filesDir, "projects").apply { mkdirs() }
        requirementsFile = File(filesDir, "requirements.txt")
        if (!requirementsFile.exists()) {
            try {
                assets.open("requirements.txt").use { input -> requirementsFile.writeBytes(input.readBytes()) }
            } catch (e: Exception) {
                requirementsFile.writeText("# Vesper Runtime Python dependencies\n")
            }
        }
        val starter = File(projectsDir, "main.py")
        if (!starter.exists()) {
            try {
                assets.open("main.py").use { input -> starter.writeBytes(input.readBytes()) }
            } catch (e: Exception) {
                starter.writeText("print('Vesper Runtime is ready.')\n")
            }
        }
        currentFile = starter

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(12, 16, 27))
        }
        // Edge-to-edge insets keep the redesigned dashboard usable around system bars.
        ViewCompat.setOnApplyWindowInsetsListener(page) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(dp(16) + bars.left, dp(12) + bars.top, dp(16) + bars.right, dp(12) + bars.bottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(14))
        }
        val brandBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandBlock.addView(TextView(this).apply {
            text = "VESPER"
            textSize = 25f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(241, 239, 255))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, wrapMatch())
        brandBlock.addView(TextView(this).apply {
            text = "RUNTIME  •  LOCAL HOSTING"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(151, 163, 190))
        }, wrapMatch())
        header.addView(brandBlock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(makeButton("HOSTING PANEL") { showHostingPanel() }.apply { styleButton(this, accent = true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        page.addView(header, wrapMatch())

        val scroll = ScrollView(this).apply { isFillViewport = false; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        content.addView(sectionHeading("SERVER OVERVIEW", "Your Android device is the host"), wrapMatch())
        val statusCard = dashboardCard()
        val statusRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 20f
            setTextColor(Color.rgb(57, 217, 138))
            setPadding(0, 0, dp(10), 0)
        }
        statusRow.addView(statusDot, wrapMatch())
        val statusColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusColumn.addView(TextView(this).apply {
            text = "ENGINE STATUS"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(151, 163, 190))
        }, wrapMatch())
        status = TextView(this).apply {
            text = "STOPPED · READY"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(57, 217, 138))
            setPadding(0, dp(3), 0, 0)
        }
        statusColumn.addView(status, wrapMatch())
        statusRow.addView(statusColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        statusCard.addView(statusRow, wrapMatch())
        val overviewButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        runButton = makeButton("START SERVER") { runScript() }.apply { styleButton(this, accent = true) }
        stopButton = makeButton("STOP SERVER") { stopScript() }.apply { styleButton(this, accent = false); isEnabled = false }
        overviewButtons.addView(runButton, weightedButton())
        overviewButtons.addView(stopButton, weightedButton())
        statusCard.addView(overviewButtons, wrapMatch())
        content.addView(statusCard, sectionParams())

        content.addView(sectionHeading("QUICK ACCESS", "Manage your projects and runtime"), wrapMatch())
        val quickGridTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quickGridTop.addView(makeButton("PROJECTS") { showProjects() }.apply { styleButton(this) }, weightedButton())
        quickGridTop.addView(makeButton("NEW PROJECT") { createProjectDialog() }.apply { styleButton(this) }, weightedButton())
        quickGridTop.addView(makeButton("STARTUP SCRIPT") { chooseStartupScript() }.apply { styleButton(this) }, weightedButton())
        content.addView(quickGridTop, sectionParams())

        currentFileLabel = TextView(this).apply {
            text = "WORKSPACE  /  main.py"
            textSize = 12f
            letterSpacing = 0.04f
            setTextColor(Color.rgb(178, 190, 218))
            setPadding(dp(2), dp(8), dp(2), dp(8))
        }
        content.addView(currentFileLabel, wrapMatch())
        val editorCard = dashboardCard()
        val editorHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        editorHeader.addView(TextView(this).apply {
            text = "Code editor"
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        editorHeader.addView(makeButton("SAVE") { saveCurrentProject(showToast = true) }.apply { styleButton(this, accent = true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        editorCard.addView(editorHeader, wrapMatch())
        editor = EditText(this).apply {
            setText(starter.readText())
            setTextColor(Color.rgb(218, 225, 244))
            setHintTextColor(Color.rgb(125, 136, 161))
            hint = "# Your Python script\nprint('Vesper is ready')"
            textSize = 13f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundColor(Color.rgb(10, 13, 22))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            minLines = 8
        }
        val editorParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210))
        editorParams.topMargin = dp(10)
        editorCard.addView(editor, editorParams)
        content.addView(editorCard, sectionParams())

        content.addView(sectionHeading("FILES & DEPENDENCIES", "Import projects, edit files and manage packages"), wrapMatch())
        val filesCard = dashboardCard()
        addActionRow(filesCard, "Import ZIP / files", "Bring an existing bot or Python project", "IMPORT") { importAnyFile() }
        addActionRow(filesCard, "Import Python file", "Add a .py script to your workspace", "IMPORT .PY") { importProject() }
        addActionRow(filesCard, "Imported files", "Browse files extracted from archives", "BROWSE") { showImportedFiles() }
        addActionRow(filesCard, "Dependencies", "Review Python packages and requirements", "MANAGE") { showDependencyManager() }
        val exportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exportRow.addView(makeButton("EXPORT .PY") { exportCurrentProject() }.apply { styleButton(this) }, weightedButton())
        exportRow.addView(makeButton("EXPORT REQ.") { exportRequirements() }.apply { styleButton(this) }, weightedButton())
        filesCard.addView(exportRow, wrapMatch())
        content.addView(filesCard, sectionParams())

        content.addView(sectionHeading("CONSOLE", "Live process output and diagnostics"), wrapMatch())
        val consoleCard = dashboardCard()
        val consoleTools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        consoleTools.addView(TextView(this).apply {
            text = "TERMINAL OUTPUT"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(151, 163, 190))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        consoleTools.addView(makeButton("CLEAR") { console.text = "Console cleared.\n" }.apply { styleButton(this) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        consoleCard.addView(consoleTools, wrapMatch())
        console = TextView(this).apply {
            text = "Vesper Runtime ready.\nImport or create a project, then start the server.\n"
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(Color.rgb(163, 236, 194))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(6, 9, 15))
            setTextIsSelectable(true)
        }
        val consoleParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
        consoleParams.topMargin = dp(10)
        consoleCard.addView(ScrollView(this).apply { addView(console) }, consoleParams)
        content.addView(consoleCard, sectionParams())

        page.addView(TextView(this).apply {
            text = "VESPER RUNTIME 1.4  •  LOCAL DEVICE HOSTING"
            textSize = 10f
            letterSpacing = 0.05f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(111, 124, 150))
            setPadding(0, dp(8), 0, dp(2))
        }, wrapMatch())
        setContentView(page)
        runtimeUiInitialized = true
        syncRuntimeState()
    }

    override fun onStart() {
        super.onStart()
        // Python initialization can fail before the UI is constructed. The fatal-error
        // dialog is still shown, but lifecycle callbacks must not touch lateinit views.
        if (!runtimeUiInitialized) return
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(RuntimeService.ACTION_STATE)
                addAction(RuntimeService.ACTION_OUTPUT)
            }
            ContextCompat.registerReceiver(this, runtimeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        syncRuntimeState()
        if (running) appendMissedRunningOutput()
        // Ask the service to confirm state so a stale persisted RUNNING flag cannot
        // leave the controls disabled if Android killed the process.
        try {
            startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_QUERY))
        } catch (_: Exception) {
            // The UI still reflects the most recent persisted state if querying fails.
        }
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(runtimeReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun syncRuntimeState() {
        val prefs = getSharedPreferences(RuntimeService.PREFS_NAME, MODE_PRIVATE)
        status.text = prefs.getString(RuntimeService.KEY_STATUS, "Status: READY")
        running = prefs.getBoolean(RuntimeService.KEY_RUNNING, false)
        runButton.isEnabled = !running
        stopButton.isEnabled = running
        val lastOutput = prefs.getString(RuntimeService.KEY_LAST_OUTPUT, "").orEmpty()
        if (lastOutput.isNotBlank() && console.text.toString().trim() == "Ready. Open or create a Python project, then run it.") {
            appendConsole(lastOutput)
        }
    }

    private fun appendMissedRunningOutput(untilOffset: Long? = null) {
        val logFile = File(filesDir, "runtime-output.log")
        if (!logFile.isFile) return
        try {
            RandomAccessFile(logFile, "r").use { stream ->
                val targetOffset = minOf(untilOffset ?: stream.length(), stream.length())
                while (lastLogBytesRead < targetOffset) {
                    stream.seek(lastLogBytesRead)
                    val remaining = (targetOffset - lastLogBytesRead).coerceAtMost(256_000L).toInt()
                    val bytes = ByteArray(remaining)
                    val count = stream.read(bytes)
                    if (count <= 0) break
                    appendConsoleRaw(String(bytes, 0, count, Charsets.UTF_8))
                    lastLogBytesRead += count
                }
            }
        } catch (e: Exception) {
            appendConsole("Could not restore recent output: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun sectionHeading(title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(2), dp(7), dp(2), dp(10))
        addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 11f
            letterSpacing = 0.12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(144, 157, 185))
        }, wrapMatch())
        addView(TextView(this@MainActivity).apply {
            text = subtitle
            textSize = 12f
            setTextColor(Color.rgb(103, 117, 145))
            setPadding(0, dp(3), 0, 0)
        }, wrapMatch())
    }

    private fun dashboardCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(22, 28, 43))
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.rgb(42, 52, 75))
        }
    }

    private fun sectionParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(14) }

    private fun styleButton(button: Button, accent: Boolean = false) {
        button.textSize = 10f
        button.isAllCaps = false
        button.setTextColor(if (accent) Color.rgb(9, 19, 28) else Color.rgb(218, 226, 246))
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (accent) Color.rgb(106, 226, 188) else Color.rgb(39, 49, 71)
        )
        button.setPadding(dp(8), dp(3), dp(8), dp(3))
        button.minHeight = dp(38)
        button.minimumHeight = dp(38)
    }

    private fun addActionRow(parent: LinearLayout, title: String, subtitle: String, actionLabel: String, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.rgb(230, 235, 249))
        }, wrapMatch())
        labels.addView(TextView(this).apply {
            text = subtitle
            textSize = 10f
            setTextColor(Color.rgb(132, 146, 174))
            setPadding(0, dp(2), 0, 0)
        }, wrapMatch())
        row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(makeButton(actionLabel, action).apply { styleButton(this) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        parent.addView(row, wrapMatch())
        val divider = android.view.View(this).apply { setBackgroundColor(Color.rgb(39, 48, 68)) }
        parent.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setOnClickListener { action() }
    }

    private fun weightedButton() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    /** Wispbyte-inspired local hosting dashboard. Python jobs still run on this phone. */
    private fun showHostingPanel() {
        val scripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        val prefs = getSharedPreferences("vesper_hosting", MODE_PRIVATE)
        val startup = prefs.getString("startup_script", "main.py") ?: "main.py"
        val stat = StatFs(filesDir.absolutePath)
        val freeMb = stat.availableBytes / (1024 * 1024)
        val totalMb = stat.totalBytes / (1024 * 1024)
        val memory = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        memory.getMemoryInfo(memInfo)
        val runningText = if (running) "RUNNING" else "STOPPED"
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(4))
        }
        val autoRestart = prefs.getBoolean(RuntimeService.KEY_AUTO_RESTART, false)
        panel.addView(TextView(this).apply {
            text = "Local engine: $runningText\nStartup script: $startup\nPython projects: ${scripts.size}\nApp storage free: ${freeMb} MB / ${totalMb} MB\nDevice RAM available: ${memInfo.availMem / (1024 * 1024)} MB\nUnexpected-kill recovery: ${if (autoRestart) "ON" else "OFF"}\n\nRuns on this Android device. Recovery is best-effort; Android and device vendors can still restrict services."
            textSize = 14f
        })
        panel.addView(makeButton(if (autoRestart) "AUTO-RESTART: ON (TAP TO DISABLE)" else "AUTO-RESTART: OFF (TAP TO ENABLE)") {
            prefs.edit().putBoolean(RuntimeService.KEY_AUTO_RESTART, !autoRestart).apply()
            Toast.makeText(this, if (!autoRestart) "Unexpected-kill recovery enabled" else "Unexpected-kill recovery disabled", Toast.LENGTH_SHORT).show()
            showHostingPanel()
        })
        panel.addView(makeButton("BATTERY / BACKGROUND SETTINGS") {
            openBackgroundSettings()
        })
        AlertDialog.Builder(this)
            .setTitle("VESPER HOSTING PANEL")
            .setView(panel)
            .setPositiveButton(if (running) "STOP ENGINE" else "START STARTUP") { _, _ ->
                if (running) {
                    stopScript()
                } else {
                    val chosen = scripts.firstOrNull { it.name == startup }
                        ?: scripts.firstOrNull { it.name == "main.py" }
                        ?: scripts.firstOrNull()
                    if (chosen == null) {
                        Toast.makeText(this, "Import or create a .py project first", Toast.LENGTH_LONG).show()
                    } else {
                        openProject(chosen)
                        runScript()
                    }
                }
            }
            .setNeutralButton("SELECT STARTUP") { _, _ -> chooseStartupScript() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun openBackgroundSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            } else {
                Intent(android.provider.Settings.ACTION_SETTINGS)
            }
            startActivity(intent)
        } catch (e: Exception) {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            catch (_: Exception) {
                Toast.makeText(this, "Open Android Settings and review Vesper Runtime battery/background restrictions.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun chooseStartupScript() {
        val scripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        if (scripts.isEmpty()) {
            Toast.makeText(this, "Create or import a Python script first", Toast.LENGTH_SHORT).show()
            return
        }
        val current = getSharedPreferences("vesper_hosting", MODE_PRIVATE).getString("startup_script", "main.py")
        AlertDialog.Builder(this)
            .setTitle("Choose startup script")
            .setSingleChoiceItems(scripts.map { if (it.name == current) "✓ ${it.name}" else it.name }.toTypedArray(),
                scripts.indexOfFirst { it.name == current }.coerceAtLeast(-1)) { dialog, which ->
                val selected = scripts[which]
                getSharedPreferences("vesper_hosting", MODE_PRIVATE).edit().putString("startup_script", selected.name).apply()
                Toast.makeText(this, "Startup script: ${selected.name}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showProjects() {
        val files = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", ignoreCase = true) }
            ?.sortedBy { it.name.lowercase() }
            .orEmpty()
        if (files.isEmpty()) {
            Toast.makeText(this, "No Python projects found", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Open Python project")
            .setItems(files.map { it.name }.toTypedArray()) { _, index -> openProject(files[index]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openProject(file: File) {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before switching projects", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val canonicalRoot = projectsDir.canonicalFile
            val canonicalFile = file.canonicalFile
            if (canonicalFile.parentFile != canonicalRoot || !canonicalFile.isFile || !canonicalFile.extension.equals("py", ignoreCase = true)) {
                Toast.makeText(this, "Invalid project file", Toast.LENGTH_LONG).show()
                return
            }
            if (canonicalFile.length() > maxImportedProjectBytes) {
                Toast.makeText(this, "Project file exceeds ${maxImportedProjectBytes / 1000} KB", Toast.LENGTH_LONG).show()
                return
            }
            editor.setText(canonicalFile.readText(Charsets.UTF_8))
            currentFile = canonicalFile
            currentFileLabel.text = "File: ${canonicalFile.name}"
            status.text = "Status: READY"
        } catch (e: Exception) {
            appendConsole("Could not open project: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun createProjectDialog() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before creating a project", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            hint = "example_bot"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Create Python project")
            .setMessage("Use letters, numbers, underscores or hyphens.")
            .setView(input)
            .setPositiveButton("Create", null)
            .setNegativeButton("Cancel", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val rawName = input.text.toString().trim().removeSuffix(".py")
                        if (!rawName.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}"))) {
                            input.error = "Enter a valid name (1–40 characters)"
                            return@setOnClickListener
                        }
                        val file = File(projectsDir, "$rawName.py")
                        if (file.exists()) {
                            input.error = "That project already exists"
                            return@setOnClickListener
                        }
                        try {
                            file.writeText("# $rawName\n\nprint(\"Hello from Vesper Runtime\")\n")
                            openProject(file)
                            dialog.dismiss()
                            Toast.makeText(this, "Created ${file.name}", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            input.error = "Could not create file: ${e.message ?: "unknown error"}"
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun saveCurrentProject(showToast: Boolean): Boolean {
        val file = currentFile ?: run {
            Toast.makeText(this, "Select or create a project first", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val root = projectsDir.canonicalFile
            val target = file.canonicalFile
            if (target.parentFile != root || !target.extension.equals("py", ignoreCase = true)) {
                appendConsole("Save blocked: project path is outside the workspace")
                false
            } else {
                val content = editor.text.toString()
                if (content.length > maxImportedProjectBytes || content.toByteArray(Charsets.UTF_8).size > maxImportedProjectBytes) {
                    Toast.makeText(this, "Project exceeds ${maxImportedProjectBytes / 1000} KB", Toast.LENGTH_LONG).show()
                    return false
                }
                target.writeText(content, Charsets.UTF_8)
                if (showToast) Toast.makeText(this, "Saved ${target.name}", Toast.LENGTH_SHORT).show()
                true
            }
        } catch (e: Exception) {
            appendConsole("Could not save project: ${e.message ?: e.javaClass.simpleName}")
            false
        }
    }

    private fun showDependencyManager() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before editing dependencies", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            setText(readRequirements())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            hint = "requests>=2.32,<3.0"
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundColor(Color.rgb(34, 34, 47))
            setPadding(14, 14, 14, 14)
            minLines = 9
            filters = arrayOf(InputFilter.LengthFilter(32_768))
        }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 4)
            addView(TextView(this@MainActivity).apply {
                text = "One package per line. Examples: requests>=2.32,<3.0 or discord.py>=2.4,<3.0.\n\nThese requirements are packaged into a new APK at build time. They do not install into the already-installed APK."
                setTextColor(Color.LTGRAY)
                textSize = 13f
                setPadding(0, 0, 0, 10)
            }, wrapMatch())
            addView(ScrollView(this@MainActivity).apply { addView(input) }, LinearLayout.LayoutParams(-1, dp(280)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Python dependencies")
            .setView(holder)
            .setPositiveButton("Save", null)
            .setNeutralButton("Validate", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val report = try {
                    validateRequirements(input.text.toString())
                } catch (e: Exception) {
                    Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                showRequirementsReport(report)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val report = try {
                    validateRequirements(input.text.toString())
                } catch (e: Exception) {
                    Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!report.optBoolean("valid", false)) {
                    showRequirementsReport(report)
                    return@setOnClickListener
                }
                try {
                    val saved = report.optString("normalized_text", input.text.toString())
                    requirementsFile.writeText(saved)
                    val count = report.optJSONArray("requirements")?.length() ?: 0
                    dialog.dismiss()
                    Toast.makeText(
                        this,
                        "Saved $count requirement(s). Export app/requirements.txt and rebuild the APK.",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not save requirements: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
        dialog.show()
    }

    private fun readRequirements(): String = try {
        requirementsFile.readText()
    } catch (_: Exception) {
        "# Vesper Runtime Python dependencies\n"
    }

    private fun validateRequirements(contents: String): JSONObject {
        val jsonText = Python.getInstance().getModule("vesper_dependencies")
            .callAttr("validate_requirements_json", contents)?.toString()
            ?: throw IllegalStateException("Dependency validator returned no result")
        return JSONObject(jsonText)
    }

    private fun showRequirementsReport(report: JSONObject) {
        val errors = jsonArrayToLines(report.optJSONArray("errors"))
        val packages = jsonArrayToLines(report.optJSONArray("requirements"))
        val warnings = jsonArrayToLines(report.optJSONArray("warnings"))
        val message = buildString {
            append(if (report.optBoolean("valid", false)) "Syntax check: PASS" else "Syntax check: FAILED")
            append("\n\nPackages: ").append(packages.size)
            if (errors.isNotEmpty()) {
                append("\n\nErrors:\n")
                append(errors.joinToString("\n"))
            }
            if (warnings.isNotEmpty()) {
                append("\n\nImportant:\n")
                append(warnings.joinToString("\n"))
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Dependency validation")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun jsonArrayToLines(array: org.json.JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            array.optString(index).takeIf { it.isNotBlank() }
        }
    }

    private fun exportRequirements() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before exporting dependencies", Toast.LENGTH_LONG).show()
            return
        }
        val content = readRequirements()
        val report = try {
            validateRequirements(content)
        } catch (e: Exception) {
            Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            return
        }
        if (!report.optBoolean("valid", false)) {
            showRequirementsReport(report)
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "requirements.txt")
        }
        try {
            startActivityForResult(intent, exportRequirementsRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open document picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses the platform document picker for broad API-level compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) {
            if (requestCode == exportProjectRequestCode) {
                pendingProjectExportName = null
                pendingProjectExportText = null
            }
            return
        }
        val uri = data?.data ?: return
        when (requestCode) {
            importProjectRequestCode -> importSelectedProject(uri)
            importFilesRequestCode -> importSelectedFileOrArchive(uri)
            exportRequirementsRequestCode -> {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                        writer.write(readRequirements())
                    } ?: throw IllegalStateException("Could not open the selected destination")
                    Toast.makeText(this, "Exported requirements.txt. Copy it to app/requirements.txt in the source project, then rebuild the APK.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Export failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
            exportProjectRequestCode -> {
                val exportText = pendingProjectExportText
                val exportName = pendingProjectExportName ?: "project.py"
                pendingProjectExportText = null
                pendingProjectExportName = null
                try {
                    if (exportText == null) throw IllegalStateException("No project content to export")
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(exportText) }
                        ?: throw IllegalStateException("Could not open destination")
                    Toast.makeText(this, "Exported $exportName", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Project export failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun importProject() {
        if (running) {
            Toast.makeText(this, "Stop the current script before importing a project", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importProjectRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importAnyFile() {
        if (running) {
            Toast.makeText(this, "Stop the current script before importing files", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "text/*", "application/octet-stream", "application/json", "application/pdf", "image/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importFilesRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importedFilesDir(): File = File(filesDir, "imports").apply { mkdirs() }

    private fun cleanImportedPath(raw: String): String {
        val normalized = raw.replace('\\', '/').trimStart('/')
        val parts = normalized.split('/')
        if (normalized.isBlank() || parts.any { it.isBlank() || it == "." || it == ".." } || normalized.contains(':')) {
            throw SecurityException("Archive contains an unsafe path")
        }
        return parts.joinToString("/") { part -> part.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(100).ifBlank { "file" } }
    }

    private fun uniqueImportedFile(parent: File, name: String): File {
        val base = name.substringAfterLast('/').ifBlank { "imported_file" }
        var candidate = File(parent, base)
        var n = 2
        while (candidate.exists()) {
            val stem = base.substringBeforeLast('.', base)
            val ext = if (base.contains('.')) "." + base.substringAfterLast('.') else ""
            candidate = File(parent, "${stem.take(80)}_$n$ext")
            n++
            if (n > 10000) throw IllegalStateException("Could not create a unique filename")
        }
        return candidate.canonicalFile.also {
            if (it.parentFile?.canonicalFile != parent.canonicalFile) throw SecurityException("Invalid import destination")
        }
    }

    private fun importSelectedFileOrArchive(uri: Uri) {
        try {
            val sourceName = displayName(uri) ?: "imported_file"
            if (sourceName.endsWith(".zip", ignoreCase = true)) {
                importZip(uri, sourceName)
            } else {
                val bytes = readLimited(uri, maxImportedArchiveBytes)
                val target = uniqueImportedFile(importedFilesDir(), sourceName.replace(Regex("[^A-Za-z0-9._ -]"), "_"))
                target.writeBytes(bytes)
                if (target.extension.equals("py", ignoreCase = true)) {
                    // Python projects live in their own workspace; copy there with a collision-safe name.
                    val projectTarget = uniqueImportedFile(projectsDir, target.name)
                    target.copyTo(projectTarget)
                    openProject(projectTarget)
                    Toast.makeText(this, "Imported ${projectTarget.name}. Review it before running.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Imported ${target.name} to Vesper/imports", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importZip(uri: Uri, archiveName: String) {
        val root = importedFilesDir().canonicalFile
        val folderName = archiveName.substringBeforeLast('.', archiveName)
            .replace(Regex("[^A-Za-z0-9_-]"), "_").take(50).ifBlank { "archive" }
        val destination = uniqueImportedFile(root, folderName).apply { mkdirs() }.canonicalFile
        var entryCount = 0
        var totalBytes = 0L
        var extractedPy: File? = null
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open ZIP")
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entryCount++
                    if (entryCount > maxArchiveEntries) throw IllegalArgumentException("ZIP has too many entries (limit $maxArchiveEntries)")
                    val relative = cleanImportedPath(entry.name)
                    val output = File(destination, relative).canonicalFile
                    if (output != destination && !output.path.startsWith(destination.path + File.separator)) {
                        throw SecurityException("ZIP entry escapes destination")
                    }
                    if (entry.isDirectory) {
                        output.mkdirs()
                    } else {
                        output.parentFile?.mkdirs()
                        var entryBytes = 0L
                        output.outputStream().buffered().use { stream ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                entryBytes += count
                                totalBytes += count
                                if (totalBytes > maxImportedArchiveBytes) throw IllegalArgumentException("Expanded ZIP exceeds 20 MB")
                                stream.write(buffer, 0, count)
                            }
                        }
                        if (extractedPy == null && output.extension.equals("py", ignoreCase = true)) extractedPy = output
                    }
                    zip.closeEntry()
                }
            }
            if (entryCount == 0) throw IllegalArgumentException("ZIP is empty or invalid")
            if (extractedPy != null) {
                // Keep extracted content in imports, but copy the first Python entry into the project workspace.
                val projectTarget = uniqueImportedFile(projectsDir, extractedPy.name)
                extractedPy.copyTo(projectTarget)
                openProject(projectTarget)
                Toast.makeText(this, "Extracted $entryCount entries. Opened ${projectTarget.name}; review before running.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Extracted $entryCount entries to Vesper/imports/${destination.name}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            destination.deleteRecursively()
            throw e
        }
    }

    private fun showImportedFiles() {
        val root = importedFilesDir()
        val items = root.walkTopDown().filter { it.isFile }.take(300).toList()
        if (items.isEmpty()) {
            Toast.makeText(this, "No imported files yet", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Imported files")
            .setItems(items.map { it.relativeTo(root).path }.toTypedArray()) { _, index ->
                val file = items[index]
                if (file.extension.equals("py", ignoreCase = true) && file.length() <= maxImportedProjectBytes) {
                    try {
                        val projectTarget = uniqueImportedFile(projectsDir, file.name)
                        file.copyTo(projectTarget)
                        openProject(projectTarget)
                        Toast.makeText(this, "Opened ${projectTarget.name}; review before running.", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Could not open file: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this, "Stored in app-private imports folder: ${file.name}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun exportCurrentProject() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before exporting", Toast.LENGTH_LONG).show()
            return
        }
        val file = currentFile ?: return
        if (!saveCurrentProject(showToast = false)) return
        try {
            pendingProjectExportName = file.name
            pendingProjectExportText = file.readText(Charsets.UTF_8)
        } catch (e: Exception) {
            pendingProjectExportName = null
            pendingProjectExportText = null
            Toast.makeText(this, "Could not read project: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/x-python"
            putExtra(Intent.EXTRA_TITLE, file.name)
        }
        try {
            startActivityForResult(intent, exportProjectRequestCode)
        } catch (e: Exception) {
            pendingProjectExportName = null
            pendingProjectExportText = null
            Toast.makeText(this, "Could not open export picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun readLimited(uri: Uri, limit: Int): ByteArray {
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open selected file")
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                if (total > limit) throw IllegalArgumentException("Python file exceeds ${limit / 1000} KB")
                out.write(buffer, 0, count)
            }
            return out.toByteArray()
        }
    }

    private fun displayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } else null
        } catch (_: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }

    private fun safeImportedName(displayName: String): String {
        val raw = displayName.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("(?i)\\.py$"), "")
        return if (raw.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}"))) raw else "imported_script"
    }

    private fun importSelectedProject(uri: Uri) {
        try {
            val sourceName = displayName(uri) ?: throw IllegalArgumentException("Could not determine the selected filename")
            if (!sourceName.endsWith(".py", ignoreCase = true)) {
                throw IllegalArgumentException("Select a .py Python source file")
            }
            val content = readLimited(uri, maxImportedProjectBytes).toString(Charsets.UTF_8)
            val baseName = safeImportedName(sourceName)
            var candidateName = "$baseName.py"
            var suffix = 2
            while (File(projectsDir, candidateName).exists()) {
                val suffixedBase = "${baseName.take(34)}_$suffix"
                candidateName = "$suffixedBase.py"
                suffix++
                if (suffix > 10_000) throw IllegalStateException("Could not generate a unique filename")
            }
            val target = File(projectsDir, candidateName).canonicalFile
            if (target.parentFile != projectsDir.canonicalFile) throw SecurityException("Invalid import destination")
            target.writeText(content, Charsets.UTF_8)
            openProject(target)
            Toast.makeText(this, "Imported ${target.name}. Review the code before running it.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopScript() {
        if (!running) return
        stopButton.isEnabled = false
        status.text = "Status: STOPPING — waiting for Python to reach a safe trace point"
        startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_STOP))
    }

    private fun runScript() {
        if (running) {
            appendConsole("A script is already running. Vesper currently runs one script at a time.")
            return
        }
        if (!saveCurrentProject(showToast = false)) return
        val selectedFile = currentFile ?: return
        running = true
        lastLogBytesRead = 0L
        runButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "Status: STARTING — ${selectedFile.name}"
        appendConsole("\n> Starting ${selectedFile.name} ...")

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // The service may still start without this permission, but Android may
            // show its foreground-service notice only in the system's active-apps UI.
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationPermissionRequestCode)
        }
        val intent = Intent(this, RuntimeService::class.java).apply {
            action = RuntimeService.ACTION_RUN
            putExtra(RuntimeService.EXTRA_SCRIPT_NAME, selectedFile.name)
            putExtra(RuntimeService.EXTRA_PROJECT_DIR, projectsDir.canonicalPath)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            running = false
            runButton.isEnabled = true
            stopButton.isEnabled = false
            status.text = "Status: ERROR"
            appendConsole("Could not start foreground service: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun appendConsole(message: String) {
        appendConsoleRaw(message + if (message.endsWith("\n")) "" else "\n")
    }

    private fun appendConsoleRaw(chunk: String) {
        if (chunk.isEmpty()) return
        val maxChars = 100_000
        val existing = console.text.toString()
        val combined = existing + chunk
        console.text = if (combined.length > maxChars) {
            "[Earlier console output trimmed]\n" + combined.takeLast(maxChars - 34)
        } else combined
    }

    private fun showFatalRuntimeError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Vesper Runtime could not start")
            .setMessage(message)
            .setPositiveButton("Close") { _, _ -> finish() }
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun wrapMatch() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
