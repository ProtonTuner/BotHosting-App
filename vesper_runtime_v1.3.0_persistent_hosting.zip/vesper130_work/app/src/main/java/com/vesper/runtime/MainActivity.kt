package com.vesper.runtime

import android.app.Activity
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.StatFs
import android.app.ActivityManager
import android.graphics.Color
import android.content.pm.PackageManager
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.InputFilter
import org.json.JSONObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var console: TextView
    private lateinit var status: TextView
    private lateinit var currentFileLabel: TextView
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private lateinit var projectsDir: File
    private lateinit var requirementsFile: File
    private var currentFile: File? = null
    private var running = false // Accessed only on the main thread.
    private var receiverRegistered = false
    private var runtimeUiInitialized = false
    private var pendingProjectExportName: String? = null
    private var pendingProjectExportText: String? = null
    private var lastLogBytesRead = 0L
    private val exportRequirementsRequestCode = 4307
    private val importProjectRequestCode = 4308
    private val importFilesRequestCode = 4311
    private val exportProjectRequestCode = 4309
    private val notificationPermissionRequestCode = 4310
    private val maxImportedProjectBytes = 1_000_000
    private val maxImportedArchiveBytes = 20 * 1024 * 1024
    private val maxArchiveEntries = 500

    private val runtimeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                RuntimeService.ACTION_STATE -> {
                    status.text = intent.getStringExtra(RuntimeService.EXTRA_STATUS) ?: "Status: READY"
                    running = intent.getBooleanExtra(RuntimeService.EXTRA_RUNNING, false)
                    runButton.isEnabled = !running
                    stopButton.isEnabled = running
                }
                RuntimeService.ACTION_OUTPUT -> {
                    val outputText = intent.getStringExtra(RuntimeService.EXTRA_OUTPUT) ?: "(no output)"
                    val startOffset = intent.getLongExtra(RuntimeService.EXTRA_OUTPUT_START_OFFSET, -1L)
                    val endOffset = intent.getLongExtra(RuntimeService.EXTRA_OUTPUT_OFFSET, -1L)
                    if (startOffset < 0L || endOffset < 0L) {
                        appendConsoleRaw(outputText)
                        return
                    }
                    // Log catch-up and live broadcasts can race while this Activity returns
                    // to the foreground. Byte offsets prevent duplicate console chunks.
                    if (endOffset <= lastLogBytesRead) return
                    if (startOffset > lastLogBytesRead) appendMissedRunningOutput(startOffset)
                    var chunkToAppend = outputText
                    if (startOffset < lastLogBytesRead) {
                        val bytes = outputText.toByteArray(Charsets.UTF_8)
                        val skipBytes = (lastLogBytesRead - startOffset).coerceAtMost(bytes.size.toLong()).toInt()
                        if (skipBytes >= bytes.size) {
                            lastLogBytesRead = maxOf(lastLogBytesRead, endOffset)
                            return
                        }
                        chunkToAppend = String(bytes.copyOfRange(skipBytes, bytes.size), Charsets.UTF_8)
                    }
                    appendConsoleRaw(chunkToAppend)
                    lastLogBytesRead = maxOf(lastLogBytesRead, endOffset)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        } catch (e: Exception) {
            showFatalRuntimeError("Python could not start: ${e.message ?: e.javaClass.simpleName}")
            return
        }

        projectsDir = File(filesDir, "projects").apply { mkdirs() }
        requirementsFile = File(filesDir, "requirements.txt")
        if (!requirementsFile.exists()) {
            try {
                assets.open("requirements.txt").use { input -> requirementsFile.writeBytes(input.readBytes()) }
            } catch (e: Exception) {
                requirementsFile.writeText("# Vesper Runtime Python dependencies\n")
            }
        }
        val starter = File(projectsDir, "main.py")
        if (!starter.exists()) {
            try {
                assets.open("main.py").use { input -> starter.writeBytes(input.readBytes()) }
            } catch (e: Exception) {
                starter.writeText("print('Vesper Runtime is ready.')\n")
            }
        }
        currentFile = starter

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(20, 20, 29))
        }
        // Android 15+ enforces edge-to-edge for apps targeting API 35.
        // Apply system-bar insets so the controls remain visible around cutouts/bars.
        ViewCompat.setOnApplyWindowInsetsListener(page) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(16 + bars.left, 16 + bars.top, 16 + bars.right, 16 + bars.bottom)
            insets
        }
        page.addView(TextView(this).apply {
            text = "VESPER RUNTIME"
            textSize = 23f
            setTextColor(Color.WHITE)
        }, wrapMatch())
        page.addView(TextView(this).apply {
            text = "Embedded Python • Runtime 1.0.0"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }, wrapMatch())

        status = TextView(this).apply {
            text = "Status: READY"
            textSize = 14f
            setTextColor(Color.rgb(72, 201, 176))
            setPadding(0, 10, 0, 4)
        }
        page.addView(status, wrapMatch())

        val hostingButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hostingButtons.addView(makeButton("HOSTING PANEL") { showHostingPanel() }, weightedButton())
        hostingButtons.addView(makeButton("STARTUP SCRIPT") { chooseStartupScript() }, weightedButton())
        page.addView(hostingButtons, wrapMatch())
        currentFileLabel = TextView(this).apply {
            text = "File: main.py"
            textSize = 13f
            setTextColor(Color.rgb(190, 190, 215))
            setPadding(0, 0, 0, 8)
        }
        page.addView(currentFileLabel, wrapMatch())

        editor = EditText(this).apply {
            setText(starter.readText())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            hint = "Python code"
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundColor(Color.rgb(34, 34, 47))
            setPadding(12, 12, 12, 12)
            minLines = 6
        }
        page.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val fileButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fileButtons.addView(makeButton("PROJECTS") { showProjects() }, weightedButton())
        fileButtons.addView(makeButton("NEW") { createProjectDialog() }, weightedButton())
        fileButtons.addView(makeButton("SAVE") { saveCurrentProject(showToast = true) }, weightedButton())
        page.addView(fileButtons, wrapMatch())

        val transferButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        transferButtons.addView(makeButton("IMPORT .PY") { importProject() }, weightedButton())
        transferButtons.addView(makeButton("EXPORT .PY") { exportCurrentProject() }, weightedButton())
        page.addView(transferButtons, wrapMatch())

        val archiveButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        archiveButtons.addView(makeButton("IMPORT ZIP / FILES") { importAnyFile() }, weightedButton())
        archiveButtons.addView(makeButton("IMPORTED FILES") { showImportedFiles() }, weightedButton())
        page.addView(archiveButtons, wrapMatch())

        val dependencyButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dependencyButtons.addView(makeButton("DEPENDENCIES") { showDependencyManager() }, weightedButton())
        dependencyButtons.addView(makeButton("EXPORT REQ.") { exportRequirements() }, weightedButton())
        page.addView(dependencyButtons, wrapMatch())

        val runButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        runButton = makeButton("RUN") { runScript() }
        stopButton = makeButton("STOP") { stopScript() }.apply { isEnabled = false }
        runButtons.addView(runButton, weightedButton())
        runButtons.addView(stopButton, weightedButton())
        runButtons.addView(makeButton("CLEAR") {
            console.text = "Console cleared.\n"
        }, weightedButton())
        page.addView(runButtons, wrapMatch())

        page.addView(TextView(this).apply {
            text = "CONSOLE"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 4)
        }, wrapMatch())
        console = TextView(this).apply {
            text = "Ready. Open or create a Python project, then run it.\n"
            textSize = 12f
            setTextColor(Color.rgb(180, 230, 200))
            setPadding(10, 10, 10, 10)
            setBackgroundColor(Color.BLACK)
            setTextIsSelectable(true)
        }
        page.addView(ScrollView(this).apply { addView(console) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 150))
        setContentView(page)
        runtimeUiInitialized = true
        syncRuntimeState()
    }

    override fun onStart() {
        super.onStart()
        // Python initialization can fail before the UI is constructed. The fatal-error
        // dialog is still shown, but lifecycle callbacks must not touch lateinit views.
        if (!runtimeUiInitialized) return
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(RuntimeService.ACTION_STATE)
                addAction(RuntimeService.ACTION_OUTPUT)
            }
            ContextCompat.registerReceiver(this, runtimeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        syncRuntimeState()
        if (running) appendMissedRunningOutput()
        // Ask the service to confirm state so a stale persisted RUNNING flag cannot
        // leave the controls disabled if Android killed the process.
        try {
            startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_QUERY))
        } catch (_: Exception) {
            // The UI still reflects the most recent persisted state if querying fails.
        }
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(runtimeReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun syncRuntimeState() {
        val prefs = getSharedPreferences(RuntimeService.PREFS_NAME, MODE_PRIVATE)
        status.text = prefs.getString(RuntimeService.KEY_STATUS, "Status: READY")
        running = prefs.getBoolean(RuntimeService.KEY_RUNNING, false)
        runButton.isEnabled = !running
        stopButton.isEnabled = running
        val lastOutput = prefs.getString(RuntimeService.KEY_LAST_OUTPUT, "").orEmpty()
        if (lastOutput.isNotBlank() && console.text.toString().trim() == "Ready. Open or create a Python project, then run it.") {
            appendConsole(lastOutput)
        }
    }

    private fun appendMissedRunningOutput(untilOffset: Long? = null) {
        val logFile = File(filesDir, "runtime-output.log")
        if (!logFile.isFile) return
        try {
            RandomAccessFile(logFile, "r").use { stream ->
                val targetOffset = minOf(untilOffset ?: stream.length(), stream.length())
                while (lastLogBytesRead < targetOffset) {
                    stream.seek(lastLogBytesRead)
                    val remaining = (targetOffset - lastLogBytesRead).coerceAtMost(256_000L).toInt()
                    val bytes = ByteArray(remaining)
                    val count = stream.read(bytes)
                    if (count <= 0) break
                    appendConsoleRaw(String(bytes, 0, count, Charsets.UTF_8))
                    lastLogBytesRead += count
                }
            }
        } catch (e: Exception) {
            appendConsole("Could not restore recent output: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setOnClickListener { action() }
    }

    private fun weightedButton() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    /** Wispbyte-inspired local hosting dashboard. Python jobs still run on this phone. */
    private fun showHostingPanel() {
        val scripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        val prefs = getSharedPreferences("vesper_hosting", MODE_PRIVATE)
        val startup = prefs.getString("startup_script", "main.py") ?: "main.py"
        val stat = StatFs(filesDir.absolutePath)
        val freeMb = stat.availableBytes / (1024 * 1024)
        val totalMb = stat.totalBytes / (1024 * 1024)
        val memory = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        memory.getMemoryInfo(memInfo)
        val runningText = if (running) "RUNNING" else "STOPPED"
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(4))
        }
        val autoRestart = prefs.getBoolean(RuntimeService.KEY_AUTO_RESTART, false)
        panel.addView(TextView(this).apply {
            text = "Local engine: $runningText\nStartup script: $startup\nPython projects: ${scripts.size}\nApp storage free: ${freeMb} MB / ${totalMb} MB\nDevice RAM available: ${memInfo.availMem / (1024 * 1024)} MB\nUnexpected-kill recovery: ${if (autoRestart) "ON" else "OFF"}\n\nRuns on this Android device. Recovery is best-effort; Android and device vendors can still restrict services."
            textSize = 14f
        })
        panel.addView(makeButton(if (autoRestart) "AUTO-RESTART: ON (TAP TO DISABLE)" else "AUTO-RESTART: OFF (TAP TO ENABLE)") {
            prefs.edit().putBoolean(RuntimeService.KEY_AUTO_RESTART, !autoRestart).apply()
            Toast.makeText(this, if (!autoRestart) "Unexpected-kill recovery enabled" else "Unexpected-kill recovery disabled", Toast.LENGTH_SHORT).show()
            showHostingPanel()
        })
        panel.addView(makeButton("BATTERY / BACKGROUND SETTINGS") {
            openBackgroundSettings()
        })
        AlertDialog.Builder(this)
            .setTitle("VESPER HOSTING PANEL")
            .setView(panel)
            .setPositiveButton(if (running) "STOP ENGINE" else "START STARTUP") { _, _ ->
                if (running) {
                    stopScript()
                } else {
                    val chosen = scripts.firstOrNull { it.name == startup }
                        ?: scripts.firstOrNull { it.name == "main.py" }
                        ?: scripts.firstOrNull()
                    if (chosen == null) {
                        Toast.makeText(this, "Import or create a .py project first", Toast.LENGTH_LONG).show()
                    } else {
                        openProject(chosen)
                        runScript()
                    }
                }
            }
            .setNeutralButton("SELECT STARTUP") { _, _ -> chooseStartupScript() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun openBackgroundSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            } else {
                Intent(android.provider.Settings.ACTION_SETTINGS)
            }
            startActivity(intent)
        } catch (e: Exception) {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            catch (_: Exception) {
                Toast.makeText(this, "Open Android Settings and review Vesper Runtime battery/background restrictions.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun chooseStartupScript() {
        val scripts = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", true) }
            ?.sortedBy { it.name.lowercase() }.orEmpty()
        if (scripts.isEmpty()) {
            Toast.makeText(this, "Create or import a Python script first", Toast.LENGTH_SHORT).show()
            return
        }
        val current = getSharedPreferences("vesper_hosting", MODE_PRIVATE).getString("startup_script", "main.py")
        AlertDialog.Builder(this)
            .setTitle("Choose startup script")
            .setSingleChoiceItems(scripts.map { if (it.name == current) "✓ ${it.name}" else it.name }.toTypedArray(),
                scripts.indexOfFirst { it.name == current }.coerceAtLeast(-1)) { dialog, which ->
                val selected = scripts[which]
                getSharedPreferences("vesper_hosting", MODE_PRIVATE).edit().putString("startup_script", selected.name).apply()
                Toast.makeText(this, "Startup script: ${selected.name}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showProjects() {
        val files = projectsDir.listFiles { file -> file.isFile && file.extension.equals("py", ignoreCase = true) }
            ?.sortedBy { it.name.lowercase() }
            .orEmpty()
        if (files.isEmpty()) {
            Toast.makeText(this, "No Python projects found", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Open Python project")
            .setItems(files.map { it.name }.toTypedArray()) { _, index -> openProject(files[index]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openProject(file: File) {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before switching projects", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val canonicalRoot = projectsDir.canonicalFile
            val canonicalFile = file.canonicalFile
            if (canonicalFile.parentFile != canonicalRoot || !canonicalFile.isFile || !canonicalFile.extension.equals("py", ignoreCase = true)) {
                Toast.makeText(this, "Invalid project file", Toast.LENGTH_LONG).show()
                return
            }
            if (canonicalFile.length() > maxImportedProjectBytes) {
                Toast.makeText(this, "Project file exceeds ${maxImportedProjectBytes / 1000} KB", Toast.LENGTH_LONG).show()
                return
            }
            editor.setText(canonicalFile.readText(Charsets.UTF_8))
            currentFile = canonicalFile
            currentFileLabel.text = "File: ${canonicalFile.name}"
            status.text = "Status: READY"
        } catch (e: Exception) {
            appendConsole("Could not open project: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun createProjectDialog() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before creating a project", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            hint = "example_bot"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Create Python project")
            .setMessage("Use letters, numbers, underscores or hyphens.")
            .setView(input)
            .setPositiveButton("Create", null)
            .setNegativeButton("Cancel", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val rawName = input.text.toString().trim().removeSuffix(".py")
                        if (!rawName.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}"))) {
                            input.error = "Enter a valid name (1–40 characters)"
                            return@setOnClickListener
                        }
                        val file = File(projectsDir, "$rawName.py")
                        if (file.exists()) {
                            input.error = "That project already exists"
                            return@setOnClickListener
                        }
                        try {
                            file.writeText("# $rawName\n\nprint(\"Hello from Vesper Runtime\")\n")
                            openProject(file)
                            dialog.dismiss()
                            Toast.makeText(this, "Created ${file.name}", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            input.error = "Could not create file: ${e.message ?: "unknown error"}"
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun saveCurrentProject(showToast: Boolean): Boolean {
        val file = currentFile ?: run {
            Toast.makeText(this, "Select or create a project first", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val root = projectsDir.canonicalFile
            val target = file.canonicalFile
            if (target.parentFile != root || !target.extension.equals("py", ignoreCase = true)) {
                appendConsole("Save blocked: project path is outside the workspace")
                false
            } else {
                val content = editor.text.toString()
                if (content.length > maxImportedProjectBytes || content.toByteArray(Charsets.UTF_8).size > maxImportedProjectBytes) {
                    Toast.makeText(this, "Project exceeds ${maxImportedProjectBytes / 1000} KB", Toast.LENGTH_LONG).show()
                    return false
                }
                target.writeText(content, Charsets.UTF_8)
                if (showToast) Toast.makeText(this, "Saved ${target.name}", Toast.LENGTH_SHORT).show()
                true
            }
        } catch (e: Exception) {
            appendConsole("Could not save project: ${e.message ?: e.javaClass.simpleName}")
            false
        }
    }

    private fun showDependencyManager() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before editing dependencies", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            setText(readRequirements())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            hint = "requests>=2.32,<3.0"
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundColor(Color.rgb(34, 34, 47))
            setPadding(14, 14, 14, 14)
            minLines = 9
            filters = arrayOf(InputFilter.LengthFilter(32_768))
        }
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 4)
            addView(TextView(this@MainActivity).apply {
                text = "One package per line. Examples: requests>=2.32,<3.0 or discord.py>=2.4,<3.0.\n\nThese requirements are packaged into a new APK at build time. They do not install into the already-installed APK."
                setTextColor(Color.LTGRAY)
                textSize = 13f
                setPadding(0, 0, 0, 10)
            }, wrapMatch())
            addView(ScrollView(this@MainActivity).apply { addView(input) }, LinearLayout.LayoutParams(-1, dp(280)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Python dependencies")
            .setView(holder)
            .setPositiveButton("Save", null)
            .setNeutralButton("Validate", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val report = try {
                    validateRequirements(input.text.toString())
                } catch (e: Exception) {
                    Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                showRequirementsReport(report)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val report = try {
                    validateRequirements(input.text.toString())
                } catch (e: Exception) {
                    Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!report.optBoolean("valid", false)) {
                    showRequirementsReport(report)
                    return@setOnClickListener
                }
                try {
                    val saved = report.optString("normalized_text", input.text.toString())
                    requirementsFile.writeText(saved)
                    val count = report.optJSONArray("requirements")?.length() ?: 0
                    dialog.dismiss()
                    Toast.makeText(
                        this,
                        "Saved $count requirement(s). Export app/requirements.txt and rebuild the APK.",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not save requirements: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
        dialog.show()
    }

    private fun readRequirements(): String = try {
        requirementsFile.readText()
    } catch (_: Exception) {
        "# Vesper Runtime Python dependencies\n"
    }

    private fun validateRequirements(contents: String): JSONObject {
        val jsonText = Python.getInstance().getModule("vesper_dependencies")
            .callAttr("validate_requirements_json", contents)?.toString()
            ?: throw IllegalStateException("Dependency validator returned no result")
        return JSONObject(jsonText)
    }

    private fun showRequirementsReport(report: JSONObject) {
        val errors = jsonArrayToLines(report.optJSONArray("errors"))
        val packages = jsonArrayToLines(report.optJSONArray("requirements"))
        val warnings = jsonArrayToLines(report.optJSONArray("warnings"))
        val message = buildString {
            append(if (report.optBoolean("valid", false)) "Syntax check: PASS" else "Syntax check: FAILED")
            append("\n\nPackages: ").append(packages.size)
            if (errors.isNotEmpty()) {
                append("\n\nErrors:\n")
                append(errors.joinToString("\n"))
            }
            if (warnings.isNotEmpty()) {
                append("\n\nImportant:\n")
                append(warnings.joinToString("\n"))
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Dependency validation")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun jsonArrayToLines(array: org.json.JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            array.optString(index).takeIf { it.isNotBlank() }
        }
    }

    private fun exportRequirements() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before exporting dependencies", Toast.LENGTH_LONG).show()
            return
        }
        val content = readRequirements()
        val report = try {
            validateRequirements(content)
        } catch (e: Exception) {
            Toast.makeText(this, "Validation failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            return
        }
        if (!report.optBoolean("valid", false)) {
            showRequirementsReport(report)
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "requirements.txt")
        }
        try {
            startActivityForResult(intent, exportRequirementsRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open document picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses the platform document picker for broad API-level compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) {
            if (requestCode == exportProjectRequestCode) {
                pendingProjectExportName = null
                pendingProjectExportText = null
            }
            return
        }
        val uri = data?.data ?: return
        when (requestCode) {
            importProjectRequestCode -> importSelectedProject(uri)
            importFilesRequestCode -> importSelectedFileOrArchive(uri)
            exportRequirementsRequestCode -> {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                        writer.write(readRequirements())
                    } ?: throw IllegalStateException("Could not open the selected destination")
                    Toast.makeText(this, "Exported requirements.txt. Copy it to app/requirements.txt in the source project, then rebuild the APK.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Export failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
            exportProjectRequestCode -> {
                val exportText = pendingProjectExportText
                val exportName = pendingProjectExportName ?: "project.py"
                pendingProjectExportText = null
                pendingProjectExportName = null
                try {
                    if (exportText == null) throw IllegalStateException("No project content to export")
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(exportText) }
                        ?: throw IllegalStateException("Could not open destination")
                    Toast.makeText(this, "Exported $exportName", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Project export failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun importProject() {
        if (running) {
            Toast.makeText(this, "Stop the current script before importing a project", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importProjectRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importAnyFile() {
        if (running) {
            Toast.makeText(this, "Stop the current script before importing files", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "text/*", "application/octet-stream", "application/json", "application/pdf", "image/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, importFilesRequestCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open file picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importedFilesDir(): File = File(filesDir, "imports").apply { mkdirs() }

    private fun cleanImportedPath(raw: String): String {
        val normalized = raw.replace('\\', '/').trimStart('/')
        val parts = normalized.split('/')
        if (normalized.isBlank() || parts.any { it.isBlank() || it == "." || it == ".." } || normalized.contains(':')) {
            throw SecurityException("Archive contains an unsafe path")
        }
        return parts.joinToString("/") { part -> part.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(100).ifBlank { "file" } }
    }

    private fun uniqueImportedFile(parent: File, name: String): File {
        val base = name.substringAfterLast('/').ifBlank { "imported_file" }
        var candidate = File(parent, base)
        var n = 2
        while (candidate.exists()) {
            val stem = base.substringBeforeLast('.', base)
            val ext = if (base.contains('.')) "." + base.substringAfterLast('.') else ""
            candidate = File(parent, "${stem.take(80)}_$n$ext")
            n++
            if (n > 10000) throw IllegalStateException("Could not create a unique filename")
        }
        return candidate.canonicalFile.also {
            if (it.parentFile?.canonicalFile != parent.canonicalFile) throw SecurityException("Invalid import destination")
        }
    }

    private fun importSelectedFileOrArchive(uri: Uri) {
        try {
            val sourceName = displayName(uri) ?: "imported_file"
            if (sourceName.endsWith(".zip", ignoreCase = true)) {
                importZip(uri, sourceName)
            } else {
                val bytes = readLimited(uri, maxImportedArchiveBytes)
                val target = uniqueImportedFile(importedFilesDir(), sourceName.replace(Regex("[^A-Za-z0-9._ -]"), "_"))
                target.writeBytes(bytes)
                if (target.extension.equals("py", ignoreCase = true)) {
                    // Python projects live in their own workspace; copy there with a collision-safe name.
                    val projectTarget = uniqueImportedFile(projectsDir, target.name)
                    target.copyTo(projectTarget)
                    openProject(projectTarget)
                    Toast.makeText(this, "Imported ${projectTarget.name}. Review it before running.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Imported ${target.name} to Vesper/imports", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importZip(uri: Uri, archiveName: String) {
        val root = importedFilesDir().canonicalFile
        val folderName = archiveName.substringBeforeLast('.', archiveName)
            .replace(Regex("[^A-Za-z0-9_-]"), "_").take(50).ifBlank { "archive" }
        val destination = uniqueImportedFile(root, folderName).apply { mkdirs() }.canonicalFile
        var entryCount = 0
        var totalBytes = 0L
        var extractedPy: File? = null
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open ZIP")
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entryCount++
                    if (entryCount > maxArchiveEntries) throw IllegalArgumentException("ZIP has too many entries (limit $maxArchiveEntries)")
                    val relative = cleanImportedPath(entry.name)
                    val output = File(destination, relative).canonicalFile
                    if (output != destination && !output.path.startsWith(destination.path + File.separator)) {
                        throw SecurityException("ZIP entry escapes destination")
                    }
                    if (entry.isDirectory) {
                        output.mkdirs()
                    } else {
                        output.parentFile?.mkdirs()
                        var entryBytes = 0L
                        output.outputStream().buffered().use { stream ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                entryBytes += count
                                totalBytes += count
                                if (totalBytes > maxImportedArchiveBytes) throw IllegalArgumentException("Expanded ZIP exceeds 20 MB")
                                stream.write(buffer, 0, count)
                            }
                        }
                        if (extractedPy == null && output.extension.equals("py", ignoreCase = true)) extractedPy = output
                    }
                    zip.closeEntry()
                }
            }
            if (entryCount == 0) throw IllegalArgumentException("ZIP is empty or invalid")
            if (extractedPy != null) {
                // Keep extracted content in imports, but copy the first Python entry into the project workspace.
                val projectTarget = uniqueImportedFile(projectsDir, extractedPy.name)
                extractedPy.copyTo(projectTarget)
                openProject(projectTarget)
                Toast.makeText(this, "Extracted $entryCount entries. Opened ${projectTarget.name}; review before running.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Extracted $entryCount entries to Vesper/imports/${destination.name}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            destination.deleteRecursively()
            throw e
        }
    }

    private fun showImportedFiles() {
        val root = importedFilesDir()
        val items = root.walkTopDown().filter { it.isFile }.take(300).toList()
        if (items.isEmpty()) {
            Toast.makeText(this, "No imported files yet", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Imported files")
            .setItems(items.map { it.relativeTo(root).path }.toTypedArray()) { _, index ->
                val file = items[index]
                if (file.extension.equals("py", ignoreCase = true) && file.length() <= maxImportedProjectBytes) {
                    try {
                        val projectTarget = uniqueImportedFile(projectsDir, file.name)
                        file.copyTo(projectTarget)
                        openProject(projectTarget)
                        Toast.makeText(this, "Opened ${projectTarget.name}; review before running.", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Could not open file: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this, "Stored in app-private imports folder: ${file.name}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun exportCurrentProject() {
        if (running) {
            Toast.makeText(this, "Wait for the running script to finish before exporting", Toast.LENGTH_LONG).show()
            return
        }
        val file = currentFile ?: return
        if (!saveCurrentProject(showToast = false)) return
        try {
            pendingProjectExportName = file.name
            pendingProjectExportText = file.readText(Charsets.UTF_8)
        } catch (e: Exception) {
            pendingProjectExportName = null
            pendingProjectExportText = null
            Toast.makeText(this, "Could not read project: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/x-python"
            putExtra(Intent.EXTRA_TITLE, file.name)
        }
        try {
            startActivityForResult(intent, exportProjectRequestCode)
        } catch (e: Exception) {
            pendingProjectExportName = null
            pendingProjectExportText = null
            Toast.makeText(this, "Could not open export picker: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun readLimited(uri: Uri, limit: Int): ByteArray {
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open selected file")
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                if (total > limit) throw IllegalArgumentException("Python file exceeds ${limit / 1000} KB")
                out.write(buffer, 0, count)
            }
            return out.toByteArray()
        }
    }

    private fun displayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            } else null
        } catch (_: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }

    private fun safeImportedName(displayName: String): String {
        val raw = displayName.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("(?i)\\.py$"), "")
        return if (raw.matches(Regex("[A-Za-z0-9_][A-Za-z0-9_-]{0,39}"))) raw else "imported_script"
    }

    private fun importSelectedProject(uri: Uri) {
        try {
            val sourceName = displayName(uri) ?: throw IllegalArgumentException("Could not determine the selected filename")
            if (!sourceName.endsWith(".py", ignoreCase = true)) {
                throw IllegalArgumentException("Select a .py Python source file")
            }
            val content = readLimited(uri, maxImportedProjectBytes).toString(Charsets.UTF_8)
            val baseName = safeImportedName(sourceName)
            var candidateName = "$baseName.py"
            var suffix = 2
            while (File(projectsDir, candidateName).exists()) {
                val suffixedBase = "${baseName.take(34)}_$suffix"
                candidateName = "$suffixedBase.py"
                suffix++
                if (suffix > 10_000) throw IllegalStateException("Could not generate a unique filename")
            }
            val target = File(projectsDir, candidateName).canonicalFile
            if (target.parentFile != projectsDir.canonicalFile) throw SecurityException("Invalid import destination")
            target.writeText(content, Charsets.UTF_8)
            openProject(target)
            Toast.makeText(this, "Imported ${target.name}. Review the code before running it.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopScript() {
        if (!running) return
        stopButton.isEnabled = false
        status.text = "Status: STOPPING — waiting for Python to reach a safe trace point"
        startService(Intent(this, RuntimeService::class.java).setAction(RuntimeService.ACTION_STOP))
    }

    private fun runScript() {
        if (running) {
            appendConsole("A script is already running. Vesper currently runs one script at a time.")
            return
        }
        if (!saveCurrentProject(showToast = false)) return
        val selectedFile = currentFile ?: return
        running = true
        lastLogBytesRead = 0L
        runButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "Status: STARTING — ${selectedFile.name}"
        appendConsole("\n> Starting ${selectedFile.name} ...")

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // The service may still start without this permission, but Android may
            // show its foreground-service notice only in the system's active-apps UI.
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationPermissionRequestCode)
        }
        val intent = Intent(this, RuntimeService::class.java).apply {
            action = RuntimeService.ACTION_RUN
            putExtra(RuntimeService.EXTRA_SCRIPT_NAME, selectedFile.name)
            putExtra(RuntimeService.EXTRA_PROJECT_DIR, projectsDir.canonicalPath)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            running = false
            runButton.isEnabled = true
            stopButton.isEnabled = false
            status.text = "Status: ERROR"
            appendConsole("Could not start foreground service: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun appendConsole(message: String) {
        appendConsoleRaw(message + if (message.endsWith("\n")) "" else "\n")
    }

    private fun appendConsoleRaw(chunk: String) {
        if (chunk.isEmpty()) return
        val maxChars = 100_000
        val existing = console.text.toString()
        val combined = existing + chunk
        console.text = if (combined.length > maxChars) {
            "[Earlier console output trimmed]\n" + combined.takeLast(maxChars - 34)
        } else combined
    }

    private fun showFatalRuntimeError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Vesper Runtime could not start")
            .setMessage(message)
            .setPositiveButton("Close") { _, _ -> finish() }
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun wrapMatch() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
