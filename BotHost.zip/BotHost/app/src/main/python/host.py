"""Runner de bots. Corre dentro del proceso de cada bot (un proceso por bot).

Java llama a run(bot_dir) en un hilo, stop() para cerrar, y warmup() una vez.
"""
import asyncio
import hashlib
import io
import json
import os
import runpy
import shutil
import sys
import threading
import time
import traceback
import zipfile

_stopping = False
_clients = []  # (client, loop) de cada discord.Client que se inicio


class _Log(object):
    """Escribe stdout/stderr en log.txt con hora y rota el archivo si crece."""

    encoding = "utf-8"
    errors = "replace"

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self.bol = True
        try:
            size = os.path.getsize(path)
        except OSError:
            size = 0
        if size > 400000:
            try:
                os.replace(path, path + ".1")
            except OSError:
                pass
            size = 0
        self.n = size
        self.f = open(path, "a", encoding="utf-8", errors="replace", buffering=1)

    def write(self, s):
        if not s:
            return 0
        out = []
        for part in s.splitlines(True):
            if self.bol:
                out.append(time.strftime("%H:%M:%S "))
            out.append(part)
            self.bol = part.endswith("\n")
        text = "".join(out)
        with self.lock:
            try:
                self.f.write(text)
                self.n += len(text)
                if self.n > 400000:
                    self._rotate()
            except Exception:
                pass
        return len(s)

    def _rotate(self):
        try:
            self.f.close()
            os.replace(self.path, self.path + ".1")
        except OSError:
            pass
        self.f = open(self.path, "a", encoding="utf-8", errors="replace", buffering=1)
        self.n = 0

    def flush(self):
        try:
            self.f.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


def _hint(exc):
    """Devuelve (mensaje, fatal) para errores comunes; fatal = reiniciar no sirve de nada."""
    names = [c.__name__ for c in type(exc).__mro__]
    if "ModuleNotFoundError" in names:
        mod = getattr(exc, "name", None) or "?"
        return ("Falta el modulo '%s'. La app no puede hacer pip install en el celular: "
                "agregalo a requirements.txt del bot (solo paquetes de Python puro) o, si tiene codigo "
                "nativo, a app/build.gradle (pip { install \"%s\" }) y recompila." % (mod, mod), True)
    if "SyntaxError" in names:  # incluye IndentationError
        return ("Error de sintaxis en %s linea %s. Corrigelo en 'Editar codigo'."
                % (os.path.basename(str(getattr(exc, "filename", "") or "main.py")),
                   getattr(exc, "lineno", "?")), True)
    if "LoginFailure" in names:
        return ("Token invalido. Revisa el token en la pantalla del bot.", True)
    if "PrivilegedIntentsRequired" in names:
        return ("Faltan intents privilegiados: activalos en Discord Developer Portal > Bot "
                "(Message Content / Server Members / Presence).", True)
    return None


# ---------------------------------------------------------------------------
# Instalador de requirements.txt (solo wheels de Python puro, desde PyPI)
# ---------------------------------------------------------------------------

def _py_ok_tag(interp, abi, plat):
    if plat != "any":
        return False
    if interp == "py3":
        return True
    if interp.startswith("py3") and interp[3:].isdigit():
        return int(interp[3:]) <= sys.version_info[1]
    return interp == "cp%d%d" % sys.version_info[:2] and abi == "none"


def _pick_wheel(files, pyver):
    from packaging.specifiers import SpecifierSet
    from packaging.utils import parse_wheel_filename
    for f in files or []:
        fn = f.get("filename", "")
        if f.get("packagetype") != "bdist_wheel" or f.get("yanked") or not fn.endswith("-none-any.whl"):
            continue
        try:
            tags = parse_wheel_filename(fn)[3]
        except Exception:
            continue
        if not any(_py_ok_tag(t.interpreter, t.abi, t.platform) for t in tags):
            continue
        rp = f.get("requires_python")
        if rp:
            try:
                if not SpecifierSet(rp).contains(pyver, prereleases=True):
                    continue
            except Exception:
                pass
        return f
    return None


def _dist_infos(libs, key):
    from packaging.utils import canonicalize_name
    out = []
    try:
        names = os.listdir(libs)
    except OSError:
        return out
    for e in names:
        if e.endswith(".dist-info"):
            nm = e[:-len(".dist-info")].rsplit("-", 1)[0]
            if canonicalize_name(nm) == key:
                out.append(os.path.join(libs, e))
    return out


def _extract_wheel(path, libs):
    root = os.path.realpath(libs) + os.sep
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if info.filename.endswith("/"):
                continue
            name = info.filename
            parts = name.split("/")
            if parts[0].endswith(".data"):
                if len(parts) > 2 and parts[1] in ("purelib", "platlib"):
                    name = "/".join(parts[2:])
                else:
                    continue
            dest = os.path.realpath(os.path.join(libs, name))
            if not dest.startswith(root):
                continue
            d = os.path.dirname(dest)
            if not os.path.isdir(d):
                os.makedirs(d)
            with z.open(info) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)


def _install_requirements(bot_dir):
    req_path = os.path.join(bot_dir, "requirements.txt")
    if not os.path.isfile(req_path):
        return
    with open(req_path, "rb") as f:
        data = f.read()
    digest = hashlib.sha1(data).hexdigest()
    libs = os.path.join(bot_dir, "libs")
    if not os.path.isdir(libs):
        os.makedirs(libs)
    marker = os.path.join(libs, ".req-hash")
    try:
        with open(marker) as f:
            if f.read().strip() == digest:
                print("[deps] requirements.txt sin cambios; nada que instalar")
                return
    except OSError:
        pass

    try:
        import importlib
        import importlib.metadata as md
        import requests
        from packaging.requirements import Requirement, InvalidRequirement
        from packaging.utils import canonicalize_name
        from packaging.version import Version
    except Exception as e:
        print("[deps] no se pueden instalar dependencias (falta %s)" % e)
        return

    pyver = Version("%d.%d.%d" % sys.version_info[:3])
    queue = []
    for raw in data.decode("utf-8", "replace").splitlines():
        line = raw.split(" #")[0].strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("-") or "://" in line or line.startswith("git+"):
            print("[deps] linea ignorada (no soportada): %s" % line)
            continue
        try:
            queue.append(Requirement(line))
        except InvalidRequirement:
            print("[deps] requisito invalido: %s" % line)

    print("[deps] instalando dependencias de requirements.txt (solo Python puro)...")
    tmpdir = os.path.join(bot_dir, ".deps-tmp")
    if not os.path.isdir(tmpdir):
        os.makedirs(tmpdir)
    sess = requests.Session()
    seen = set()
    ok = problems = 0
    net_error = False

    while queue and not _stopping:
        req = queue.pop(0)
        key = canonicalize_name(req.name)
        if key in seen:
            continue
        if req.marker is not None and not req.marker.evaluate({"extra": ""}):
            continue
        seen.add(key)

        try:
            cur = md.version(req.name)
            if not req.specifier or req.specifier.contains(cur, prereleases=True):
                print("[deps] %s %s ya disponible" % (req.name, cur))
                continue
            print("[deps] %s %s no cumple '%s'; buscando otra version" % (req.name, cur, req.specifier))
        except md.PackageNotFoundError:
            pass

        try:
            r = sess.get("https://pypi.org/pypi/%s/json" % key, timeout=30)
        except Exception as e:
            print("[deps] %s: error de red (%s)" % (req.name, e))
            net_error = True
            problems += 1
            continue
        if r.status_code == 404:
            print("[deps] %s: no existe en PyPI" % req.name)
            problems += 1
            continue
        if r.status_code != 200:
            print("[deps] %s: PyPI respondio %s" % (req.name, r.status_code))
            net_error = True
            problems += 1
            continue
        releases = r.json().get("releases", {})
        vmap = {}
        for v in releases:
            try:
                vmap[Version(v)] = v
            except Exception:
                pass
        cands = list(req.specifier.filter(list(vmap), prereleases=False)) \
            or list(req.specifier.filter(list(vmap), prereleases=True))
        cands.sort(reverse=True)
        chosen = None
        for v in cands[:20]:
            w = _pick_wheel(releases.get(vmap[v]), pyver)
            if w:
                chosen = (v, w)
                break
        if not chosen:
            print("[deps] %s: no tiene wheel de Python puro compatible (probablemente necesita "
                  "compilarse). Si Chaquopy lo incluye, agregalo en app/build.gradle." % req.name)
            problems += 1
            continue

        ver, wheel = chosen
        dest = os.path.join(tmpdir, wheel["filename"])
        try:
            sha = hashlib.sha256()
            with sess.get(wheel["url"], stream=True, timeout=60) as resp:
                resp.raise_for_status()
                with open(dest, "wb") as out:
                    for chunk in resp.iter_content(65536):
                        sha.update(chunk)
                        out.write(chunk)
            want = (wheel.get("digests") or {}).get("sha256")
            if want and sha.hexdigest() != want:
                raise ValueError("checksum no coincide")
            for old in _dist_infos(libs, key):
                shutil.rmtree(old, ignore_errors=True)
            _extract_wheel(dest, libs)
        except Exception as e:
            print("[deps] %s: fallo la descarga/instalacion (%s)" % (req.name, e))
            net_error = True
            problems += 1
            continue
        finally:
            try:
                os.remove(dest)
            except OSError:
                pass
        print("[deps] %s %s instalado" % (req.name, ver))
        ok += 1

        # dependencias del paquete (desde su METADATA)
        extras = set(e.lower() for e in req.extras) | set([""])
        for di in _dist_infos(libs, key):
            try:
                from email.parser import Parser
                with open(os.path.join(di, "METADATA"), encoding="utf-8", errors="replace") as f:
                    msg = Parser().parsestr(f.read())
            except Exception:
                continue
            for rd in msg.get_all("Requires-Dist") or []:
                try:
                    dep = Requirement(rd)
                except InvalidRequirement:
                    continue
                if dep.marker is not None and not any(dep.marker.evaluate({"extra": e}) for e in extras):
                    continue
                queue.append(dep)
            break

    shutil.rmtree(tmpdir, ignore_errors=True)
    importlib.invalidate_caches()
    if not net_error and not _stopping:
        try:
            with open(marker, "w") as f:
                f.write(digest)
        except OSError:
            pass
    print("[deps] listo: %d instalada(s), %d con problemas%s"
          % (ok, problems, " (se reintentara al iniciar)" if net_error else ""))


def warmup():
    """Importa las librerias pesadas una vez (Java lo llama con un candado entre procesos)."""
    try:
        import discord  # noqa: F401
        import aiohttp  # noqa: F401
    except Exception:
        traceback.print_exc()


def _rss_mb():
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return round(int(line.split()[1]) / 1024.0, 1)
    except Exception:
        pass
    return 0


def _active_client():
    for c, _loop in reversed(_clients):
        try:
            if not c.is_closed():
                return c
        except Exception:
            pass
    return None


def _install_hook():
    """Registra cada discord.Client que arranca para poder cerrarlo limpiamente."""
    try:
        import discord
    except Exception:
        return
    if getattr(discord.Client, "_bothost_hooked", False):
        return
    orig = discord.Client.start

    async def start(self, *args, **kwargs):
        _clients.append((self, asyncio.get_running_loop()))
        return await orig(self, *args, **kwargs)

    discord.Client.start = start
    discord.Client._bothost_hooked = True


def _heartbeat(bot_dir, started):
    path = os.path.join(bot_dir, "heartbeat.json")
    tmp = path + ".tmp"
    while not _stopping:
        info = {
            "t": time.time(),
            "started": started,
            "ready": False,
            "mem": _rss_mb(),
            "pid": os.getpid(),
        }
        c = _active_client()
        if c is not None:
            try:
                info["ready"] = bool(c.is_ready())
                user = c.user
                info["user"] = str(user) if user else ""
                info["guilds"] = len(c.guilds)
                lat = c.latency
                info["ping"] = int(lat * 1000) if lat == lat and lat != float("inf") else -1
            except Exception:
                pass
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(info, f)
            os.replace(tmp, path)
        except Exception:
            pass
        time.sleep(3)


def _apply_env(cfg):
    token = (cfg.get("token") or "").strip()
    if token:
        for k in ("DISCORD_TOKEN", "TOKEN", "BOT_TOKEN"):
            os.environ[k] = token
    for line in (cfg.get("env") or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        if k:
            os.environ[k] = v


def run(bot_dir):
    """Ejecuta main.py y lo reinicia si se cae (segun config). Bloquea hasta stop()."""
    global _stopping
    _stopping = False
    bot_dir = str(bot_dir)

    log = _Log(os.path.join(bot_dir, "log.txt"))
    sys.stdout = log
    sys.stderr = log

    try:
        os.chdir(bot_dir)
    except OSError:
        pass
    if bot_dir not in sys.path:
        sys.path.insert(0, bot_dir)

    try:
        with open(os.path.join(bot_dir, "config.json"), encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
    _apply_env(cfg)
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    try:  # certificados CA propios por si el sistema no los expone a OpenSSL
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except Exception:
        pass
    libs = os.path.join(bot_dir, "libs")  # paquetes de Python puro copiados a mano
    if libs not in sys.path:
        sys.path.insert(1, libs)
    if not (cfg.get("token") or "").strip() and not os.environ.get("DISCORD_TOKEN"):
        print("[host] aviso: no hay token configurado (pegalo en la pantalla del bot)")
    _install_hook()

    t = threading.Thread(target=_heartbeat, args=(bot_dir, time.time()))
    t.daemon = True
    t.start()

    if cfg.get("installReqs", True):
        try:
            _install_requirements(bot_dir)
        except Exception:
            traceback.print_exc()

    entry = os.path.join(bot_dir, "main.py")
    autorestart = bool(cfg.get("autoRestart", True))
    print("[host] Python %s - bot '%s'" % (sys.version.split()[0], cfg.get("name", "?")))

    attempt = 0
    while not _stopping:
        started = time.time()
        fatal = False
        print("[host] iniciando main.py")
        try:
            runpy.run_path(entry, run_name="__main__")
            print("[host] el script termino")
        except SystemExit as e:
            print("[host] SystemExit: %s" % (e.code,))
        except BaseException as e:
            traceback.print_exc()
            h = _hint(e)
            if h:
                print("[host] %s" % h[0])
                fatal = h[1]

        if _stopping:
            break
        if fatal:
            print("[host] error que no se arregla reiniciando; deteniendo")
            break
        if not autorestart:
            print("[host] auto-reinicio desactivado; deteniendo")
            break

        attempt = 0 if time.time() - started > 60 else attempt + 1
        delay = min(60, 5 * (2 ** (attempt - 1))) if attempt else 5
        print("[host] reiniciando en %ds" % delay)
        for _ in range(delay):
            if _stopping:
                break
            time.sleep(1)

    print("[host] bot detenido")
    log.flush()


def stop():
    """Cierra los clientes de discord con gracia (Java mata el proceso despues)."""
    global _stopping
    _stopping = True
    for client, loop in list(_clients):
        try:
            if not client.is_closed():
                fut = asyncio.run_coroutine_threadsafe(client.close(), loop)
                fut.result(timeout=6)
        except Exception as e:
            print("[host] error al cerrar: %s" % (e,))
