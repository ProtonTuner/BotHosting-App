"""Runner de bots. Corre dentro del proceso de cada bot (un proceso por bot).

Java llama a run(bot_dir) en un hilo, stop() para cerrar, y warmup() una vez.
"""
import asyncio
import io
import json
import os
import runpy
import sys
import threading
import time
import traceback

_stopping = False
_clients = []  # (client, loop) de cada discord.Client que se inicio


class _Log(object):
    """Escribe stdout/stderr en log.txt con hora y rota el archivo si crece."""

    encoding = "utf-8"
    errors = "replace"

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self.bol = True
        try:
            size = os.path.getsize(path)
        except OSError:
            size = 0
        if size > 400000:
            try:
                os.replace(path, path + ".1")
            except OSError:
                pass
            size = 0
        self.n = size
        self.f = open(path, "a", encoding="utf-8", errors="replace", buffering=1)

    def write(self, s):
        if not s:
            return 0
        out = []
        for part in s.splitlines(True):
            if self.bol:
                out.append(time.strftime("%H:%M:%S "))
            out.append(part)
            self.bol = part.endswith("\n")
        text = "".join(out)
        with self.lock:
            try:
                self.f.write(text)
                self.n += len(text)
                if self.n > 400000:
                    self._rotate()
            except Exception:
                pass
        return len(s)

    def _rotate(self):
        try:
            self.f.close()
            os.replace(self.path, self.path + ".1")
        except OSError:
            pass
        self.f = open(self.path, "a", encoding="utf-8", errors="replace", buffering=1)
        self.n = 0

    def flush(self):
        try:
            self.f.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


def warmup():
    """Importa las librerias pesadas una vez (Java lo llama con un candado entre procesos)."""
    try:
        import discord  # noqa: F401
        import aiohttp  # noqa: F401
    except Exception:
        traceback.print_exc()


def _rss_mb():
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return round(int(line.split()[1]) / 1024.0, 1)
    except Exception:
        pass
    return 0


def _active_client():
    for c, _loop in reversed(_clients):
        try:
            if not c.is_closed():
                return c
        except Exception:
            pass
    return None


def _install_hook():
    """Registra cada discord.Client que arranca para poder cerrarlo limpiamente."""
    try:
        import discord
    except Exception:
        return
    if getattr(discord.Client, "_bothost_hooked", False):
        return
    orig = discord.Client.start

    async def start(self, *args, **kwargs):
        _clients.append((self, asyncio.get_running_loop()))
        return await orig(self, *args, **kwargs)

    discord.Client.start = start
    discord.Client._bothost_hooked = True


def _heartbeat(bot_dir, started):
    path = os.path.join(bot_dir, "heartbeat.json")
    tmp = path + ".tmp"
    while not _stopping:
        info = {
            "t": time.time(),
            "started": started,
            "ready": False,
            "mem": _rss_mb(),
            "pid": os.getpid(),
        }
        c = _active_client()
        if c is not None:
            try:
                info["ready"] = bool(c.is_ready())
                user = c.user
                info["user"] = str(user) if user else ""
                info["guilds"] = len(c.guilds)
                lat = c.latency
                info["ping"] = int(lat * 1000) if lat == lat and lat != float("inf") else -1
            except Exception:
                pass
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(info, f)
            os.replace(tmp, path)
        except Exception:
            pass
        time.sleep(3)


def _apply_env(cfg):
    token = (cfg.get("token") or "").strip()
    if token:
        for k in ("DISCORD_TOKEN", "TOKEN", "BOT_TOKEN"):
            os.environ[k] = token
    for line in (cfg.get("env") or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        if k:
            os.environ[k] = v


def run(bot_dir):
    """Ejecuta main.py y lo reinicia si se cae (segun config). Bloquea hasta stop()."""
    global _stopping
    _stopping = False
    bot_dir = str(bot_dir)

    log = _Log(os.path.join(bot_dir, "log.txt"))
    sys.stdout = log
    sys.stderr = log

    try:
        os.chdir(bot_dir)
    except OSError:
        pass
    if bot_dir not in sys.path:
        sys.path.insert(0, bot_dir)

    try:
        with open(os.path.join(bot_dir, "config.json"), encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
    _apply_env(cfg)
    _install_hook()

    t = threading.Thread(target=_heartbeat, args=(bot_dir, time.time()))
    t.daemon = True
    t.start()

    entry = os.path.join(bot_dir, "main.py")
    autorestart = bool(cfg.get("autoRestart", True))
    print("[host] Python %s - bot '%s'" % (sys.version.split()[0], cfg.get("name", "?")))

    attempt = 0
    while not _stopping:
        started = time.time()
        print("[host] iniciando main.py")
        try:
            runpy.run_path(entry, run_name="__main__")
            print("[host] el script termino")
        except SystemExit as e:
            print("[host] SystemExit: %s" % (e.code,))
        except BaseException:
            traceback.print_exc()

        if _stopping:
            break
        if not autorestart:
            print("[host] auto-reinicio desactivado; deteniendo")
            break

        attempt = 0 if time.time() - started > 60 else attempt + 1
        delay = min(60, 5 * (2 ** (attempt - 1))) if attempt else 5
        print("[host] reiniciando en %ds" % delay)
        for _ in range(delay):
            if _stopping:
                break
            time.sleep(1)

    print("[host] bot detenido")
    log.flush()


def stop():
    """Cierra los clientes de discord con gracia (Java mata el proceso despues)."""
    global _stopping
    _stopping = True
    for client, loop in list(_clients):
        try:
            if not client.is_closed():
                fut = asyncio.run_coroutine_threadsafe(client.close(), loop)
                fut.result(timeout=6)
        except Exception as e:
            print("[host] error al cerrar: %s" % (e,))
