# Vesper BotHost 10.0.0

**Product direction:** a Discord-bot control panel for Android, built on the Vesper Runtime 1.8 source base and using the supplied debug APK only as a visual/runtime reference. This archive is the editable source project; it is not an APK.

## What changed in 10.0.0

- Repositioned the app around Discord bots with BotHost branding, dashboard cards, dedicated Bots screen, custom server-stack launcher glyph, status and action controls.
- Added per-bot projects with a `/ping` slash-command starter, `bot.py`, `requirements.txt`, `vesper-bot.json`, `.env.example`, `.gitignore`, and per-project logs.
- Added token setup/removal UI. `DISCORD_TOKEN` is written to a bot-specific `.env` in app-private storage; the bot list returns only a Boolean status, not the secret. `.env` is hidden from browsing and blocked from the text-export action.
- Added bot ZIP import with traversal checks, a 500-entry cap, 20 MiB expanded-data limit, duplicate-file detection, and exclusion of `.env`, `.git`, `venv`, caches, and imported bot metadata.
- Added start/stop, entrypoint selection, source editing, file browsing, project deletion, and a local hosting dashboard. Runtime errors that surface as Python tracebacks are now marked as errors rather than normal completion.
- Added scoped `.env` handling to Python execution: variables exist for the script run and are restored afterward, preventing a previous bot token from carrying over to the next run.
- Bundles `discord.py==2.7.1` plus pinned Android-wheel builds of `aiohttp`, `yarl`, `multidict` and `frozenlist` in the Chaquopy manifest and sets Android version `10.0.0` / versionCode `100000`.
- Preserves the prior editor, standalone Python scripts, console, dependency validation, import tools and foreground-service controls.

## Build a debug APK with GitHub Actions

1. Upload this project directory to a GitHub repository.
2. Open **Actions**, choose **Build Vesper BotHost APK**, and run the workflow (or push a change to one of its watched paths).
3. Download artifact **`vesper-bothost-v10.0.0-debug-apk`** after the workflow succeeds.

This workspace does not include a configured Android SDK or Gradle executable, so APK assembly and Android runtime behavior have **not** been verified here. The workflow runs the host-side tests and attempts the actual Android build. Chaquopy must find Android-compatible wheels for every native dependency; if a dependency has no matching Android wheel, the Gradle build will fail rather than create a usable APK. See the [Chaquopy package compatibility FAQ](https://www.chaquo.com/chaquopy/doc/current/faq.html) and [plugin documentation](https://chaquo.com/chaquopy/doc/current/android.html).

## Create and run a bot

1. Open **Bots** and select **Nuevo bot** or **Importar ZIP**.
2. Configure the Discord bot token from the bot card. Never place the token directly in source code or an exported archive.
3. Review `bot.py` and `requirements.txt`. For the starter, create a bot application in the Discord Developer Portal and invite it to your server with the `bot` and `applications.commands` scopes.
4. Start the bot and watch **Console** for connection, slash-command sync and errors. The starter defines `/ping` and does not require Message Content Intent.
5. Use **Entrypoint** to change the root-level `.py` file, **Files** to inspect the project, or **Delete** to remove source and stored token after confirmation.

The APK's dependency manifest is build-time configuration. Editing `requirements.txt` inside an installed app does not install a new package into that APK. The included Discord library is pinned; extra third-party packages must be added to `app/requirements.txt` in source and checked by a real Chaquopy build. Native packages and arbitrary desktop bot dependencies are not guaranteed to work on Android.

## Known limitations and safety

- **One runtime slot:** this release manages many bot projects but runs only one Python script/bot at a time. It is not a multi-process daemon manager yet.
- **Local hosting:** bots run on the phone. Android may restrict or terminate background work due to force-stop, memory pressure, battery policy or OEM behavior. Auto-recovery is best-effort; this is not guaranteed cloud or 24/7 hosting.
- **Not a sandbox:** running a bot executes Python inside the app process with the app's access to network and private files. Review imported ZIPs and code before running them. A malicious script can read its own `.env` and can deliberately print its token; secrecy measures here reduce accidental display/export, not hostile-code exposure.
- **Logs are local:** logs are stored under each bot's private `.vesper-logs` directory, bounded by the runtime output cap. Avoid logging tokens or other credentials.
- **Token storage:** app-private `.env` is protected by Android app storage permissions and written atomically with restrictive file mode where supported. This is not hardware-backed secret storage. Uninstalling the app removes its private workspace.
- **Runtime stop is cooperative:** the Stop action uses Python trace events. It cannot reliably interrupt every blocking native extension or network call, and scripts may disable tracing.
- **App distribution:** the included workflow builds a debug APK, not a production-signed release. Google Play has separate foreground-service and distribution requirements.

## Run host-side tests

```bash
python -m unittest discover -s tests -v
```

These tests validate Python runtime behavior and structural Android/source invariants. They do not replace a successful Gradle build, installation, bot-token test or live Discord connection on a physical device.
