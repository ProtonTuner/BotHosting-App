package com.mini.bothost;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Descarga el bot desde GitHub (repo completo o un .zip dentro del repo) y lo extrae. */
final class GitHub {
    private GitHub() { }

    /**
     * Acepta "usuario/repo", "https://github.com/usuario/repo(.git)", ".../tree/rama" o
     * "git@github.com:usuario/repo.git". Devuelve {repo, rama} (rama "" si no viene) o null.
     */
    static String[] parse(String in) {
        if (in == null) {
            return null;
        }
        String s = in.trim();
        if (s.isEmpty()) {
            return null;
        }
        s = s.replaceFirst("^git@github\\.com:", "")
                .replaceFirst("^(?i)(https?://)?(www\\.)?github\\.com/", "");
        int q = s.indexOf('?');
        if (q >= 0) {
            s = s.substring(0, q);
        }
        q = s.indexOf('#');
        if (q >= 0) {
            s = s.substring(0, q);
        }
        String[] seg = s.split("/");
        if (seg.length < 2) {
            return null;
        }
        String repo = seg[1];
        if (repo.endsWith(".git")) {
            repo = repo.substring(0, repo.length() - 4);
        }
        String full = seg[0] + "/" + repo;
        if (!full.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")) {
            return null;
        }
        String branch = (seg.length >= 4 && seg[2].equals("tree")) ? seg[3] : "";
        return new String[]{full, branch};
    }

    private static HttpURLConnection open(String url, Store.Bot b, String accept, int readMs)
            throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(15000);
        h.setReadTimeout(readMs);
        h.setRequestProperty("User-Agent", "BotHost");
        h.setRequestProperty("Accept", accept);
        if (!b.ghToken.trim().isEmpty()) {
            h.setRequestProperty("Authorization", "Bearer " + b.ghToken.trim());
        }
        return h;
    }

    /** SHA del ultimo commit de la rama (vacia = rama por defecto) o null si no se pudo saber. */
    static String headSha(Store.Bot b) {
        String repo = b.ghRepo.trim();
        if (!repo.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")) {
            return null;
        }
        String ref = b.ghBranch.trim();
        HttpURLConnection h = null;
        try {
            h = open("https://api.github.com/repos/" + repo + "/commits/"
                    + (ref.isEmpty() ? "HEAD" : Uri.encode(ref, "/")), b,
                    "application/vnd.github.sha", 10000);
            if (h.getResponseCode() != 200) {
                return null;
            }
            InputStream in = h.getInputStream();
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[256];
                int n;
                while ((n = in.read(buf)) != -1 && bo.size() < 256) {
                    bo.write(buf, 0, n);
                }
                String sha = new String(bo.toByteArray(), "UTF-8").trim();
                return sha.matches("[0-9a-f]{40}") ? sha : null;
            } finally {
                in.close();
            }
        } catch (IOException e) {
            return null;
        } finally {
            if (h != null) {
                h.disconnect();
            }
        }
    }

    /** Descarga y extrae siempre. Devuelve null si todo salio bien, o el mensaje de error. */
    static String update(Context c, Store.Bot b) {
        String repo = b.ghRepo.trim();
        if (!repo.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")) {
            return "Repositorio no válido (usa usuario/repo)";
        }
        // Rama vacía = la rama por defecto del repo (main, master, lo que sea)
        String ref = b.ghBranch.trim();
        String path = b.ghPath.trim();
        while (path.startsWith("/")) {
            path = path.substring(1);
        }
        String url = "https://api.github.com/repos/" + repo
                + (path.isEmpty() ? "/zipball" + (ref.isEmpty() ? "" : "/" + Uri.encode(ref, "/"))
                : "/contents/" + Uri.encode(path, "/") + (ref.isEmpty() ? "" : "?ref=" + Uri.encode(ref)));

        File tmp = new File(c.getCacheDir(), "gh-" + b.id + ".dl");
        HttpURLConnection h = null;
        try {
            h = open(url, b, path.isEmpty()
                    ? "application/vnd.github+json" : "application/vnd.github.raw+json", 60000);
            int code = h.getResponseCode();
            if (code == 403 && "0".equals(h.getHeaderField("X-RateLimit-Remaining"))) {
                return "Límite de peticiones de GitHub alcanzado. Agrega un token de GitHub o espera un rato";
            }
            if (code == 401 || code == 403) {
                return "GitHub rechazó el acceso (revisa el token y sus permisos)";
            }
            if (code == 404) {
                return "No se encontró el repo, la rama o el archivo (¿falta el token de un repo privado?)";
            }
            if (code != 200) {
                return "GitHub respondió " + code;
            }
            InputStream in = h.getInputStream();
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[8192];
                long total = 0;
                int n;
                while ((n = in.read(buf)) != -1) {
                    total += n;
                    if (total > 100L * 1024 * 1024) {
                        return "El archivo pesa más de 100 MB";
                    }
                    out.write(buf, 0, n);
                }
            } finally {
                in.close();
                out.close();
            }
            String sha = null;
            if (path.isEmpty()) {
                // el zipball viene dentro de "usuario-repo-<sha7>/": ese es el commit extraido
                String top = Store.zipTopDir(tmp);
                int i = top.lastIndexOf('-');
                if (i >= 0 && top.substring(i + 1).matches("[0-9a-f]{7,40}")) {
                    sha = top.substring(i + 1);
                }
            } else {
                sha = headSha(b);
            }
            if (path.isEmpty() || path.toLowerCase().endsWith(".zip")) {
                if (Store.unzip(tmp, Store.dir(c, b.id)) < 0) {
                    return "No se pudo extraer el zip descargado";
                }
            } else {
                File dest = Store.resolve(c, b.id, path.substring(path.lastIndexOf('/') + 1));
                if (dest == null || !tmp.renameTo(dest)) {
                    return "No se pudo guardar el archivo";
                }
            }
            Store.writeDeploy(c, b.id, repo, ref, sha);
            return null;
        } catch (IOException e) {
            return "Error de red: " + e.getMessage();
        } finally {
            if (h != null) {
                h.disconnect();
            }
            tmp.delete();
        }
    }

    /**
     * Para el arranque automático: baja el repo solo si hay un commit nuevo. Reintenta si no hay
     * red todavía (p. ej. justo después de encender el celular). Devuelve una línea para el log.
     */
    static String syncIfNew(Context c, Store.Bot b) {
        String err = "sin respuesta";
        for (int attempt = 0; attempt < 3; attempt++) {
            if (attempt > 0) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            String remote = headSha(b);
            String local = Store.deploySha(c, b.id);
            if (remote != null && !local.isEmpty()
                    && (remote.equals(local) || remote.startsWith(local))) {
                return "ya estás en la última versión (" + short7(remote) + ")";
            }
            err = update(c, b);
            if (err == null) {
                String now = Store.deploySha(c, b.id);
                return "actualizado a " + (now.isEmpty() ? "la última versión" : short7(now));
            }
            if (!err.startsWith("Error de red")) {
                break; // token malo, repo inexistente...: reintentar no sirve
            }
        }
        return "no se pudo actualizar (" + err + "); se usa el código que ya está guardado";
    }

    static String short7(String sha) {
        return sha == null ? "" : (sha.length() > 7 ? sha.substring(0, 7) : sha);
    }
}
