import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).parents[1] / "app" / "src" / "main" / "python" / "vesper_bot_host.py"
spec = importlib.util.spec_from_file_location("vesper_bot_host", MODULE_PATH)
vesper_bot_host = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(vesper_bot_host)


class BotHostProjectsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "discord_bots"
        self.root.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def create(self, project_id="status_bot"):
        response = json.loads(vesper_bot_host.create_project_json(str(self.root), project_id))
        self.assertTrue(response["ok"], response)
        return self.root / project_id

    def test_creates_complete_discord_slash_bot_project(self):
        project = self.create()
        self.assertTrue((project / "bot.py").is_file())
        self.assertTrue((project / "vesper-bot.json").is_file())
        self.assertTrue((project / ".env.example").is_file())
        self.assertTrue((project / ".gitignore").is_file())
        code = (project / "bot.py").read_text(encoding="utf-8")
        self.assertIn("app_commands.CommandTree", code)
        self.assertIn('@tree.command(name="ping"', code)
        self.assertNotIn("DISCORD_TOKEN=", (project / "bot.py").read_text(encoding="utf-8"))

    def test_duplicate_name_does_not_overwrite_project(self):
        project = self.create()
        (project / "bot.py").write_text("custom\n", encoding="utf-8")
        response = json.loads(vesper_bot_host.create_project_json(str(self.root), "status_bot"))
        self.assertFalse(response["ok"])
        self.assertEqual((project / "bot.py").read_text(encoding="utf-8"), "custom\n")

    def test_project_id_rejects_path_traversal(self):
        for name in ("../outside", "/tmp/bot", "bot name", ".hidden", "x" * 41):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    vesper_bot_host.create_project_json(str(self.root), name)

    def test_listing_reports_missing_token_without_leaking_token(self):
        project = self.create()
        token = "never-return-this-secret"
        vesper_bot_host.set_discord_token_json(str(self.root), project.name, token)
        result = json.loads(vesper_bot_host.list_projects_json(str(self.root)))
        serialized = json.dumps(result)
        self.assertNotIn(token, serialized)
        self.assertTrue(result["projects"][0]["token_configured"])
        self.assertTrue(result["projects"][0]["entrypoint_exists"])

    def test_secret_write_rejects_multiline_and_oversized_values(self):
        self.create()
        for token in ("bad\nDISCORD_TOKEN=other", "x" * 513, "\x00bad"):
            with self.subTest(token=token[:20]):
                with self.assertRaises(ValueError):
                    vesper_bot_host.set_discord_token_json(str(self.root), "status_bot", token)

    def test_secret_writer_preserves_other_environment_values(self):
        project = self.create()
        (project / ".env").write_text('API_BASE="https://example.test/api"\n', encoding="utf-8")
        vesper_bot_host.set_discord_token_json(str(self.root), project.name, "abc.def.ghi")
        values = vesper_bot_host._read_dotenv(project / ".env")
        self.assertEqual(values["API_BASE"], "https://example.test/api")
        self.assertEqual(values["DISCORD_TOKEN"], "abc.def.ghi")

    def test_env_json_escape_round_trip_when_updating_token(self):
        project = self.create()
        value = "tabs\t unicode-é slash\\tail"
        (project / ".env").write_text("CUSTOM_VALUE=" + json.dumps(value, ensure_ascii=False) + "\n", encoding="utf-8")
        vesper_bot_host.set_discord_token_json(str(self.root), project.name, "abc.def.ghi")
        parsed = vesper_bot_host._read_dotenv(project / ".env")
        self.assertEqual(parsed["CUSTOM_VALUE"], value)
        self.assertEqual(parsed["DISCORD_TOKEN"], "abc.def.ghi")

    def test_import_registration_rejects_entrypoint_outside_root(self):
        project = self.root / "raw_import"
        project.mkdir()
        with self.assertRaises(ValueError):
            vesper_bot_host.register_imported_project_json(str(self.root), project.name, "Bad", "../bot.py")

    def test_delete_requires_registered_child_project(self):
        project = self.create()
        response = json.loads(vesper_bot_host.delete_project_json(str(self.root), project.name))
        self.assertTrue(response["ok"])
        self.assertFalse(project.exists())
        with self.assertRaises(ValueError):
            vesper_bot_host.delete_project_json(str(self.root), "../outside")

    def test_clear_token_preserves_nonsecret_variables(self):
        project = self.create()
        vesper_bot_host.set_discord_token_json(str(self.root), project.name, "top.secret.token")
        (project / ".env").write_text((project / ".env").read_text(encoding="utf-8") + "FEATURE_FLAG=on\n", encoding="utf-8")
        vesper_bot_host.clear_discord_token_json(str(self.root), project.name)
        values = vesper_bot_host._read_dotenv(project / ".env")
        self.assertNotIn("DISCORD_TOKEN", values)
        self.assertEqual(values["FEATURE_FLAG"], "on")


if __name__ == "__main__":
    unittest.main()
